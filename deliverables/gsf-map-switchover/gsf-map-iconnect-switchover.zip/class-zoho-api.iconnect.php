<?php
/**
 * ============================================================================
 * iCONNECT SWITCH-OVER -- HANDOVER NOTES (2026-07-09)
 * ============================================================================
 * This file is the plugin's original ZohoAPI class with the Zoho CRM calls
 * repointed at the iConnect API. Every replaced block of original code has
 * been left in place but commented out between clearly marked
 *
 *     "ORIGINAL ZOHO CODE (disabled 2026-07-09)" / "END ORIGINAL ZOHO CODE"
 *
 * markers, and every new block is tagged [ICONNECT 2026-07-09] with a comment
 * explaining the change, so you can review exactly what changed and why.
 *
 * WHAT CHANGED
 *  - Members are now fetched from:   GET {base}/api/public/gsf-map/members
 *  - Countries are now fetched from: GET {base}/api/public/gsf-map/countries
 *  - Auth is a shared secret sent as an "X-Api-Key" header. There is no OAuth
 *    and no token refresh any more; the whole Zoho token machinery is
 *    commented out / no-opped.
 *  - Both endpoints return payloads byte-compatible with the old Zoho ones
 *    (same field names, same "id" values), already filtered to current
 *    members, in a single JSON array (no pagination and no "data"/"info"
 *    envelope).
 *  - Everything downstream is untouched: post creation/update, meta fields,
 *    stale-record deletion, the getMembers() filters, and the
 *    gsf_zoho_countries option shape are all exactly as before.
 *
 * CONFIGURATION (WordPress options -- set these BEFORE deploying)
 *   gsf_iconnect_base_url   e.g. https://your-iconnect-host  (no trailing /)
 *   gsf_iconnect_api_key    the shared secret; sent as the X-Api-Key header
 * e.g. via WP-CLI:
 *   wp option update gsf_iconnect_base_url 'https://...'
 *   wp option update gsf_iconnect_api_key '...'
 * If either option is missing the sync logs an ERROR and aborts (no fallback
 * to Zoho).
 *
 * ON THE iCONNECT SIDE
 *  - The env var GSF_MAP_API_SECRET must be set on the iConnect deployment;
 *    the endpoints return HTTP 503 until it is.
 *  - Responses are CDN-cached for 5 minutes (Cache-Control: max-age=300,
 *    stale-while-revalidate=600), so changes made in iConnect can take up to
 *    ~5 minutes to be visible to a sync.
 *  - A 401 from these endpoints means the API key is wrong. Unlike Zoho there
 *    is no token to refresh or clear -- the code now just logs and aborts.
 *
 * SECURITY -- PLEASE ACTION
 *  - The original file contained a hard-coded Zoho client id, client secret
 *    and refresh token (still visible, commented out, just below). Those
 *    credentials were committed in plain text and should be ROTATED / REVOKED
 *    in the Zoho admin console once the switch-over is confirmed.
 * ============================================================================
 */
/**
 * Zoho API integration class
 */
class ZohoAPI
{
    // [ICONNECT 2026-07-09] The hard-coded Zoho OAuth credentials below are no
    // longer used anywhere in this class. They are kept (commented out) only so
    // you can identify WHICH credentials to rotate/revoke in Zoho -- see the
    // SECURITY note in the header. iConnect connection settings are read from
    // WP options instead (gsf_iconnect_base_url / gsf_iconnect_api_key).
    // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
    // Kept for review -- safe to delete once the iConnect switch-over is verified.
    // -------------------------------------------------------------------------------
    // private $clientId = '1000.7WKGX9DP1FINC0GHFC9S5X4655RVIU';
    // private $clientSecret = '9cc492e34793e45a782e485538ad9e9c30c409b858';
    // private $refreshToken = '1000.f5a2d10c3021b24e4ab49ca312828cee.418c6e771618aea44e9d0857e05c59f8';
    // ==================== END ORIGINAL ZOHO CODE ===================================
    // [ICONNECT 2026-07-09] $tokenExpiry / $accessToken are retained only so the
    // legacy debug helpers at the bottom of the file (getTokenStatus,
    // clearCachedTokens) keep compiling; they stay null and are never used for
    // requests any more.
    private $tokenExpiry = null;
    private $accessToken = null;
    private $lastSyncTime = null;
    private $lastCountrySyncTime = null;
    private $syncInterval = null; // Will be loaded from options
    private $countrySyncInterval = 86400; // 24 hours in seconds
    private $logger;

    public function __construct()
    {
        $this->logger = GSF_Logger::getInstance();
        $this->lastSyncTime = get_option('gsf_zoho_last_sync');
        $this->lastCountrySyncTime = get_option('gsf_zoho_last_country_sync');

        // Load sync interval from options (default to 1 hour)
        $this->syncInterval = get_option('gsf_sync_interval', 3600);

        // [ICONNECT 2026-07-09] No stored OAuth token to load any more -- auth is a
        // per-request X-Api-Key header read from the gsf_iconnect_api_key option.
        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // // Load stored token data
        // $this->accessToken = get_option('gsf_zoho_access_token');
        // $this->tokenExpiry = get_option('gsf_zoho_token_expiry', 0);
        // ==================== END ORIGINAL ZOHO CODE ===================================

        $this->logger->log('ZohoAPI initialized', 'INFO', [
            'lastSyncTime' => $this->lastSyncTime,
            'lastCountrySyncTime' => $this->lastCountrySyncTime,
            'tokenExpiry' => $this->tokenExpiry ? date('Y-m-d H:i:s', $this->tokenExpiry) : 'none'
        ]);
        // [ICONNECT 2026-07-09] No token refresh needed (maybeRefreshToken() is now a
        // no-op, see below).
        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->maybeRefreshToken();
        // ==================== END ORIGINAL ZOHO CODE ===================================
    }

    // ==========================================================================
    // [ICONNECT 2026-07-09] New helpers for the iConnect switch-over.
    // The base URL and API key are read from WordPress options so that no
    // secrets are hard-coded in this file (unlike the original Zoho version).
    // ==========================================================================

    /**
     * [ICONNECT 2026-07-09] iConnect base URL, e.g. https://your-iconnect-host
     * (no trailing slash). Read from the gsf_iconnect_base_url option.
     */
    private function getIconnectBaseUrl()
    {
        $base = get_option('gsf_iconnect_base_url', '');
        return rtrim(is_string($base) ? trim($base) : '', '/');
    }

    /**
     * [ICONNECT 2026-07-09] Shared secret for the iConnect map endpoints, sent as
     * the X-Api-Key header. Read from the gsf_iconnect_api_key option.
     */
    private function getIconnectApiKey()
    {
        $key = get_option('gsf_iconnect_api_key', '');
        return is_string($key) ? trim($key) : '';
    }

    /**
     * [ICONNECT 2026-07-09] Shared GET helper for the two iConnect map endpoints.
     * Both endpoints return a bare JSON array (no Zoho-style data/info
     * envelope, no pagination). Returns the decoded array on success or null
     * on any failure; failures are logged so callers keep their existing
     * null/false handling.
     */
    private function fetchIconnectCollection($path, $context)
    {
        $base = $this->getIconnectBaseUrl();
        $key = $this->getIconnectApiKey();

        if ($base === '' || $key === '') {
            $this->logger->log('iConnect API not configured', 'ERROR', [
                'context' => $context,
                'missing_option' => $base === '' ? 'gsf_iconnect_base_url' : 'gsf_iconnect_api_key'
            ]);
            return null;
        }

        $url = $base . $path;

        $this->logger->log('Fetching from iConnect', 'DEBUG', [
            'context' => $context,
            'url' => $url
        ]);

        $response = wp_remote_get($url, [
            'headers' => [
                'X-Api-Key' => $key,
                'Accept' => 'application/json'
            ],
            'timeout' => 60
        ]);

        if (is_wp_error($response)) {
            $this->logger->log('iConnect API request failed', 'ERROR', [
                'context' => $context,
                'error' => $response->get_error_message()
            ]);
            return null;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($response_code === 401) {
            // [ICONNECT 2026-07-09] Unlike Zoho, a 401 here means the shared API
            // key is wrong or has been rotated -- there is no token to refresh
            // or clear. Log and abort; fix the gsf_iconnect_api_key option.
            $this->logger->log('iConnect API rejected the API key (401) - check the gsf_iconnect_api_key option', 'ERROR', [
                'context' => $context
            ]);
            return null;
        }

        if ($response_code === 503) {
            // [ICONNECT 2026-07-09] The endpoints return 503 until the
            // GSF_MAP_API_SECRET env var is configured on the iConnect side.
            $this->logger->log('iConnect API not configured on the server (503) - GSF_MAP_API_SECRET not set on iConnect', 'ERROR', [
                'context' => $context
            ]);
            return null;
        }

        if ($response_code !== 200) {
            $this->logger->log('iConnect API returned non-200 status', 'ERROR', [
                'context' => $context,
                'response_code' => $response_code,
                'response' => $body
            ]);
            return null;
        }

        if (!is_array($body)) {
            $this->logger->log('iConnect API returned an unexpected (non-array) body', 'ERROR', [
                'context' => $context
            ]);
            return null;
        }

        return $body;
    }

    private function maybeRefreshToken()
    {
        // [ICONNECT 2026-07-09] No-op. iConnect auth is a static X-Api-Key header;
        // there is no OAuth token to refresh. The entire original refresh flow
        // (including the hard-coded credentials and token option writes) is
        // disabled below.
        return;

        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->logger->log('Checking token status', 'DEBUG');
        //
        // // Add a 5-minute buffer before expiry to avoid edge cases
        // $buffer = 300; // 5 minutes
        //
        // if (!$this->accessToken || (time() > ($this->tokenExpiry - $buffer))) {
            // $this->logger->log('Token refresh required', 'INFO', [
                // 'current_time' => time(),
                // 'token_expiry' => $this->tokenExpiry,
                // 'time_until_expiry' => $this->tokenExpiry ? ($this->tokenExpiry - time()) : 'no_token'
            // ]);
        //
            // // Check for rate limiting - don't refresh more than once per minute
            // $last_refresh = get_option('gsf_zoho_last_token_refresh', 0);
            // if ($last_refresh && (time() - $last_refresh) < 60) {
                // $this->logger->log('Token refresh rate limited', 'WARNING', [
                    // 'seconds_since_last_refresh' => time() - $last_refresh
                // ]);
                // return;
            // }
        //
            // $response = wp_remote_post('https://accounts.zoho.eu/oauth/v2/token', [
                // 'body' => [
                    // 'client_id' => $this->clientId,
                    // 'client_secret' => $this->clientSecret,
                    // 'refresh_token' => $this->refreshToken,
                    // 'grant_type' => 'refresh_token'
                // ],
                // 'timeout' => 30
            // ]);
        //
            // if (is_wp_error($response)) {
                // $this->logger->log('Token refresh failed', 'ERROR', [
                    // 'error' => $response->get_error_message()
                // ]);
                // return;
            // }
        //
            // $body = json_decode(wp_remote_retrieve_body($response), true);
            // if (isset($body['access_token'])) {
                // $this->accessToken = $body['access_token'];
                // $this->tokenExpiry = time() + intval($body['expires_in']);
        //
                // // Store tokens persistently
                // update_option('gsf_zoho_access_token', $this->accessToken);
                // update_option('gsf_zoho_token_expiry', $this->tokenExpiry);
                // update_option('gsf_zoho_last_token_refresh', time());
        //
                // $this->logger->log('Token refreshed successfully', 'INFO', [
                    // 'expires_in' => $body['expires_in'],
                    // 'new_expiry' => date('Y-m-d H:i:s', $this->tokenExpiry)
                // ]);
            // } else {
                // $this->logger->log('Token refresh response invalid', 'ERROR', [
                    // 'response' => $body
                // ]);
            // }
        // } else {
            // $this->logger->log('Token still valid', 'DEBUG', [
                // 'expires_in' => $this->tokenExpiry - time() . ' seconds'
            // ]);
        // }
        // ==================== END ORIGINAL ZOHO CODE ===================================
    }

    private function syncMembersToWordPress($members)
    {
        $this->logger->log('Starting member sync', 'INFO', [
            'memberCount' => count($members)
        ]);

        $sync_stats = [
            'created' => 0,
            'updated' => 0,
            'failed' => 0,
            'total_fetched' => count($members),
        ];

        foreach ($members as $member) {
            $post_updated = false; // Track if the post itself was updated

            $existing_member = get_posts([
                'post_type' => 'gsf_member',
                'meta_query' => [
                    [
                        'key' => 'zoho_id',
                        'value' => $member['id'],
                    ]
                ],
                'posts_per_page' => 1,
                'post_status' => ['publish', 'draft']
            ]);

            try {
                if (empty($existing_member)) {
                    // New member - create as published initially
                    $member_data = [
                        'post_title' => $member['Account_Name'],
                        'post_type' => 'gsf_member',
                        'post_status' => 'publish',
                        'post_date' => current_time('mysql'),
                        'post_modified' => current_time('mysql'),
                    ];
                    $post_id = wp_insert_post($member_data);
                    if ($post_id) {
                        $sync_stats['created']++;
                    } else {
                        $sync_stats['failed']++;
                    }
                } else {
                    // Check if existing member needs updating
                    $existing_post = $existing_member[0];
                    $needs_update = false;

                    // Check if post title changed
                    if ($existing_post->post_title !== $member['Account_Name']) {
                        $needs_update = true;
                    }

                    if ($needs_update) {
                        // Update existing member - preserve current status
                        $member_data = [
                            'ID' => $existing_post->ID,
                            'post_title' => $member['Account_Name'],
                            'post_modified' => current_time('mysql'),
                            'post_status' => $existing_post->post_status
                        ];
                        $post_id = wp_update_post($member_data);
                        if ($post_id) {
                            $sync_stats['updated']++;
                        } else {
                            $sync_stats['failed']++;
                        }
                    } else {
                        // No post update needed, but we still need the post ID for meta updates
                        $post_id = $existing_post->ID;
                    }
                }

                if ($post_id) {
                    // Format CEO name from first and last name if available
                    $ceo_name = '';
                    if (!empty($member['CEO_First_Name']) || !empty($member['CEO_Last_Name'])) {
                        $ceo_name = trim($member['CEO_First_Name'] . ' ' . $member['CEO_Last_Name']);
                    }

                    // Get stored country data with flags
                    $all_countries = get_option('gsf_zoho_countries', []);

                    // Filter countries of operation to only include those with Flag: Show
                    $countries_of_operation = [];
                    if (!empty($member['Countries_of_Operation']) && is_array($member['Countries_of_Operation'])) {
                        foreach ($member['Countries_of_Operation'] as $country_name) {
                            $country_name = $this->normaliseCountryName($country_name);
                            // Only include the country if it exists in our country data AND has flag set to Show
                            if (
                                isset($all_countries[$country_name]) &&
                                isset($all_countries[$country_name]['flag']) &&
                                strtolower($all_countries[$country_name]['flag']) === 'show'
                            ) {
                                $countries_of_operation[] = $country_name;
                            }
                        }
                    }

                    $new_meta_fields = [
                        'zoho_id' => $member['id'],
                        'organisation_name' => $member['Account_Name'],
                        'email' => $member['Email'],
                        'country' => $member['Location_of_HQ_Country'],
                        'countries_of_operation' => $countries_of_operation,
                        'organisation_type' => $member['Type_of_Organisation'],
                        'website' => $member['Website'],
                        'ceo_name' => $ceo_name,
                        'ceo_email' => $member['Email_of_CEO'],
                        'account_type' => $member['Account_Type'],
                        'lifecycle_status' => $member['Lifecycle_Status'],
                        'last_sync' => current_time('mysql'),
                        'Org_logo_URL' => $member['Org_logo_URL'] ?? '',
                        'Record_image_URL' => $member['Record_image_URL'] ?? '',
                        'Education_levels' => !empty($member['Education_levels']) && is_array($member['Education_levels']) ? $member['Education_levels'] : [],
                        'Do_programs_focus_on_key_emerging_existing_themes' => !empty($member['Do_programs_focus_on_key_emerging_existing_themes']) && is_array($member['Do_programs_focus_on_key_emerging_existing_themes']) ? $member['Do_programs_focus_on_key_emerging_existing_themes'] : [],
                        'Services_provided_to_partner_schools' => !empty($member['Services_provided_to_partner_schools']) && is_array($member['Services_provided_to_partner_schools']) ? $member['Services_provided_to_partner_schools'] : []
                    ];

                    // For existing members, check if meta fields actually changed before updating
                    $meta_updated = false;
                    if (!empty($existing_member)) {
                        foreach ($new_meta_fields as $key => $new_value) {
                            // Skip last_sync from change detection (it always changes)
                            if ($key === 'last_sync') {
                                update_post_meta($post_id, $key, $new_value);
                                continue;
                            }

                            $existing_value = get_post_meta($post_id, $key, true);

                            // Normalize empty values for comparison
                            $new_value_normalized = $new_value === null ? '' : $new_value;
                            $existing_value_normalized = $existing_value === null ? '' : $existing_value;

                            // Handle array comparison properly
                            if (is_array($new_value_normalized) && is_array($existing_value_normalized)) {
                                // Sort arrays to ensure consistent comparison
                                sort($new_value_normalized);
                                sort($existing_value_normalized);

                                if ($new_value_normalized !== $existing_value_normalized) {
                                    update_post_meta($post_id, $key, $new_value);
                                    $meta_updated = true;
                                    $this->logger->log('Meta field changed', 'DEBUG', [
                                        'member_id' => $member['id'],
                                        'field' => $key,
                                        'old' => $existing_value_normalized,
                                        'new' => $new_value_normalized
                                    ]);
                                }
                            } elseif ($existing_value_normalized !== $new_value_normalized) {
                                update_post_meta($post_id, $key, $new_value);
                                $meta_updated = true;
                                $this->logger->log('Meta field changed', 'DEBUG', [
                                    'member_id' => $member['id'],
                                    'field' => $key,
                                    'old' => $existing_value_normalized,
                                    'new' => $new_value_normalized
                                ]);
                            }
                        }

                        // If meta was updated but post wasn't, count it as an update
                        if ($meta_updated && !$post_updated) {
                            $sync_stats['updated']++;
                        } elseif ($post_updated) {
                            $sync_stats['updated']++;
                        }
                    } else {
                        // New member - update all meta fields
                        foreach ($new_meta_fields as $key => $value) {
                            update_post_meta($post_id, $key, $value);
                        }
                    }
                }
            } catch (Exception $e) {
                $sync_stats['failed']++;
                $this->logger->log('Member sync failed', 'ERROR', [
                    'member' => $member['Organisation_name'],
                    'error' => $e->getMessage()
                ]);
            }
        }

        // Update global sync timestamp
        update_option('gsf_zoho_last_sync', time());
        $this->lastSyncTime = time();
        gsf_clear_community_stats_cache();

        // Store sync stats for retrieval by other parts of the system
        update_option('gsf_last_sync_stats', $sync_stats);

        $this->logger->log('Member sync completed', 'INFO', $sync_stats);
    }

    public function getMembers($page = 1, $perPage = 200, $filters = [], $forceSync = false)
    {
        $this->logger->log('Fetching members', 'INFO', [
            'page' => $page,
            'perPage' => $perPage,
            'filters' => $filters,
            'forceSync' => $forceSync
        ]);

        // Enhanced rate limiting logic
        $shouldSync = false;
        if ($forceSync) {
            // For manual syncs, check if we haven't synced in the last 30 seconds to prevent spam
            $last_manual_sync = get_option('gsf_zoho_last_manual_sync', 0);
            if (time() - $last_manual_sync > 30) {
                $shouldSync = true;
                update_option('gsf_zoho_last_manual_sync', time());
                $this->logger->log('Manual sync allowed', 'INFO', [
                    'seconds_since_last_manual' => time() - $last_manual_sync
                ]);
            } else {
                $this->logger->log('Manual sync rate limited', 'WARNING', [
                    'seconds_since_last_manual' => time() - $last_manual_sync,
                    'wait_seconds' => 30 - (time() - $last_manual_sync)
                ]);
            }
        } else {
            // For automatic syncs, use the normal interval
            $shouldSync = !$this->lastSyncTime || (time() - $this->lastSyncTime) > $this->syncInterval;
        }

        $deleted_count = 0;
        if ($shouldSync) {
            $deleted_count = $this->syncWithZoho();
        } else {
            $this->logger->log('Sync not required', 'DEBUG', [
                'last_sync_time' => $this->lastSyncTime ? date('Y-m-d H:i:s', $this->lastSyncTime) : 'never',
                'time_since_sync' => $this->lastSyncTime ? time() - $this->lastSyncTime : 'never',
                'sync_interval' => $this->syncInterval
            ]);
        }

        // Query WordPress for members
        $query_args = [
            'post_type' => 'gsf_member',
            'posts_per_page' => $perPage,
            'paged' => $page,
            'post_status' => 'publish',
            'orderby' => 'title',
            'order' => 'ASC',
            'meta_query' => []
        ];

        // Apply filters
        if (!empty($filters['search'])) {
            $query_args['s'] = $filters['search'];
        }

        if (!empty($filters['country'])) {
            // ONLY search in countries_of_operation, not in the primary country field
            $query_args['meta_query'][] = [
                'key' => 'countries_of_operation',
                'value' => serialize($filters['country']),
                'compare' => 'LIKE'
            ];
        }

        if (!empty($filters['organization_type'])) {
            $types = array_map('trim', explode(',', $filters['organization_type']));
            // Prepend `Member - ` to each type
            $types = array_map(function ($type) {
                return trim('Member – ' . $type);
            }, $types);

            $query_args['meta_query'][] = [
                'key' => 'account_type',
                'value' => $types,
                'compare' => 'IN'
            ];
        }

        if (!empty($filters['focus_areas'])) {
            $focus_areas = array_map('trim', explode(',', $filters['focus_areas'])); //arr of l_c fas

            $meta_query = ['relation' => 'OR'];

            foreach ($focus_areas as $fa) {
                $human_value = ucwords(str_replace('_', ' ', $fa));

                $meta_query[] = [
                    'key' => 'Do_programs_focus_on_key_emerging_existing_themes',
                    'value' => $human_value,
                    'compare' => 'LIKE'
                ];

                $meta_query[] = [
                    'key' => 'Services_provided_to_partner_schools',
                    'value' => $human_value,
                    'compare' => 'LIKE'
                ];
            }

            $query_args['meta_query'][] = $meta_query;
        }


        if (count($query_args['meta_query']) > 1) {
            $query_args['meta_query']['relation'] = 'AND';
        }

        $query = new WP_Query($query_args);
        $members = [];

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $countries_of_operation = get_post_meta(get_the_ID(), 'countries_of_operation', true);
                if (!is_array($countries_of_operation)) {
                    $countries_of_operation = [];
                }

                $members[] = [
                    'Organisation_name' => html_entity_decode(get_the_title(), ENT_QUOTES, 'UTF-8'),  // Used by the frontend
                    'Account_Name' => get_the_title(),       // Used for Zoho sync
                    'Country' => get_post_meta(get_the_ID(), 'country', true),
                    'Type_of_Organisation' => get_post_meta(get_the_ID(), 'organisation_type', true),
                    'Email' => get_post_meta(get_the_ID(), 'email', true),
                    'Website' => get_post_meta(get_the_ID(), 'website', true),
                    'Countries_of_Operation' => $countries_of_operation,
                    'Account_Type' => get_post_meta(get_the_ID(), 'account_type', true),
                    'Org_logo_URL' => get_post_meta(get_the_ID(), 'Org_logo_URL', true),
                    'Record_image_URL' => get_post_meta(get_the_ID(), 'Record_image_URL', true),
                    'Education_levels' => get_post_meta(get_the_ID(), 'Education_levels', true),
                    'Do_programs_focus_on_key_emerging_existing_themes' => get_post_meta(get_the_ID(), 'Do_programs_focus_on_key_emerging_existing_themes', true),
                    'Services_provided_to_partner_schools' => get_post_meta(get_the_ID(), 'Services_provided_to_partner_schools', true)
                ];
            }
            wp_reset_postdata();
        }

        return [
            'members' => $members,
            'total' => $query->found_posts,
            'deleted_count' => isset($deleted_count) ? $deleted_count : 0,
            'sync_stats' => get_option('gsf_last_sync_stats', [
                'created' => 0,
                'updated' => 0,
                'failed' => 0
            ])
        ];
    }

    /**
     * Normalise country names that Zoho stores inconsistently against the Countries1 module.
     * Shares the same override list used by the map (see gsf_get_country_name_overrides())
     * so sync-time filtering and map counting never drift out of sync.
     */
    private function normaliseCountryName($name)
    {
        return gsf_normalize_country_name($name);
    }

    // [ICONNECT 2026-07-09] getMemberSearchCriteria() built the Zoho search
    // criteria string. The iConnect /api/public/gsf-map/members endpoint
    // already returns ONLY current members of the two member account types, so
    // this filtering now happens server-side in iConnect and the method is no
    // longer called from anywhere.
    // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
    // Kept for review -- safe to delete once the iConnect switch-over is verified.
    // -------------------------------------------------------------------------------
    // /**
     // * Zoho Accounts search criteria for member sync.
     // * Lifecycle applies to both member account types (grouped OR, not the old bug
     // * where School operators bypassed lifecycle).
     // */
    // private function getMemberSearchCriteria()
    // {
        // $lifecycle_statuses = apply_filters('gsf_member_sync_lifecycle_statuses', ['Current']);
        // $account_type_criteria = '((Account_Type:equals:Member – Education Support Organisations)or(Account_Type:equals:Member – School and ECED Operators))';
    //
        // if (count($lifecycle_statuses) === 1) {
            // $lifecycle_criteria = '(Lifecycle_Status:equals:' . $lifecycle_statuses[0] . ')';
        // } else {
            // $lifecycle_criteria = '(Lifecycle_Status:in:' . implode(',', $lifecycle_statuses) . ')';
        // }
    //
        // return '(' . $lifecycle_criteria . 'and' . $account_type_criteria . ')';
    // }
    // ==================== END ORIGINAL ZOHO CODE ===================================

    /**
     * Fetch all member accounts from Zoho using paginated search.
     *
     * @return array{members: array, pages_fetched: int}|null Null on API failure.
     */
    // [ICONNECT 2026-07-09] Method name kept so no callers change. Members now
    // come from iConnect instead of Zoho CRM.
    private function fetchAllMembersFromZoho()
    {
        // [ICONNECT 2026-07-09] GET {base}/api/public/gsf-map/members with an
        // X-Api-Key header. The endpoint returns a bare JSON array of member
        // records byte-compatible with the Zoho Accounts payload (same field
        // names, same 'id' values) and already filtered to current members, so
        // the Zoho criteria search, the pagination loop and the
        // $body['data'] / $body['info']['more_records'] handling below are no
        // longer needed. The return shape ({members, pages_fetched}) is
        // unchanged so syncWithZoho() and countZohoMembers() are untouched.
        $members = $this->fetchIconnectCollection('/api/public/gsf-map/members', 'members');
        if ($members === null) {
            return null;
        }

        // Preserve the original de-duplication-by-id behaviour.
        $allMembersById = [];
        foreach ($members as $member) {
            if (!empty($member['id'])) {
                $allMembersById[$member['id']] = $member;
            }
        }

        if (empty($allMembersById)) {
            $this->logger->log('No members returned from iConnect', 'WARNING');
            return null;
        }

        return [
            'members' => array_values($allMembersById),
            'pages_fetched' => 1, // iConnect returns everything in one response
        ];

        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $criteria = $this->getMemberSearchCriteria();
        // $baseUrl = 'https://www.zohoapis.eu/crm/v2/Accounts/search';
        // $perPage = 200;
        // $page = 1;
        // $hasMorePages = true;
        // $allMembersById = [];
        //
        // while ($hasMorePages) {
            // $queryArgs = http_build_query([
                // 'criteria' => $criteria,
                // 'page' => $page,
                // 'per_page' => $perPage
            // ]);
            // $url = $baseUrl . '?' . $queryArgs;
        //
            // $this->logger->log('Fetching members page from Zoho', 'DEBUG', [
                // 'page' => $page,
                // 'per_page' => $perPage,
                // 'url' => $url
            // ]);
        //
            // $response = wp_remote_get($url, [
                // 'headers' => [
                    // 'Authorization' => 'Zoho-oauthtoken ' . $this->accessToken,
                    // 'Content-Type' => 'application/json'
                // ],
                // 'timeout' => 30
            // ]);
        //
            // if (is_wp_error($response)) {
                // $this->logger->log('Zoho API request failed', 'ERROR', [
                    // 'error' => $response->get_error_message(),
                    // 'page' => $page
                // ]);
                // return null;
            // }
        //
            // $response_code = wp_remote_retrieve_response_code($response);
            // $body = json_decode(wp_remote_retrieve_body($response), true);
        //
            // if ($response_code === 429) {
                // $this->logger->log('Zoho API rate limit exceeded', 'ERROR', [
                    // 'response_code' => $response_code,
                    // 'response' => $body,
                    // 'page' => $page
                // ]);
                // return null;
            // } elseif ($response_code === 401) {
                // $this->logger->log('Zoho API authentication failed, clearing cached tokens', 'ERROR', [
                    // 'response_code' => $response_code,
                    // 'page' => $page
                // ]);
                // delete_option('gsf_zoho_access_token');
                // delete_option('gsf_zoho_token_expiry');
                // $this->accessToken = null;
                // $this->tokenExpiry = 0;
                // $this->maybeRefreshToken();
                // return null;
            // } elseif ($response_code !== 200) {
                // $this->logger->log('Zoho API returned non-200 status', 'ERROR', [
                    // 'response_code' => $response_code,
                    // 'response' => $body,
                    // 'page' => $page
                // ]);
                // return null;
            // }
        //
            // if (isset($body['data']) && is_array($body['data']) && count($body['data']) > 0) {
                // foreach ($body['data'] as $member) {
                    // if (!empty($member['id'])) {
                        // $allMembersById[$member['id']] = $member;
                    // }
                // }
        //
                // if (isset($body['info']['more_records'])) {
                    // if ($body['info']['more_records']) {
                        // $page++;
                    // } else {
                        // $hasMorePages = false;
                    // }
                // } elseif (count($body['data']) < $perPage) {
                    // $hasMorePages = false;
                // } else {
                    // $page++;
                // }
            // } else {
                // $hasMorePages = false;
        //
                // if ($page === 1) {
                    // $this->logger->log('No members returned from Zoho', 'WARNING', [
                        // 'response' => $body
                    // ]);
                    // return null;
                // }
            // }
        // }
        //
        // return [
            // 'members' => array_values($allMembersById),
            // 'pages_fetched' => $page,
        // ];
        // ==================== END ORIGINAL ZOHO CODE ===================================
    }

    private function syncWithZoho()
    {
        $this->logger->log('Sync required, fetching all members from Zoho', 'INFO');
        // [ICONNECT 2026-07-09] No token refresh needed for iConnect (no-op anyway).
        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->maybeRefreshToken();
        // ==================== END ORIGINAL ZOHO CODE ===================================

        // Check if we need to sync countries
        $shouldSyncCountries = !$this->lastCountrySyncTime || (time() - $this->lastCountrySyncTime) > $this->countrySyncInterval;
        if ($shouldSyncCountries) {
            $this->syncCountriesFromZoho();
        }

        $fetchResult = $this->fetchAllMembersFromZoho();
        if ($fetchResult === null) {
            return 0;
        }

        $allMembers = $fetchResult['members'];
        $pagesFetched = $fetchResult['pages_fetched'];

        if (empty($allMembers)) {
            $this->logger->log('No members to sync from Zoho', 'WARNING');
            return 0;
        }

        $current_zoho_ids = array_map(function ($member) {
            return $member['id'];
        }, $allMembers);

        $stale_members = get_posts([
            'post_type' => 'gsf_member',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                [
                    'key' => 'zoho_id',
                    'value' => $current_zoho_ids,
                    'compare' => 'NOT IN'
                ]
            ]
        ]);

        $orphan_members = get_posts([
            'post_type' => 'gsf_member',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                'relation' => 'OR',
                [
                    'key' => 'zoho_id',
                    'compare' => 'NOT EXISTS',
                ],
                [
                    'key' => 'zoho_id',
                    'value' => '',
                    'compare' => '=',
                ],
            ],
        ]);

        $posts_to_delete = array_unique(array_merge($stale_members, $orphan_members));

        $deleted_count = 0;
        foreach ($posts_to_delete as $post_id) {
            wp_delete_post($post_id, true);
            $deleted_count++;
        }

        if ($deleted_count > 0) {
            $this->logger->log('Removed stale or orphan member records', 'INFO', [
                'deleted_count' => $deleted_count,
                'stale_count' => count($stale_members),
                'orphan_count' => count($orphan_members),
            ]);
        }

        $this->syncMembersToWordPress($allMembers);

        $this->logger->log('Member sync from Zoho completed', 'INFO', [
            'total_members_fetched' => count($allMembers),
            'pages_fetched' => $pagesFetched,
            'deleted_count' => $deleted_count
        ]);

        return $deleted_count;
    }

    /**
     * Sync countries data from Zoho
     */
    // [ICONNECT 2026-07-09] Method name kept so no callers change. Countries now
    // come from iConnect instead of the Zoho Countries1 module.
    private function syncCountriesFromZoho()
    {
        // [ICONNECT 2026-07-09] GET {base}/api/public/gsf-map/countries with an
        // X-Api-Key header. The endpoint returns a bare JSON array in a single
        // response (no pagination), and each row has exactly the same shape as
        // a Zoho Countries1 record (Country.name, Country.id, Income_Group,
        // GSF_Region_Classification, Flag), so the per-row field mapping below
        // is preserved VERBATIM from the original code. The option keys
        // (gsf_zoho_countries, gsf_zoho_last_country_sync) are intentionally
        // unchanged so everything downstream keeps working.
        $this->logger->log('Fetching countries from iConnect', 'INFO');

        $rows = $this->fetchIconnectCollection('/api/public/gsf-map/countries', 'countries');
        if ($rows === null) {
            return false;
        }

        $countries = [];
        foreach ($rows as $country_data) {
            if (isset($country_data['Country']['name'])) {
                $country_name = $country_data['Country']['name'];
                $countries[$country_name] = [
                    'id' => $country_data['id'],
                    'zoho_country_id' => $country_data['Country']['id'],
                    'income_group' => $country_data['Income_Group'] ?? '',
                    'region' => $country_data['GSF_Region_Classification'] ?? '',
                    'flag' => $country_data['Flag'] ?? ''
                ];
            }
        }

        if (empty($countries)) {
            $this->logger->log('iConnect countries endpoint returned no usable rows', 'ERROR');
            return false;
        }

        // Save countries to an option (same option keys as before)
        update_option('gsf_zoho_countries', $countries);
        update_option('gsf_zoho_last_country_sync', time());
        $this->lastCountrySyncTime = time();

        $this->logger->log('Countries sync completed', 'INFO', [
            'count' => count($countries),
            'pages_fetched' => 1 // iConnect returns everything in one response
        ]);

        return true;

        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->logger->log('Fetching countries from Zoho', 'INFO');
        // $this->maybeRefreshToken();
        //
        // $countries = [];
        // $page = 1;
        // $perPage = 200;
        // $hasMorePages = true;
        //
        // while ($hasMorePages) {
            // $url = 'https://www.zohoapis.eu/crm/v2/Countries1?per_page=' . $perPage . '&page=' . $page;
        //
            // $this->logger->log('Fetching countries page', 'DEBUG', [
                // 'page' => $page,
                // 'per_page' => $perPage
            // ]);
        //
            // $response = wp_remote_get($url, [
                // 'headers' => [
                    // 'Authorization' => 'Zoho-oauthtoken ' . $this->accessToken,
                    // 'Content-Type' => 'application/json'
                // ],
                // 'timeout' => 30
            // ]);
        //
            // if (is_wp_error($response)) {
                // $this->logger->log('Countries API request failed', 'ERROR', [
                    // 'error' => $response->get_error_message(),
                    // 'page' => $page
                // ]);
                // return false;
            // }
        //
            // $body = json_decode(wp_remote_retrieve_body($response), true);
        //
            // if (isset($body['data']) && is_array($body['data']) && count($body['data']) > 0) {
                // foreach ($body['data'] as $country_data) {
                    // if (isset($country_data['Country']['name'])) {
                        // $country_name = $country_data['Country']['name'];
                        // $countries[$country_name] = [
                            // 'id' => $country_data['id'],
                            // 'zoho_country_id' => $country_data['Country']['id'],
                            // 'income_group' => $country_data['Income_Group'] ?? '',
                            // 'region' => $country_data['GSF_Region_Classification'] ?? '',
                            // 'flag' => $country_data['Flag'] ?? ''
                        // ];
                    // }
                // }
        //
                // // Check if there are more pages
                // if (count($body['data']) < $perPage) {
                    // // This was the last page
                    // $hasMorePages = false;
                // } else {
                    // // Move to next page
                    // $page++;
                // }
            // } else {
                // // No more data
                // $hasMorePages = false;
        //
                // if ($page === 1) {
                    // // No data on first page - likely an error
                    // $this->logger->log('Invalid response from Zoho Countries API', 'ERROR', [
                        // 'response' => $body
                    // ]);
                    // return false;
                // }
            // }
        // }
        //
        // // Save countries to an option
        // update_option('gsf_zoho_countries', $countries);
        // update_option('gsf_zoho_last_country_sync', time());
        // $this->lastCountrySyncTime = time();
        //
        // $this->logger->log('Countries sync completed', 'INFO', [
            // 'count' => count($countries),
            // 'pages_fetched' => $page
        // ]);
        //
        // return true;
        // ==================== END ORIGINAL ZOHO CODE ===================================
    }

    /**
     * Return total member accounts matching sync criteria (all pages).
     *
     * @return int|null Member count, or null if the Zoho API request failed.
     */
    public function countZohoMembers()
    {
        // [ICONNECT 2026-07-09] No token refresh needed for iConnect (no-op anyway).
        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->maybeRefreshToken();
        // ==================== END ORIGINAL ZOHO CODE ===================================
        $fetchResult = $this->fetchAllMembersFromZoho();

        return $fetchResult === null ? null : count($fetchResult['members']);
    }

    // [ICONNECT 2026-07-09] Debug fetch repointed at the two iConnect endpoints so
    // the plugin's debug path no longer hits Zoho. The return shape is kept
    // compatible with the original (success / raw_data / member_count /
    // country_data / all_countries / country_count / country_pages_fetched);
    // raw_data emulates the old Zoho envelope by slicing the requested page out
    // of the full member list.
    public function testGetZohoData($page = 1, $perPage = 10)
    {
        $this->logger->log('TESTING: Fetching raw iConnect data for debugging', 'INFO');

        $members = $this->fetchIconnectCollection('/api/public/gsf-map/members', 'members (debug)');
        if ($members === null) {
            return [
                'success' => false,
                'error' => 'iConnect members request failed - see the GSF log for details'
            ];
        }

        // Emulate the old paged Zoho debug view for backward compatibility.
        $offset = max(0, ($page - 1) * $perPage);
        $pageSlice = array_slice($members, $offset, $perPage);
        $rawData = [
            'data' => $pageSlice,
            'info' => [
                'more_records' => ($offset + $perPage) < count($members)
            ]
        ];

        $allCountries = $this->fetchIconnectCollection('/api/public/gsf-map/countries', 'countries (debug)');
        if ($allCountries === null) {
            $allCountries = [];
        }

        $this->logger->log('Raw iConnect debug data received', 'DEBUG', [
            'member_count_total' => count($members),
            'country_count' => count($allCountries)
        ]);

        return [
            'success' => true,
            'raw_data' => $rawData,
            'member_count' => count($pageSlice),
            'country_data' => ['data' => $allCountries], // first-page equivalent
            'all_countries' => $allCountries,
            'country_count' => count($allCountries),
            'country_pages_fetched' => 1
        ];

        // ==================== ORIGINAL ZOHO CODE (disabled 2026-07-09) ====================
        // Kept for review -- safe to delete once the iConnect switch-over is verified.
        // -------------------------------------------------------------------------------
        // $this->logger->log('TESTING: Fetching raw Zoho data for debugging', 'INFO');
        // $this->maybeRefreshToken();
        //
        // $criteria = $this->getMemberSearchCriteria();
        // $baseUrl = 'https://www.zohoapis.eu/crm/v2/Accounts/search';
        // $queryArgs = http_build_query([
            // 'criteria' => $criteria,
            // 'page' => $page,
            // 'per_page' => $perPage
        // ]);
        // $url = $baseUrl . '?' . $queryArgs;
        //
        // $this->logger->log('Making Zoho API debug request for members', 'DEBUG', [
            // 'url' => $url
        // ]);
        //
        // $response = wp_remote_get($url, [
            // 'headers' => [
                // 'Authorization' => 'Zoho-oauthtoken ' . $this->accessToken,
                // 'Content-Type' => 'application/json'
            // ]
        // ]);
        //
        // if (is_wp_error($response)) {
            // $this->logger->log('Zoho API debug request failed', 'ERROR', [
                // 'error' => $response->get_error_message()
            // ]);
            // return [
                // 'success' => false,
                // 'error' => $response->get_error_message()
            // ];
        // }
        //
        // $body = json_decode(wp_remote_retrieve_body($response), true);
        // $this->logger->log('Raw Zoho API response received', 'DEBUG');
        // $this->logger->log('Raw response data', 'DEBUG', [
            // 'response' => $body
        // ]);
        //
        // // Also fetch countries data for debugging - paginate through all pages
        // $countryData = [];
        // $allCountries = [];
        // $countryPage = 1;
        // $countryPerPage = 200;
        // $hasMoreCountryPages = true;
        //
        // while ($hasMoreCountryPages) {
            // $countryUrl = 'https://www.zohoapis.eu/crm/v2/Countries1?per_page=' . $countryPerPage . '&page=' . $countryPage;
            // $countryResponse = wp_remote_get($countryUrl, [
                // 'headers' => [
                    // 'Authorization' => 'Zoho-oauthtoken ' . $this->accessToken,
                    // 'Content-Type' => 'application/json'
                // ],
                // 'timeout' => 30
            // ]);
        //
            // if (!is_wp_error($countryResponse)) {
                // $countryBody = json_decode(wp_remote_retrieve_body($countryResponse), true);
        //
                // if ($countryPage === 1) {
                    // $countryData = $countryBody; // Store first page for backward compatibility
                // }
        //
                // if (isset($countryBody['data']) && is_array($countryBody['data']) && count($countryBody['data']) > 0) {
                    // $allCountries = array_merge($allCountries, $countryBody['data']);
        //
                    // if (count($countryBody['data']) < $countryPerPage) {
                        // $hasMoreCountryPages = false;
                    // } else {
                        // $countryPage++;
                    // }
                // } else {
                    // $hasMoreCountryPages = false;
                // }
        //
                // $this->logger->log('Countries API data received', 'DEBUG', [
                    // 'page' => $countryPage,
                    // 'count_this_page' => isset($countryBody['data']) ? count($countryBody['data']) : 0
                // ]);
            // } else {
                // $this->logger->log('Countries API request failed', 'ERROR', [
                    // 'error' => $countryResponse->get_error_message(),
                    // 'page' => $countryPage
                // ]);
                // $hasMoreCountryPages = false;
            // }
        // }
        //
        // // Return the raw response data
        // return [
            // 'success' => true,
            // 'raw_data' => $body,
            // 'member_count' => isset($body['data']) ? count($body['data']) : 0,
            // 'country_data' => $countryData,
            // 'all_countries' => $allCountries,
            // 'country_count' => count($allCountries),
            // 'country_pages_fetched' => $countryPage
        // ];
        // ==================== END ORIGINAL ZOHO CODE ===================================
    }

    // [ICONNECT 2026-07-09] getCountries() below is untouched: it still reads the
    // gsf_zoho_countries option (name kept for compatibility), which is now
    // populated from iConnect by syncCountriesFromZoho() above.
    /**
     * Get all countries from Zoho data that has been synced
     * 
     * @return array Array of country information
     */
    public function getCountries()
    {
        // If test data is enabled, return test country data
        if (get_option('gsf_use_test_data', false)) {
            return $this->getTestCountryData();
        }

        $countries = get_option('gsf_zoho_countries', []);

        // Force sync if we don't have countries or it's time for a sync
        if (empty($countries) || !$this->lastCountrySyncTime || (time() - $this->lastCountrySyncTime) > $this->countrySyncInterval) {
            $this->syncCountriesFromZoho();
            $countries = get_option('gsf_zoho_countries', []);
        }

        return $countries;
    }

    /**
     * Generate test country data for use in test mode
     * 
     * @return array Test country data
     */
    private function getTestCountryData()
    {
        $test_countries = [
            'Afghanistan' => [
                'id' => '1001',
                'zoho_country_id' => '2001',
                'income_group' => 'Low Income',
                'region' => 'Asia',
                'flag' => 'Show'
            ],
            'Albania' => [
                'id' => '1002',
                'zoho_country_id' => '2002',
                'income_group' => 'Upper Middle Income',
                'region' => 'Europe',
                'flag' => 'Show'
            ],
            'Algeria' => [
                'id' => '1003',
                'zoho_country_id' => '2003',
                'income_group' => 'Lower Middle Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'India' => [
                'id' => '1004',
                'zoho_country_id' => '2004',
                'income_group' => 'Lower Middle Income',
                'region' => 'Asia',
                'flag' => 'Show'
            ],
            'Kenya' => [
                'id' => '1005',
                'zoho_country_id' => '2005',
                'income_group' => 'Lower Middle Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Nigeria' => [
                'id' => '1006',
                'zoho_country_id' => '2006',
                'income_group' => 'Lower Middle Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Bangladesh' => [
                'id' => '1007',
                'zoho_country_id' => '2007',
                'income_group' => 'Lower Middle Income',
                'region' => 'Asia',
                'flag' => 'Show'
            ],
            'Nepal' => [
                'id' => '1008',
                'zoho_country_id' => '2008',
                'income_group' => 'Low Income',
                'region' => 'Asia',
                'flag' => 'Show'
            ],
            'Ethiopia' => [
                'id' => '1009',
                'zoho_country_id' => '2009',
                'income_group' => 'Low Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Brazil' => [
                'id' => '1010',
                'zoho_country_id' => '2010',
                'income_group' => 'Upper Middle Income',
                'region' => 'South America',
                'flag' => 'Show'
            ],
            'Mexico' => [
                'id' => '1011',
                'zoho_country_id' => '2011',
                'income_group' => 'Upper Middle Income',
                'region' => 'North America',
                'flag' => 'Show'
            ],
            'United States' => [
                'id' => '1012',
                'zoho_country_id' => '2012',
                'income_group' => 'High Income',
                'region' => 'North America',
                'flag' => 'Show'
            ],
            'United Kingdom' => [
                'id' => '1013',
                'zoho_country_id' => '2013',
                'income_group' => 'High Income',
                'region' => 'Europe',
                'flag' => 'Show'
            ],
            'Somalia' => [
                'id' => '1014',
                'zoho_country_id' => '2014',
                'income_group' => 'Low Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Sudan' => [
                'id' => '1015',
                'zoho_country_id' => '2015',
                'income_group' => 'Low Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Colombia' => [
                'id' => '1016',
                'zoho_country_id' => '2016',
                'income_group' => 'Upper Middle Income',
                'region' => 'South America',
                'flag' => 'Show'
            ],
            'Argentina' => [
                'id' => '1017',
                'zoho_country_id' => '2017',
                'income_group' => 'Upper Middle Income',
                'region' => 'South America',
                'flag' => 'Show'
            ],
            'Andorra' => [
                'id' => '1018',
                'zoho_country_id' => '2018',
                'income_group' => 'High Income',
                'region' => 'Europe',
                'flag' => 'Hide', // Added Hide flag to test filtering
                'flag' => 'Hide'
            ],
            'Tanzania' => [
                'id' => '1019',
                'zoho_country_id' => '2019',
                'income_group' => 'Lower Middle Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Uganda' => [
                'id' => '1019',
                'zoho_country_id' => '2019',
                'income_group' => 'Low Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ],
            'Bhutan' => [
                'id' => '1020',
                'zoho_country_id' => '2020',
                'income_group' => 'Lower Middle Income',
                'region' => 'Asia',
                'flag' => 'Show'
            ],
            'Ghana' => [
                'id' => '1021',
                'zoho_country_id' => '2021',
                'income_group' => 'Lower Middle Income',
                'region' => 'Africa',
                'flag' => 'Show'
            ]
        ];

        return $test_countries;
    }

    // [ICONNECT 2026-07-09] The two debug helpers below (clearCachedTokens,
    // getTokenStatus) only touch the now-unused legacy Zoho token options.
    // They are harmless and kept as-is; clearCachedTokens() can be used once to
    // clean the stale Zoho tokens out of wp_options after the switch-over.
    /**
     * Clear cached Zoho tokens (useful for debugging)
     */
    public function clearCachedTokens()
    {
        delete_option('gsf_zoho_access_token');
        delete_option('gsf_zoho_token_expiry');
        delete_option('gsf_zoho_last_token_refresh');

        $this->accessToken = null;
        $this->tokenExpiry = 0;

        $this->logger->log('Cached Zoho tokens cleared', 'INFO');
    }

    /**
     * Get token status for debugging
     */
    public function getTokenStatus()
    {
        return [
            'access_token' => $this->accessToken ? substr($this->accessToken, 0, 20) . '...' : 'none',
            'token_expiry' => $this->tokenExpiry,
            'token_expiry_human' => $this->tokenExpiry ? wp_date('Y-m-d H:i:s', $this->tokenExpiry) : 'none',
            'expires_in_seconds' => $this->tokenExpiry ? max(0, $this->tokenExpiry - time()) : 0,
            'is_expired' => $this->tokenExpiry ? (time() > $this->tokenExpiry) : true,
            'last_sync' => $this->lastSyncTime ? wp_date('Y-m-d H:i:s', $this->lastSyncTime) : 'never',
            'last_token_refresh' => get_option('gsf_zoho_last_token_refresh', 0) ? wp_date('Y-m-d H:i:s', get_option('gsf_zoho_last_token_refresh', 0)) : 'never'
        ];
    }

    /**
     * Public method to trigger country synchronization from Zoho
     * 
     * @return boolean Success status
     */
    public function forceSyncCountries()
    {
        return $this->syncCountriesFromZoho();
    }
}


import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertCircle, Loader2, CheckCircle2, Send } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

import DynamicFormInput from "../components/forms/DynamicFormInput";

export default function FillForm() {
  const urlParams = new URLSearchParams(window.location.search);
  const formConfigId = urlParams.get('id');

  const [formData, setFormData] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});

  const { data: formConfig, isLoading, error } = useQuery({
    queryKey: ['formConfig', formConfigId],
    queryFn: async () => {
      if (!formConfigId) throw new Error('No form ID provided');
      const configs = await base44.entities.FormConfiguration.filter({ id: formConfigId });
      if (configs.length === 0) throw new Error('Form not found');
      return configs[0];
    },
    enabled: !!formConfigId,
  });

  const submitMutation = useMutation({
    mutationFn: async (data) => {
      // Extract applicant name and email
      let applicantName = '';
      let applicantEmail = '';

      // Try to find name field
      if (formConfig.form_structure?.fields) {
        const nameField = formConfig.form_structure.fields.find(f => f.type === 'name');
        if (nameField && data[`${nameField.name}_First`] && data[`${nameField.name}_Last`]) {
          applicantName = `${data[`${nameField.name}_First`]} ${data[`${nameField.name}_Last`]}`;
        }

        // Try to find email field
        const emailField = formConfig.form_structure.fields.find(f => f.type === 'email');
        if (emailField && data[emailField.name]) {
          applicantEmail = data[emailField.name];
        }
      }

      // Generate unique application ID
      const applicationUid = crypto.randomUUID();
      
      // Initialize agreements_status based on signature email fields
      const agreements_status = [];
      if (formConfig.form_structure?.fields) {
        // Check top-level fields
        for (const field of formConfig.form_structure.fields) {
          if (field.type === 'email' && field.is_signature_email === true) {
            agreements_status.push({
              signature_field_name: field.name,
              is_signed: false,
              signed_date: null,
              signed_by_email: null
            });
          }
          
          // Check subform fields
          if (field.type === 'subform' && field.subfields) {
            for (const subfield of field.subfields) {
              if (subfield.type === 'email' && subfield.is_signature_email === true) {
                agreements_status.push({
                  signature_field_name: subfield.name,
                  is_signed: false,
                  signed_date: null,
                  signed_by_email: null
                });
              }
            }
          }
        }
      }

      // Create submission
      const submissionData = {
        application_uid: applicationUid,
        form_config_id: formConfigId,
        applicant_name: applicantName || 'Unknown',
        applicant_email: applicantEmail || '',
        form_data: data,
        original_form_data: data,
        status: 'new'
      };
      
      if (agreements_status.length > 0) {
        submissionData.agreements_status = agreements_status;
      }
      
      return base44.entities.Submission.create(submissionData);
    },
    onSuccess: () => {
      setSubmitted(true);
      setFormData({});
      setValidationErrors({});
    },
  });

  const handleFieldChange = (fieldName, value) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
    // Clear validation error for this field
    if (validationErrors[fieldName]) {
      setValidationErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[fieldName];
        return newErrors;
      });
    }
  };

  const validateForm = () => {
    const errors = {};
    
    if (formConfig.form_structure?.fields) {
      formConfig.form_structure.fields.forEach(field => {
        if (field.visible !== false && field.required) {
          if (field.type === 'name') {
            // Check both first and last name
            if (!formData[`${field.name}_First`] || !formData[`${field.name}_Last`]) {
              errors[field.name] = 'This field is required';
            }
          } else if (field.type === 'address') {
            // Check required address sub-fields
            if (!formData[`${field.name}_address1`] || !formData[`${field.name}_city`] || !formData[`${field.name}_country`]) {
              errors[field.name] = 'Address Line 1, City, and Country are required';
            }
          } else {
            const value = formData[field.name];
            if (!value || (typeof value === 'string' && value.trim() === '')) {
              errors[field.name] = 'This field is required';
            }
          }
        }
      });
    }

    return errors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      // Scroll to first error
      const firstErrorField = Object.keys(errors)[0];
      const element = document.getElementById(`field-${firstErrorField}`);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }

    submitMutation.mutate(formData);
  };

  if (!formConfigId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            No form ID provided in URL. Please provide a valid form ID.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 p-4 md:p-8">
        <div className="max-w-3xl mx-auto space-y-6">
          <Skeleton className="h-16 w-full" />
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
              <Skeleton className="h-4 w-full mt-2" />
            </CardHeader>
            <CardContent className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (error || !formConfig) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            {error?.message || 'Form not found'}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!formConfig.form_structure || !formConfig.form_structure.fields) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 flex items-center justify-center p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            This form has not been configured yet. Please contact the administrator.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-2xl w-full shadow-2xl border-green-200">
          <CardContent className="pt-12 pb-12 text-center">
            <div className="mb-6 flex justify-center">
              <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-lg">
                <CheckCircle2 className="w-12 h-12 text-white" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Submission Successful!</h2>
            <p className="text-lg text-gray-600 mb-8">
              Thank you for your submission. Your application has been received and will be reviewed shortly.
            </p>
            <Button 
              onClick={() => setSubmitted(false)}
              variant="outline"
              className="gap-2"
            >
              Submit Another Response
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filter visible fields only
  const visibleFields = formConfig.form_structure.fields.filter(field => field.visible !== false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 p-4 md:p-8">
      <div className="max-w-3xl mx-auto space-y-6">
        <Card className="shadow-2xl border-0 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-blue-600 via-blue-700 to-blue-800"></div>
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <CardTitle className="text-2xl md:text-3xl">{formConfig.form_name}</CardTitle>
            <CardDescription className="text-blue-100 text-base mt-2">
              Please fill out all required fields marked with an asterisk (*)
            </CardDescription>
          </CardHeader>
        </Card>

        <form onSubmit={handleSubmit} className="space-y-4">
          <DynamicFormInput
            formStructure={{ ...formConfig.form_structure, fields: visibleFields }}
            formData={formData}
            onChange={handleFieldChange}
            validationErrors={validationErrors}
          />

          <Card className="shadow-lg border-0 overflow-hidden sticky bottom-4 bg-white/95 backdrop-blur-sm z-10">
            <CardContent className="p-4">
              <div className="flex justify-end gap-4">
                <Button
                  type="submit"
                  disabled={submitMutation.isPending}
                  size="lg"
                  className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg px-8"
                >
                  {submitMutation.isPending ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5" />
                      Submit Application
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {submitMutation.isError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Failed to submit form: {submitMutation.error.message}
              </AlertDescription>
            </Alert>
          )}
        </form>

        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Powered by iConnect Due Diligence System</p>
        </div>
      </div>
    </div>
  );
}

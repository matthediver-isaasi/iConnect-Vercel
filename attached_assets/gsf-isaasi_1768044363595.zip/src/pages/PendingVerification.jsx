import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { base44 } from "@/api/base44Client";
import { AlertCircle, Clock, LogOut } from "lucide-react";

export default function PendingVerification() {
  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 flex items-center justify-center p-6">
      <Card className="max-w-2xl w-full shadow-2xl">
        <CardHeader className="bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-t-lg">
          <div className="flex items-center gap-3">
            <Clock className="w-8 h-8" />
            <CardTitle className="text-2xl">Account Pending Verification</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-8 space-y-6">
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
            <div className="flex gap-3">
              <AlertCircle className="w-6 h-6 text-amber-600 flex-shrink-0 mt-1" />
              <div className="space-y-2">
                <p className="text-amber-900 font-semibold text-lg">
                  Your account is awaiting administrator approval
                </p>
                <p className="text-amber-800">
                  Thank you for registering. An administrator will review your account request shortly.
                  You will receive an email notification once your account has been verified and you can access the system.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <h3 className="font-semibold text-blue-900 mb-2">What happens next?</h3>
            <ol className="space-y-2 text-sm text-blue-800">
              <li className="flex gap-2">
                <span className="font-bold">1.</span>
                <span>An administrator will review your registration details</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold">2.</span>
                <span>You'll receive an email once your account is verified</span>
              </li>
              <li className="flex gap-2">
                <span className="font-bold">3.</span>
                <span>Log in again to access the full system</span>
              </li>
            </ol>
          </div>

          <div className="pt-4 border-t">
            <p className="text-sm text-gray-600 mb-4">
              If you have any questions or believe this is an error, please contact your system administrator.
            </p>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full gap-2"
            >
              <LogOut className="w-4 h-4" />
              Log Out
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Eye, FileText, Paperclip, FileSignature, Phone, Loader2, ChevronLeft, ChevronRight, ArrowLeft } from "lucide-react";
import { format } from "date-fns";

export default function FormSubmissions() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(25);

  const urlParams = new URLSearchParams(window.location.search);
  const formId = urlParams.get('formId');

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submissions = [], isLoading: submissionsLoading } = useQuery({
    queryKey: ['form-submissions', formId],
    queryFn: async () => {
      const result = await base44.entities.Submission.filter({ form_config_id: formId }, "-created_date");
      return result;
    },
    enabled: isAuthenticated === true && !!formId,
  });

  const { data: formConfig, isLoading: configLoading } = useQuery({
    queryKey: ['form-config', formId],
    queryFn: async () => {
      const configs = await base44.entities.FormConfiguration.filter({ id: formId });
      return configs[0];
    },
    enabled: isAuthenticated === true && !!formId,
  });

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, riskFilter, itemsPerPage]);

  if (isAuthenticated === null || submissionsLoading || configLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!formConfig) {
    return (
      <div className="p-6 md:p-8">
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-lg font-medium text-gray-900">Form not found</p>
            <Link to={createPageUrl('Submissions')}>
              <Button className="mt-4">Back to Submissions</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const filteredSubmissions = submissions.filter(sub => {
    const matchesSearch =
      (sub.applicant_name?.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (sub.applicant_email?.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === "all" || sub.status === statusFilter;
    const matchesRisk = riskFilter === "all" || sub.risk_level === riskFilter;
    return matchesSearch && matchesStatus && matchesRisk;
  });

  // Pagination calculations
  const totalItems = filteredSubmissions.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedSubmissions = filteredSubmissions.slice(startIndex, endIndex);

  // Helper function to get stage color and label
  const getStageDisplay = (submission) => {
    const stages = formConfig?.workflow_stages || [];
    const stage = stages.find(s => s.id === submission.status);

    if (stage) {
      return {
        label: stage.label,
        color: stage.color,
      };
    }

    const fallbackColors = {
      new: { label: "New", color: "#f97316" },
      in_review: { label: "In Review", color: "#a855f7" },
      verified: { label: "Verified", color: "#3b82f6" },
      approved: { label: "Approved", color: "#22c55e" },
      rejected: { label: "Rejected", color: "#ef4444" },
    };

    const fallback = fallbackColors[submission.status] || { label: submission.status.replace('_', ' '), color: "#6b7280" };
    return fallback;
  };

  const riskColors = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  const SubmissionRow = ({ sub }) => {
    const totalAttachments = sub.crm_attachments_status?.length || 0;
    const approvedAttachments = sub.crm_attachments_status?.filter(att => att.is_approved).length || 0;
    const hasCrmDocsConfigured = formConfig?.crm_attachment_config?.enabled === true;
    const showAttachmentBadge = totalAttachments > 0 || hasCrmDocsConfigured;
    const totalAgreements = sub.agreements_status?.length || 0;
    const signedAgreements = sub.agreements_status?.filter(ag => ag.is_signed).length || 0;
    const showSignatureBadge = totalAgreements > 0;
    const hasDdCallBooked = !!sub.dd_call_date;
    const stageDisplay = getStageDisplay(sub);
    
    // Get organization name from form_data
    const organizationField = formConfig?.applicant_organization_name_field;
    const organizationName = organizationField ? sub.form_data?.[organizationField] : null;

    return (
      <div className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className="font-semibold text-lg">{organizationName || sub.applicant_name || 'Unnamed Applicant'}</h3>
            <Badge style={{ backgroundColor: stageDisplay.color, color: '#ffffff', border: 'none' }}>
              {stageDisplay.label}
            </Badge>
            {sub.risk_level && (
              <Badge className={riskColors[sub.risk_level]}>
                {sub.risk_level} risk
              </Badge>
            )}
            {showAttachmentBadge && (
              <Badge
                className={
                  totalAttachments === 0 && hasCrmDocsConfigured
                    ? "bg-blue-100 text-blue-800 border-blue-300"
                    : approvedAttachments === totalAttachments && totalAttachments > 0
                    ? "bg-green-100 text-green-800 border-green-300"
                    : approvedAttachments > 0 && totalAttachments > 0
                    ? "bg-amber-100 text-amber-800 border-amber-300"
                    : totalAttachments > 0
                    ? "bg-gray-100 text-gray-800 border-gray-300"
                    : ""
                }
                variant="outline"
              >
                <Paperclip className="w-3 h-3 mr-1" />
                {totalAttachments > 0 ? `${approvedAttachments}/${totalAttachments} Docs` : 'CRM Docs'}
              </Badge>
            )}
            {showSignatureBadge && (
              <Badge
                className={
                  signedAgreements === totalAgreements
                    ? "bg-green-100 text-green-800 border-green-300"
                    : signedAgreements > 0
                    ? "bg-amber-100 text-amber-800 border-amber-300"
                    : "bg-gray-100 text-gray-800 border-gray-300"
                }
                variant="outline"
              >
                <FileSignature className="w-3 h-3 mr-1" />
                {signedAgreements}/{totalAgreements} Signed
              </Badge>
            )}
            {hasDdCallBooked && (
              <Badge className="bg-cyan-100 text-cyan-800 border-cyan-300" variant="outline">
                <Phone className="w-3 h-3 mr-1" />
                DD Call Booked
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>{sub.applicant_email || 'No email'}</span>
            <span>•</span>
            <span>Submitted {format(new Date(sub.created_date), 'MMM d, yyyy')}</span>
            {sub.due_diligence_score !== null && sub.due_diligence_score !== undefined && (
              <>
                <span>•</span>
                <span className="font-medium">Score: {sub.due_diligence_score}%</span>
              </>
            )}
          </div>
        </div>
        <Link to={createPageUrl(`ReviewSubmission?id=${sub.id}`)}>
          <Button variant="outline" size="sm" className="gap-2">
            <Eye className="w-4 h-4" />
            Review
          </Button>
        </Link>
      </div>
    );
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex items-center gap-4">
        <Link to={createPageUrl('Submissions')}>
          <Button variant="outline" size="icon">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{formConfig.form_name}</h1>
          <p className="text-gray-500 mt-1">
            {submissions.length} total submission{submissions.length !== 1 ? 's' : ''} 
            {filteredSubmissions.length !== submissions.length && (
              <span> • {filteredSubmissions.length} filtered</span>
            )}
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filter & Search</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {formConfig.workflow_stages?.map(stage => (
                  <SelectItem key={stage.id} value={stage.id}>
                    {stage.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={riskFilter} onValueChange={setRiskFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Risk Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Risk Levels</SelectItem>
                <SelectItem value="low">Low Risk</SelectItem>
                <SelectItem value="medium">Medium Risk</SelectItem>
                <SelectItem value="high">High Risk</SelectItem>
                <SelectItem value="critical">Critical Risk</SelectItem>
              </SelectContent>
            </Select>
            <Select value={itemsPerPage.toString()} onValueChange={(value) => setItemsPerPage(Number(value))}>
              <SelectTrigger className="w-[140px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">10 per page</SelectItem>
                <SelectItem value="25">25 per page</SelectItem>
                <SelectItem value="50">50 per page</SelectItem>
                <SelectItem value="100">100 per page</SelectItem>
                <SelectItem value="999999">Show All</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {paginatedSubmissions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-lg font-medium text-gray-900">No submissions found</p>
            <p className="text-sm text-gray-500 mt-1">
              {searchQuery || statusFilter !== "all" || riskFilter !== "all"
                ? "Try adjusting your filters"
                : "Submissions will appear here when this form is submitted"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardContent className="p-6">
              <div className="space-y-3">
                {paginatedSubmissions.map(sub => (
                  <SubmissionRow key={sub.id} sub={sub} />
                ))}
              </div>
            </CardContent>
          </Card>

          {totalPages > 1 && (
            <Card>
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    Showing {startIndex + 1} to {Math.min(endIndex, totalItems)} of {totalItems} results
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                      disabled={currentPage === 1}
                      className="gap-1"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>
                    
                    <div className="flex items-center gap-1">
                      {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                        let pageNum;
                        if (totalPages <= 5) {
                          pageNum = i + 1;
                        } else if (currentPage <= 3) {
                          pageNum = i + 1;
                        } else if (currentPage >= totalPages - 2) {
                          pageNum = totalPages - 4 + i;
                        } else {
                          pageNum = currentPage - 2 + i;
                        }
                        
                        return (
                          <Button
                            key={pageNum}
                            variant={currentPage === pageNum ? "default" : "outline"}
                            size="sm"
                            onClick={() => setCurrentPage(pageNum)}
                            className="w-9 h-9"
                          >
                            {pageNum}
                          </Button>
                        );
                      })}
                      {totalPages > 5 && currentPage < totalPages - 2 && (
                        <>
                          <span className="px-2 text-gray-500">...</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setCurrentPage(totalPages)}
                            className="w-9 h-9"
                          >
                            {totalPages}
                          </Button>
                        </>
                      )}
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                      disabled={currentPage === totalPages}
                      className="gap-1"
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

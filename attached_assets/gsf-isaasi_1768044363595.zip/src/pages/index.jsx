import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Submissions from "./Submissions";

import SyncForms from "./SyncForms";

import ReviewSubmission from "./ReviewSubmission";

import FillForm from "./FillForm";

import ConfigureScoring from "./ConfigureScoring";

import Scoring from "./Scoring";

import FormFields from "./FormFields";

import ManageSubmissions from "./ManageSubmissions";

import TestCrmAttachments from "./TestCrmAttachments";

import TestSignedAgreement from "./TestSignedAgreement";

import AddReferee from "./AddReferee";

import PendingVerification from "./PendingVerification";

import FormSubmissions from "./FormSubmissions";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Submissions: Submissions,
    
    SyncForms: SyncForms,
    
    ReviewSubmission: ReviewSubmission,
    
    FillForm: FillForm,
    
    ConfigureScoring: ConfigureScoring,
    
    Scoring: Scoring,
    
    FormFields: FormFields,
    
    ManageSubmissions: ManageSubmissions,
    
    TestCrmAttachments: TestCrmAttachments,
    
    TestSignedAgreement: TestSignedAgreement,
    
    AddReferee: AddReferee,
    
    PendingVerification: PendingVerification,
    
    FormSubmissions: FormSubmissions,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Submissions" element={<Submissions />} />
                
                <Route path="/SyncForms" element={<SyncForms />} />
                
                <Route path="/ReviewSubmission" element={<ReviewSubmission />} />
                
                <Route path="/FillForm" element={<FillForm />} />
                
                <Route path="/ConfigureScoring" element={<ConfigureScoring />} />
                
                <Route path="/Scoring" element={<Scoring />} />
                
                <Route path="/FormFields" element={<FormFields />} />
                
                <Route path="/ManageSubmissions" element={<ManageSubmissions />} />
                
                <Route path="/TestCrmAttachments" element={<TestCrmAttachments />} />
                
                <Route path="/TestSignedAgreement" element={<TestSignedAgreement />} />
                
                <Route path="/AddReferee" element={<AddReferee />} />
                
                <Route path="/PendingVerification" element={<PendingVerification />} />
                
                <Route path="/FormSubmissions" element={<FormSubmissions />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}

import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, AlertCircle, CheckCircle, Clock, TrendingUp, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submissions, isLoading } = useQuery({
    queryKey: ['submissions'],
    queryFn: () => base44.entities.Submission.list("-created_date"),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const { data: formConfigs, isLoading: configsLoading } = useQuery({
    queryKey: ['formConfigurations'],
    queryFn: () => base44.entities.FormConfiguration.list(),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }
  
  // Get all unique stage IDs across all forms
  const allStageIds = new Set();
  formConfigs.forEach(config => {
    config.workflow_stages?.forEach(stage => {
      allStageIds.add(stage.id);
    });
  });

  // Calculate stats dynamically based on all possible stages
  const stats = {
    total: submissions.length,
    byStage: {},
    highRisk: submissions.filter(s => s.risk_level === 'high' || s.risk_level === 'critical').length,
  };

  // Count submissions by stage
  submissions.forEach(sub => {
    if (sub.status) {
      stats.byStage[sub.status] = (stats.byStage[sub.status] || 0) + 1;
    }
  });

  // Helper to get stage display info
  const getStageDisplay = (stageId) => {
    // Look through all form configs to find this stage
    for (const config of formConfigs) {
      const stage = config.workflow_stages?.find(s => s.id === stageId);
      if (stage) {
        return {
          label: stage.label,
          color: stage.color,
          isInitial: stage.is_initial
        };
      }
    }
    
    // Fallback
    const fallbacks = {
      new: { label: "New", color: "#f97316", isInitial: true },
      in_review: { label: "In Review", color: "#a855f7", isInitial: false },
      verified: { label: "Verified", color: "#3b82f6", isInitial: false },
      approved: { label: "Approved", color: "#22c55e", isInitial: false },
      rejected: { label: "Rejected", color: "#ef4444", isInitial: false },
    };
    
    return fallbacks[stageId] || { label: stageId, color: "#6b7280", isInitial: false };
  };

  // Helper function to get stage info for a submission
  const getSubmissionStageInfo = (submission) => {
    const formConfig = formConfigs.find(f => f.id === submission.form_config_id);
    const stage = formConfig?.workflow_stages?.find(s => s.id === submission.status);
    
    if (stage) {
      return {
        label: stage.label,
        color: stage.color
      };
    }
    
    return getStageDisplay(submission.status);
  };

  const StatCard = ({ title, value, icon: Icon, color, subtitle }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <div className={`p-2 rounded-lg ${color} bg-opacity-10`}>
          <Icon className={`w-5 h-5 ${color.replace('bg-', 'text-')}`} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">{value}</div>
        {subtitle && <p className="text-xs text-gray-500 mt-1">{subtitle}</p>}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 md:p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Member registration due diligence overview</p>
      </div>

      {isLoading || configsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader><Skeleton className="h-4 w-24" /></CardHeader>
              <CardContent><Skeleton className="h-8 w-16" /></CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Total Submissions"
              value={stats.total}
              icon={FileText}
              color="bg-blue-600"
              subtitle="All time"
            />
            <StatCard
              title="Awaiting Review"
              value={stats.byStage['new'] || 0}
              icon={Clock}
              color="bg-orange-600"
              subtitle="New applications"
            />
            <StatCard
              title="In Review"
              value={stats.byStage['in_review'] || 0}
              icon={TrendingUp}
              color="bg-purple-600"
              subtitle="Currently being processed"
            />
            <StatCard
              title="High Risk"
              value={stats.highRisk}
              icon={AlertCircle}
              color="bg-red-600"
              subtitle="Requires attention"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                {submissions.slice(0, 5).length > 0 ? (
                  <div className="space-y-3">
                    {submissions.slice(0, 5).map((sub) => {
                      const stageInfo = getSubmissionStageInfo(sub);
                      
                      return (
                        <Link 
                          key={sub.id} 
                          to={createPageUrl(`ReviewSubmission?id=${sub.id}`)}
                          className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div 
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: stageInfo.color }}
                            />
                            <div>
                              <p className="font-medium">{sub.applicant_name || 'Unnamed'}</p>
                              <p className="text-sm text-gray-500">{sub.applicant_email || 'No email'}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium">{stageInfo.label}</p>
                            {sub.due_diligence_score !== null && sub.due_diligence_score !== undefined && (
                              <p className="text-xs text-gray-500">Score: {sub.due_diligence_score}%</p>
                            )}
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>No submissions yet</p>
                    <p className="text-sm mt-1">Sync your Zoho Forms to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Status Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(stats.byStage)
                    .sort((a, b) => {
                      const stageA = getStageDisplay(a[0]);
                      const stageB = getStageDisplay(b[0]);
                      // Sort by initial first, then alphabetically
                      if (stageA.isInitial !== stageB.isInitial) {
                        return stageA.isInitial ? -1 : 1;
                      }
                      return stageA.label.localeCompare(stageB.label);
                    })
                    .map(([stageId, count]) => {
                      const stageDisplay = getStageDisplay(stageId);
                      
                      return (
                        <div key={stageId} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div 
                              className="w-4 h-4 rounded-full"
                              style={{ backgroundColor: stageDisplay.color }}
                            />
                            <span className="text-sm">{stageDisplay.label}</span>
                          </div>
                          <span className="font-semibold">{count}</span>
                        </div>
                      );
                    })}
                  
                  {Object.keys(stats.byStage).length === 0 && (
                    <p className="text-sm text-gray-500 text-center py-4">No submissions to display</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

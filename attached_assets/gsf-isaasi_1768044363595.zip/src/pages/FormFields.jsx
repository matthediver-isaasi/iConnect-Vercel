
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Eye, EyeOff, Lock, ChevronDown, Pencil, Check, X, FileText, Plus, Trash2, Send, Loader2, Mail } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";


export default function FormFields() {
  const queryClient = useQueryClient();
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [selectedFormId, setSelectedFormId] = useState(null);
  const [selectedField, setSelectedField] = useState(null);
  const [editingSubform, setEditingSubform] = React.useState(null);
  const [subformTitleInput, setSubformTitleInput] = React.useState('');
  const [editingCrmConfig, setEditingCrmConfig] = React.useState({});
  
  // Webhook testing state
  const [showTriggerWebhookDialog, setShowTriggerWebhookDialog] = React.useState(false);
  const [selectedFieldForWebhook, setSelectedFieldForWebhook] = React.useState(null);
  const [testSubmissionIdInput, setTestSubmissionIdInput] = React.useState('');
  const [testResendCountInput, setTestResendCountInput] = React.useState('0');
  const [isTriggeringWebhook, setIsTriggeringWebhook] = React.useState(false);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: forms, isLoading } = useQuery({
    queryKey: ['forms'],
    queryFn: () => base44.entities.FormConfiguration.list("-created_date"),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const updateFieldMutation = useMutation({
    mutationFn: ({ formId, updatedStructure }) =>
      base44.entities.FormConfiguration.update(formId, {
        form_structure: updatedStructure
      }),
    onMutate: async ({ formId, updatedStructure }) => {
      await queryClient.cancelQueries({ queryKey: ['forms'] });
      const previousForms = queryClient.getQueryData(['forms']);

      queryClient.setQueryData(['forms'], (old) => {
        return old.map(form =>
          form.id === formId
            ? { ...form, form_structure: updatedStructure }
            : form
        );
      });

      return { previousForms };
    },
    onError: (error, variables, context) => {
      if (context?.previousForms) {
        queryClient.setQueryData(['forms'], context.previousForms);
      }
      console.error("Failed to update field:", error);
      toast.error('Failed to update field');
    },
    onSuccess: () => {
      toast.success('Field updated');
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['forms'] });
    }
  });

  const toggleFieldVisibility = (form, fieldName, visible, parentSubformName = null) => {
    let updatedFields;

    if (parentSubformName) {
      // This is a subfield within a subform
      updatedFields = form.form_structure.fields.map(field => {
        if (field.name === parentSubformName && field.type === 'subform') {
          return {
            ...field,
            subfields: field.subfields.map(subfield =>
              subfield.name === fieldName ? { ...subfield, visible } : subfield
            )
          };
        }
        return field;
      });
    } else {
      // This is a top-level field
      updatedFields = form.form_structure.fields.map(field =>
        field.name === fieldName ? { ...field, visible } : field
      );
    }

    const updatedStructure = {
      ...form.form_structure,
      fields: updatedFields
    };

    updateFieldMutation.mutate({
      formId: form.id,
      updatedStructure
    });
  };

  const toggleFieldInternal = (form, fieldName, isInternal, parentSubformName = null) => {
    let updatedFields;

    if (parentSubformName) {
      // This is a subfield within a subform
      updatedFields = form.form_structure.fields.map(field => {
        if (field.name === parentSubformName && field.type === 'subform') {
          return {
            ...field,
            subfields: field.subfields.map(subfield =>
              subfield.name === fieldName ? { ...subfield, is_internal: isInternal } : subfield
            )
          };
        }
        return field;
      });
    } else {
      // This is a top-level field
      updatedFields = form.form_structure.fields.map(field =>
        field.name === fieldName ? { ...field, is_internal: isInternal } : field
      );
    }

    const updatedStructure = {
      ...form.form_structure,
      fields: updatedFields
    };

    updateFieldMutation.mutate({
      formId: form.id,
      updatedStructure
    });
  };

  const toggleFieldSignatureEmail = (form, fieldName, isSignatureEmail, parentSubformName = null) => {
    let updatedFields;

    if (parentSubformName) {
      updatedFields = form.form_structure.fields.map(field => {
        if (field.name === parentSubformName && field.type === 'subform') {
          return {
            ...field,
            subfields: field.subfields.map(subfield => {
              if (subfield.name === fieldName) {
                const updated = { ...subfield, is_signature_email: isSignatureEmail };
                // Clear signature config when toggling off
                if (!isSignatureEmail) {
                  delete updated.signature_form_permalink;
                  delete updated.signature_webhook_address;
                  delete updated.signing_form_config_id;
                  delete updated.signature_trigger_stage_id;
                  delete updated.signature_expiry_days;
                  delete updated.max_resends; // Clear new field
                }
                return updated;
              }
              return subfield;
            })
          };
        }
        return field;
      });
    } else {
      updatedFields = form.form_structure.fields.map(field => {
        if (field.name === fieldName) {
          const updated = { ...field, is_signature_email: isSignatureEmail };
          // Clear signature config when toggling off
          if (!isSignatureEmail) {
            delete updated.signature_form_permalink;
            delete updated.signature_webhook_address;
            delete updated.signing_form_config_id;
            delete updated.signature_trigger_stage_id;
            delete updated.signature_expiry_days;
            delete updated.max_resends; // Clear new field
          }
          return updated;
        }
        return field;
      });
    }

    const updatedStructure = {
      ...form.form_structure,
      fields: updatedFields
    };

    updateFieldMutation.mutate({
      formId: form.id,
      updatedStructure
    });
  };

  const updateSignatureConfig = (form, fieldName, configKey, value, parentSubformName = null) => {
    let updatedFields;

    if (parentSubformName) {
      updatedFields = form.form_structure.fields.map(field => {
        if (field.name === parentSubformName && field.type === 'subform') {
          return {
            ...field,
            subfields: field.subfields.map(subfield =>
              subfield.name === fieldName ? { ...subfield, [configKey]: value } : subfield
            )
          };
        }
        return field;
      });
    } else {
      updatedFields = form.form_structure.fields.map(field =>
        field.name === fieldName ? { ...field, [configKey]: value } : field
      );
    }

    const updatedStructure = {
      ...form.form_structure,
      fields: updatedFields
    };

    updateFieldMutation.mutate({
      formId: form.id,
      updatedStructure
    });
  };

  const updateSubformLabel = (form, fieldName, newLabel) => {
    const updatedFields = form.form_structure.fields.map(field =>
      field.name === fieldName ? { ...field, label: newLabel } : field
    );

    const updatedStructure = {
      ...form.form_structure,
      fields: updatedFields
    };

    updateFieldMutation.mutate({
      formId: form.id,
      updatedStructure
    });
  };

  const handleStartEditSubform = (fieldName, currentLabel) => {
    setEditingSubform(fieldName);
    setSubformTitleInput(currentLabel);
  };

  const handleSaveSubformTitle = (form, fieldName) => {
    if (subformTitleInput.trim()) {
      updateSubformLabel(form, fieldName, subformTitleInput.trim());
      setEditingSubform(null);
      setSubformTitleInput('');
    } else {
      toast.error('Subform title cannot be empty.');
    }
  };

  const handleCancelEditSubform = () => {
    setEditingSubform(null);
    setSubformTitleInput('');
  };

  const updateCrmAttachmentConfig = (form, config) => {
    // Optimistically update the local cache
    queryClient.setQueryData(['forms'], (old) => {
      return old.map(f =>
        f.id === form.id
          ? { ...f, crm_attachment_config: config }
          : f
      );
    });

    base44.entities.FormConfiguration.update(form.id, {
      crm_attachment_config: config
    }).then(() => {
      toast.success('CRM document configuration updated');
      setEditingCrmConfig(prev => {
        const newState = { ...prev };
        delete newState[form.id]; // Clear local editing state for this form
        return newState;
      });
      // Invalidate queries to refetch and ensure consistency, though optimistic update helps
      queryClient.invalidateQueries({ queryKey: ['forms'] });
    }).catch((error) => {
      toast.error('Failed to update CRM configuration: ' + error.message);
      // Revert optimistic update on error
      queryClient.invalidateQueries({ queryKey: ['forms'] });
    });
  };

  const updateFormConfig = (formId, fieldName, value) => {
    base44.entities.FormConfiguration.update(formId, {
      [fieldName]: value
    }).then(() => {
      queryClient.invalidateQueries({ queryKey: ['forms'] });
      toast.success('Configuration updated');
    }).catch((error) => {
      toast.error('Failed to update configuration: ' + error.message);
      queryClient.invalidateQueries({ queryKey: ['forms'] });
    });
  };

  const handleTriggerWebhook = async () => {
    if (!selectedFieldForWebhook || !testSubmissionIdInput) {
      toast.error("Please select a signature field and enter a Submission ID.");
      return;
    }

    const resendCount = parseInt(testResendCountInput) || 0;

    setIsTriggeringWebhook(true);
    try {
      const result = await base44.functions.invoke('triggerSignatureWebhook', {
        submissionId: testSubmissionIdInput,
        signatureFieldName: selectedFieldForWebhook.field.name,
        testResendCount: resendCount
      });

      if (result.data.success) {
        toast.success(`Webhook triggered successfully with resendCount: ${resendCount}`);
        setShowTriggerWebhookDialog(false);
        setTestSubmissionIdInput('');
        setTestResendCountInput('0');
        setSelectedFieldForWebhook(null);
      } else {
        toast.error(`Failed to trigger webhook: ${result.data.message}`);
      }
    } catch (error) {
      toast.error(`Error triggering webhook: ${error.message}`);
      console.error("Error triggering webhook:", error);
    } finally {
      setIsTriggeringWebhook(false);
    }
  };

  const openTriggerWebhookDialog = (field, parentSubformName) => {
    setSelectedFieldForWebhook({ field, parentSubformName });
    setTestSubmissionIdInput('');
    setTestResendCountInput('0');
    setShowTriggerWebhookDialog(true);
  };

  const renderFieldControls = (form, field, parentSubformName = null, isSubfield = false) => {
    const isVisible = field.visible !== false;
    const isInternal = field.is_internal === true;
    const isSignatureEmail = field.is_signature_email === true;
    const isEmailField = field.type === 'email';

    // Get workflow stages for this form
    const workflowStages = form.workflow_stages || [
      { id: "new", label: "New", color: "#f97316", order: 0 },
      { id: "in_review", label: "In Review", color: "#a855f7", order: 1 },
      { id: "verified", label: "Verified", color: "#3b82f6", order: 2 },
      { id: "approved", label: "#22c55e", color: "#22c55e", order: 3 },
      { id: "rejected", label: "#ef4444", color: "#ef4444", order: 4 }
    ];
    const sortedStages = [...workflowStages].sort((a, b) => (a.order || 0) - (b.order || 0));

    return (
      <div
        key={field.name}
        className={`border rounded-lg hover:bg-gray-50 transition-colors ${
          isSubfield ? 'bg-purple-50/50 border-purple-200 ml-8' : ''
        }`}
      >
        <div className="flex items-center justify-between p-3">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <p className={`font-semibold ${isSubfield ? 'text-sm text-gray-800' : 'text-gray-900'}`}>
                {field.label || field.name}
              </p>
              {isInternal && (
                <Lock className="w-4 h-4 text-blue-600" />
              )}
              {isSignatureEmail && (
                <Badge className="bg-green-100 text-green-700 text-xs">Signature Email</Badge>
              )}
            </div>
            <div className="flex items-center gap-3 mt-1">
              <span className="text-xs text-gray-500">Type: {field.type}</span>
              {field.required && (
                <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">Required</span>
              )}
              {isSubfield && (
                <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded">Subform Field</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              {isVisible ? (
                <Eye className="w-4 h-4 text-green-600" />
              ) : (
                <EyeOff className="w-4 h-4 text-gray-400" />
              )}
              <span className={`text-sm font-medium ${isVisible ? 'text-green-600' : 'text-gray-400'}`}>
                {isVisible ? 'Visible' : 'Hidden'}
              </span>
              <Switch
                checked={isVisible}
                onCheckedChange={(checked) => toggleFieldVisibility(form, field.name, checked, parentSubformName)}
                className="data-[state=checked]:bg-green-600"
                disabled={updateFieldMutation.isPending}
              />
            </div>
            <div className="flex items-center gap-3 pl-6 border-l border-gray-300">
              <Lock className={`w-4 h-4 ${isInternal ? 'text-blue-600' : 'text-gray-400'}`} />
              <span className={`text-sm font-medium ${isInternal ? 'text-blue-600' : 'text-gray-400'}`}>
                {isInternal ? 'Internal' : 'Standard'}
              </span>
              <Switch
                checked={isInternal}
                onCheckedChange={(checked) => toggleFieldInternal(form, field.name, checked, parentSubformName)}
                className="data-[state=checked]:bg-blue-600"
                disabled={updateFieldMutation.isPending}
              />
            </div>
            {isEmailField && (
              <div className="flex items-center gap-3 pl-6 border-l border-gray-300">
                <FileText className={`w-4 h-4 ${isSignatureEmail ? 'text-green-600' : 'text-gray-400'}`} />
                <span className={`text-sm font-medium ${isSignatureEmail ? 'text-green-600' : 'text-gray-400'}`}>
                  {isSignatureEmail ? 'Signature' : 'Regular'}
                </span>
                <Switch
                  checked={isSignatureEmail}
                  onCheckedChange={(checked) => toggleFieldSignatureEmail(form, field.name, checked, parentSubformName)}
                  className="data-[state=checked]:bg-green-600"
                  disabled={updateFieldMutation.isPending}
                />
              </div>
            )}
          </div>
        </div>

        {/* Signature Configuration Fields */}
        {isEmailField && isSignatureEmail && (
          <div className="px-3 pb-3 space-y-3 bg-green-50/50 border-t border-green-200">
            <div className="pt-3">
              <Label htmlFor={`sig-form-${field.name}`} className="text-sm font-medium text-gray-700">
                Signing Form Blueprint <span className="text-red-500">*</span>
              </Label>
              <Select
                value={field.signing_form_config_id || ''}
                onValueChange={(value) => updateSignatureConfig(form, field.name, 'signing_form_config_id', value, parentSubformName)}
              >
                <SelectTrigger id={`sig-form-${field.name}`} className="mt-1">
                  <SelectValue placeholder="Select the form blueprint for this signature" />
                </SelectTrigger>
                <SelectContent>
                  {forms.map((formConfig) => (
                    <SelectItem key={formConfig.id} value={formConfig.id}>
                      {formConfig.form_name} ({formConfig.zoho_form_id})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-1">
                Select which form blueprint represents the signature form. This ensures we know what data to expect when the signed form is submitted.
              </p>
            </div>
            
            <div>
              <Label htmlFor={`sig-permalink-${field.name}`} className="text-sm font-medium text-gray-700">
                Signature Form Permalink <span className="text-red-500">*</span>
              </Label>
              <Input
                id={`sig-permalink-${field.name}`}
                value={field.signature_form_permalink || ''}
                onChange={(e) => updateSignatureConfig(form, field.name, 'signature_form_permalink', e.target.value, parentSubformName)}
                placeholder="https://forms.zoho.eu/..."
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                The URL to the digital signature form that will be sent to the applicant
              </p>
            </div>

            <div>
              <Label htmlFor={`sig-webhook-${field.name}`} className="text-sm font-medium text-gray-700">
                Email Trigger Webhook Address <span className="text-red-500">*</span>
              </Label>
              <Input
                id={`sig-webhook-${field.name}`}
                value={field.signature_webhook_address || ''}
                onChange={(e) => updateSignatureConfig(form, field.name, 'signature_webhook_address', e.target.value, parentSubformName)}
                placeholder="https://flow.zoho.eu/..."
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                The webhook URL our app will call to trigger your Flow to send the signature request email
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor={`sig-expiry-${field.name}`} className="text-sm font-medium text-gray-700">
                  Signature Expiry (days) <span className="text-red-500">*</span>
                </Label>
                <Input
                  id={`sig-expiry-${field.name}`}
                  type="number"
                  min="1"
                  value={field.signature_expiry_days || 7}
                  onChange={(e) => updateSignatureConfig(form, field.name, 'signature_expiry_days', parseInt(e.target.value) || 7, parentSubformName)}
                  placeholder="7"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Number of days before the signature request expires and requires follow-up
                </p>
              </div>

              <div>
                <Label htmlFor={`sig-max-resends-${field.name}`} className="text-sm font-medium text-gray-700">
                  Max Resends <span className="text-red-500">*</span>
                </Label>
                <Input
                  id={`sig-max-resends-${field.name}`}
                  type="number"
                  min="0"
                  max="10"
                  value={field.max_resends !== undefined ? field.max_resends : 3}
                  onChange={(e) => updateSignatureConfig(form, field.name, 'max_resends', parseInt(e.target.value) || 3, parentSubformName)}
                  placeholder="3"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Maximum number of times this signature request can be sent (safety limit)
                </p>
              </div>
            </div>
            
            <div>
              <Label htmlFor={`sig-trigger-stage-${field.name}`} className="text-sm font-medium text-gray-700">
                Trigger When Status Changes To <span className="text-red-500">*</span>
              </Label>
              <Select
                value={field.signature_trigger_stage_id || 'verified'}
                onValueChange={(value) => updateSignatureConfig(form, field.name, 'signature_trigger_stage_id', value, parentSubformName)}
              >
                <SelectTrigger id={`sig-trigger-stage-${field.name}`} className="mt-1">
                  <SelectValue placeholder="Select workflow stage" />
                </SelectTrigger>
                <SelectContent>
                  {sortedStages.map((stage) => (
                    <SelectItem key={stage.id} value={stage.id}>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: stage.color }}
                        />
                        {stage.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-gray-500 mt-1">
                The signature request will be sent automatically when the submission status is changed to this stage
              </p>
            </div>

            <div className="pt-3 border-t border-green-200">
              <Label className="text-sm font-medium text-gray-700 block mb-2">
                Test Webhook Trigger
              </Label>
              <Button
                variant="outline"
                size="sm"
                className="w-full gap-2 text-green-700 border-green-300 hover:bg-green-100"
                onClick={() => openTriggerWebhookDialog(field, parentSubformName)}
              >
                <Send className="w-4 h-4" />
                Test Trigger Webhook
              </Button>
              <p className="text-xs text-gray-500 mt-1">
                Manually trigger the signature webhook for this field. Requires a Submission ID.
              </p>
            </div>
          </div>
        )}
      </div>
    );
  };

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Form Fields Management</h1>
        <p className="text-gray-500 mt-1">Control which fields appear in the due diligence review process and mark internal fields</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Available Forms</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="p-4 border rounded-lg">
                  <Skeleton className="h-6 w-64 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ))}
            </div>
          ) : forms.length > 0 ? (
            <Accordion type="single" collapsible className="space-y-2">
              {forms.map((form) => {
                const hasSchema = form.form_structure?.fields?.length > 0;
                const visibleFieldsCount = hasSchema
                  ? form.form_structure.fields.filter(f => f.visible !== false).length
                  : 0;
                const internalFieldsCount = hasSchema
                  ? form.form_structure.fields.filter(f => f.is_internal === true).length
                  : 0;
                const totalFieldsCount = hasSchema ? form.form_structure.fields.length : 0;
                const crmConfigEnabled = form.crm_attachment_config?.enabled === true;

                return (
                  <AccordionItem key={form.id} value={form.id} className="border rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="flex-1 text-left">
                          <h3 className="font-semibold text-lg">{form.form_name}</h3>
                          <p className="text-sm text-gray-600">Link Name: {form.zoho_form_id}</p>
                        </div>
                        {hasSchema ? (
                          <div className="flex gap-2">
                            <Badge className="bg-green-100 text-green-800">
                              {visibleFieldsCount} / {totalFieldsCount} visible
                            </Badge>
                            {internalFieldsCount > 0 && (
                              <Badge className="bg-blue-100 text-blue-800">
                                {internalFieldsCount} internal
                              </Badge>
                            )}
                            {crmConfigEnabled && (
                              <Badge className="bg-purple-100 text-purple-800">
                                CRM Docs
                              </Badge>
                            )}
                            {(form.expected_agreement_types?.length || 0) > 0 && (
                                <Badge className="bg-green-100 text-green-800">
                                  {form.expected_agreement_types.length} Agreements
                                </Badge>
                            )}
                          </div>
                        ) : (
                          <Badge variant="secondary">No Schema</Badge>
                        )}
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      {hasSchema ? (
                        <div className="space-y-6 pt-4">
                          {/* Applicant Name Field Configuration */}
                          <Card className="bg-indigo-50 border-indigo-200">
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base flex items-center gap-2">
                                <Mail className="w-5 h-5 text-indigo-600" />
                                Applicant Name Field
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <Select
                                value={form.applicant_name_field || ''}
                                onValueChange={(value) => updateFormConfig(form.id, 'applicant_name_field', value)}
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select applicant name field..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {form.form_structure.fields
                                    .filter(f => f.type === 'name' || f.type === 'text')
                                    .map(field => (
                                      <SelectItem key={field.name} value={field.name}>
                                        {field.label || field.name}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                              <p className="text-sm text-gray-600 mt-1">
                                Select which field contains the applicant's full name. For name-type fields, both first and last names will be combined.
                              </p>
                            </CardContent>
                          </Card>

                          {/* Applicant Email Field Configuration */}
                          <Card className="bg-blue-50 border-blue-200">
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base flex items-center gap-2">
                                <Mail className="w-5 h-5 text-blue-600" />
                                Applicant Email Field
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <Select
                                value={form.applicant_email_field || ''}
                                onValueChange={(value) => updateFormConfig(form.id, 'applicant_email_field', value)}
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select applicant email field..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {form.form_structure.fields
                                    .filter(f => f.type === 'email' || f.type === 'text')
                                    .map(field => (
                                      <SelectItem key={field.name} value={field.name}>
                                        {field.label || field.name}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                              <p className="text-sm text-gray-600 mt-1">
                                Select which field contains the applicant's main email address. This email will be used when triggering signature requests.
                              </p>
                            </CardContent>
                          </Card>

                          {/* Applicant Organization Name Field Configuration */}
                          <Card className="bg-teal-50 border-teal-200">
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base flex items-center gap-2">
                                <FileText className="w-5 h-5 text-teal-600" />
                                Applicant Organization Name Field
                              </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <Select
                                value={form.applicant_organization_name_field || ''}
                                onValueChange={(value) => updateFormConfig(form.id, 'applicant_organization_name_field', value)}
                              >
                                <SelectTrigger className="w-full">
                                  <SelectValue placeholder="Select organization name field..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {form.form_structure.fields
                                    .filter(f => f.type === 'text' || f.type === 'name')
                                    .map(field => (
                                      <SelectItem key={field.name} value={field.name}>
                                        {field.label || field.name}
                                      </SelectItem>
                                    ))}
                                </SelectContent>
                              </Select>
                              <p className="text-sm text-gray-600 mt-1">
                                Select which field contains the applicant's organization name. This will be included in status change webhook payloads.
                              </p>
                            </CardContent>
                          </Card>

                          {/* CRM Documents Configuration */}
                          <Card className="bg-purple-50 border-purple-200">
                            <CardHeader className="pb-3">
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <FileText className="w-5 h-5 text-purple-600" />
                                  <CardTitle className="text-base">CRM Document Links</CardTitle>
                                </div>
                                <Switch
                                  checked={crmConfigEnabled}
                                  onCheckedChange={(checked) => {
                                    updateCrmAttachmentConfig(form, {
                                      enabled: checked,
                                      submission_org_name_field: form.crm_attachment_config?.submission_org_name_field || '',
                                      label: form.crm_attachment_config?.label || 'CRM Documents'
                                    });
                                  }}
                                  className="data-[state=checked]:bg-purple-600"
                                />
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <p className="text-sm text-gray-600">
                                Link to documents stored in Zoho CRM's isaasi_Organisations module. The system will search by Name field.
                              </p>

                              {crmConfigEnabled && (
                                <div className="space-y-3 bg-white p-4 rounded-lg border">
                                  <div>
                                    <Label htmlFor={`crm-label-${form.id}`} className="text-sm font-medium">Display Label</Label>
                                    <Input
                                      id={`crm-label-${form.id}`}
                                      value={editingCrmConfig[form.id]?.label !== undefined
                                        ? editingCrmConfig[form.id].label
                                        : (form.crm_attachment_config?.label || 'CRM Documents')}
                                      onChange={(e) => {
                                        setEditingCrmConfig(prev => ({
                                          ...prev,
                                          [form.id]: {
                                            ...prev[form.id],
                                            label: e.target.value
                                          }
                                        }));
                                      }}
                                      placeholder="e.g., Company Documents"
                                      className="mt-1"
                                    />
                                  </div>

                                  <div>
                                    <Label htmlFor={`org-name-field-${form.id}`} className="text-sm font-medium">Organization Name Field</Label>
                                    <Select
                                      value={editingCrmConfig[form.id]?.submission_org_name_field !== undefined
                                        ? editingCrmConfig[form.id].submission_org_name_field
                                        : (form.crm_attachment_config?.submission_org_name_field || '')}
                                      onValueChange={(value) => {
                                        setEditingCrmConfig(prev => ({
                                          ...prev,
                                          [form.id]: {
                                            ...prev[form.id],
                                            submission_org_name_field: value
                                          }
                                        }));
                                      }}
                                    >
                                      <SelectTrigger id={`org-name-field-${form.id}`} className="mt-1">
                                        <SelectValue placeholder="Select field containing organization name" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {form.form_structure.fields
                                          .filter(f => f.visible !== false)
                                          .map((field) => (
                                            <SelectItem key={field.name} value={field.name}>
                                              {field.label || field.name}
                                            </SelectItem>
                                          ))}
                                      </SelectContent>
                                    </Select>
                                    <p className="text-xs text-gray-500 mt-1">
                                      This field should contain the exact organization name as it appears in the Zoho CRM isaasi_Organisations module (Name field)
                                    </p>
                                  </div>

                                  {(editingCrmConfig[form.id]?.label !== undefined &&
                                    editingCrmConfig[form.id].label !== (form.crm_attachment_config?.label || 'CRM Documents')) ||
                                   (editingCrmConfig[form.id]?.submission_org_name_field !== undefined &&
                                    editingCrmConfig[form.id].submission_org_name_field !== (form.crm_attachment_config?.submission_org_name_field || ''))
                                   ? (
                                    <Button
                                      size="sm"
                                      onClick={() => {
                                        updateCrmAttachmentConfig(form, {
                                          enabled: true,
                                          submission_org_name_field: editingCrmConfig[form.id].submission_org_name_field !== undefined
                                            ? editingCrmConfig[form.id].submission_org_name_field
                                            : (form.crm_attachment_config?.submission_org_name_field || ''),
                                          label: editingCrmConfig[form.id].label !== undefined
                                            ? editingCrmConfig[form.id].label
                                            : (form.crm_attachment_config?.label || 'CRM Documents')
                                        });
                                      }}
                                      className="w-full bg-purple-600 hover:bg-purple-700"
                                    >
                                      Save Configuration
                                    </Button>
                                  ) : null}
                                </div>
                              )}
                            </CardContent>
                          </Card>

                          {/* Form Fields */}
                          <div className="space-y-3">
                            {form.form_structure.fields.map((field) => {
                              // Check if this is a subform
                              if (field.type === 'subform' && field.subfields?.length > 0) {
                                const isEditing = editingSubform === field.name;

                                return (
                                  <Collapsible key={field.name} defaultOpen className="space-y-2">
                                    <div className="border-2 border-purple-300 rounded-lg bg-purple-50/30 overflow-hidden">
                                      <CollapsibleTrigger asChild>
                                        <div className="flex items-center justify-between p-3 bg-purple-100/50 hover:bg-purple-100 transition-colors cursor-pointer">
                                          <div className="flex items-center gap-2 flex-1">
                                            <ChevronDown className="w-5 h-5 text-purple-700 data-[state=open]:rotate-180 transition-transform" />
                                            <div className="flex-1">
                                              {isEditing ? (
                                                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                                                  <Input
                                                    value={subformTitleInput}
                                                    onChange={(e) => setSubformTitleInput(e.target.value)}
                                                    onKeyDown={(e) => {
                                                      if (e.key === 'Enter') {
                                                        handleSaveSubformTitle(form, field.name);
                                                      } else if (e.key === 'Escape') {
                                                        handleCancelEditSubform();
                                                      }
                                                    }}
                                                    className="h-8 text-sm font-semibold"
                                                    placeholder="Enter subform title..."
                                                    autoFocus
                                                  />
                                                  <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                                                    onClick={() => handleSaveSubformTitle(form, field.name)}
                                                  >
                                                    <Check className="w-4 h-4" />
                                                  </Button>
                                                  <Button
                                                    size="icon"
                                                    variant="ghost"
                                                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                                    onClick={handleCancelEditSubform}
                                                  >
                                                    <X className="w-4 h-4" />
                                                  </Button>
                                                </div>
                                              ) : (
                                                <>
                                                  <div className="flex items-center gap-2 group">
                                                    <p className="font-semibold text-gray-900">{field.label || field.name}</p>
                                                    <Button
                                                      size="icon"
                                                      variant="ghost"
                                                      className="h-6 w-6 opacity-0 group-hover:opacity-100 hover:bg-purple-200 transition-opacity"
                                                      onClick={(e) => {
                                                        e.stopPropagation();
                                                        handleStartEditSubform(field.name, field.label || field.name);
                                                      }}
                                                    >
                                                      <Pencil className="w-3 h-3 text-purple-700" />
                                                    </Button>
                                                  </div>
                                                  <div className="flex items-center gap-3 mt-1">
                                                    <span className="text-xs text-gray-500">Type: {field.type}</span>
                                                    <Badge className="bg-purple-200 text-purple-800 text-xs">
                                                      {field.subfields.length} subfields
                                                    </Badge>
                                                    {field.required && (
                                                      <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">Required</span>
                                                    )}
                                                  </div>
                                                </>
                                              )}
                                            </div>
                                          </div>
                                        </div>
                                      </CollapsibleTrigger>
                                      <CollapsibleContent className="p-2 space-y-2">
                                        {field.subfields.map((subfield) =>
                                          renderFieldControls(form, subfield, field.name, true)
                                        )}
                                      </CollapsibleContent>
                                    </div>
                                  </Collapsible>
                                );
                              }

                              // Regular field
                              return renderFieldControls(form, field, null, false);
                            })}
                          </div>
                          {/*
                          {/* Signature Agreements Configuration 
                          <Card className="bg-green-50 border-green-200 mt-6">
                            <CardHeader className="pb-3">
                              <div className="flex items-center gap-2">
                                <FileText className="w-5 h-5 text-green-600" />
                                <CardTitle className="text-base">Signature Agreements</CardTitle>
                              </div>
                            </CardHeader>
                            <CardContent className="space-y-3">
                              <p className="text-sm text-gray-600">
                                Configure which signature agreements are expected for this form. These will appear as pending on the review page.
                              </p>

                              <div className="space-y-2">
                                <Label className="text-sm font-medium">Expected Agreement Types</Label>
                                {(form.expected_agreement_types || []).map((agreementType, index) => (
                                  <div key={index} className="flex gap-2 items-center">
                                    <Input
                                      value={agreementType}
                                      onChange={(e) => {
                                        const updated = [...(form.expected_agreement_types || [])];
                                        updated[index] = e.target.value;
                                        base44.entities.FormConfiguration.update(form.id, {
                                          expected_agreement_types: updated
                                        }).then(() => {
                                          queryClient.invalidateQueries({ queryKey: ['forms'] });
                                          toast.success('Agreement types updated');
                                        }).catch((error) => {
                                          toast.error('Failed to update agreement type: ' + error.message);
                                        });
                                      }}
                                      placeholder="e.g., Membership Agreement 1"
                                      className="flex-1"
                                    />
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => {
                                        const updated = (form.expected_agreement_types || []).filter((_, i) => i !== index);
                                        base44.entities.FormConfiguration.update(form.id, {
                                          expected_agreement_types: updated
                                        }).then(() => {
                                          queryClient.invalidateQueries({ queryKey: ['forms'] });
                                          toast.success('Agreement type removed');
                                        }).catch((error) => {
                                          toast.error('Failed to remove agreement type: ' + error.message);
                                        });
                                      }}
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                ))}
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    const updated = [...(form.expected_agreement_types || []), ''];
                                    base44.entities.FormConfiguration.update(form.id, {
                                      expected_agreement_types: updated
                                    }).then(() => {
                                      queryClient.invalidateQueries({ queryKey: ['forms'] });
                                      toast.success('Agreement type added');
                                    }).catch((error) => {
                                      toast.error('Failed to add agreement type: ' + error.message);
                                    });
                                  }}
                                  className="w-full border-2 border-dashed border-green-300 hover:bg-green-100 hover:border-green-400 text-green-700"
                                >
                                  <Plus className="w-4 h-4 mr-2" />
                                  Add Agreement Type
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                          */}
                        </div>
                      ) : (
                        <div className="text-center py-8 text-gray-500">
                          <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                          <p>
                            No form fields are configured for review in this form structure.
                          </p>
                          <p className="text-sm mt-1">Please scrape the form schema first in Sync Forms</p>
                        </div>
                      )}
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-lg font-medium">No forms available</p>
              <p className="text-sm mt-1">Sync your Zoho Forms to get started</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Test Webhook Dialog */}
      <Dialog open={showTriggerWebhookDialog} onOpenChange={setShowTriggerWebhookDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="w-5 h-5 text-green-600" />
              Test Webhook: {selectedFieldForWebhook?.field?.label || selectedFieldForWebhook?.field?.name}
            </DialogTitle>
            <DialogDescription>
              Enter the Submission ID and specify the resend count to test the webhook with different email scenarios.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="submission-id-input" className="mb-2 block">Submission ID <span className="text-red-500">*</span></Label>
              <Input
                id="submission-id-input"
                value={testSubmissionIdInput}
                onChange={(e) => setTestSubmissionIdInput(e.target.value)}
                placeholder="e.g., clt74g1070002123abcde456"
              />
              <p className="text-xs text-gray-500 mt-1">
                You can find the Submission ID in the URL when reviewing a submission (e.g., /ReviewSubmission?id=...)
              </p>
            </div>

            <div>
              <Label htmlFor="resend-count-input" className="mb-2 block">Resend Count (for testing)</Label>
              <Input
                id="resend-count-input"
                type="number"
                min="0"
                max="10"
                value={testResendCountInput}
                onChange={(e) => setTestResendCountInput(e.target.value)}
                placeholder="0"
              />
              <p className="text-xs text-gray-500 mt-1">
                Specify which resend attempt to simulate (0 = initial, 1 = first resend, 2 = second resend, etc.). This allows you to test how your Zoho Flow handles different email scenarios.
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-900 font-semibold mb-2">Test Mode Notice</p>
              <p className="text-xs text-blue-800">
                This test will send the webhook with <code className="bg-blue-100 px-1 py-0.5 rounded">resendCount: {testResendCountInput || '0'}</code> in the payload, but <strong>will NOT update the database</strong>. Use this to test your Zoho Flow email templates for different retry scenarios.
              </p>
            </div>
            
            {selectedFieldForWebhook?.field && (
              <div className="bg-gray-50 p-3 rounded-lg space-y-2 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Field:</span>{' '}
                  <span className="text-gray-900">{selectedFieldForWebhook.field.label || selectedFieldForWebhook.field.name}</span>
                </div>
                {selectedFieldForWebhook.field.signature_webhook_address && (
                  <div>
                    <span className="font-medium text-gray-700">Webhook URL:</span>{' '}
                    <span className="text-gray-900 font-mono text-xs break-all">
                      {selectedFieldForWebhook.field.signature_webhook_address}
                    </span>
                  </div>
                )}
                {selectedFieldForWebhook.field.max_resends !== undefined && (
                  <div>
                    <span className="font-medium text-gray-700">Max Resends:</span>{' '}
                    <span className="text-gray-900">{selectedFieldForWebhook.field.max_resends}</span>
                  </div>
                )}
                {selectedFieldForWebhook.parentSubformName && (
                  <div>
                    <span className="font-medium text-gray-700">Parent Subform:</span>{' '}
                    <span className="text-gray-900">{selectedFieldForWebhook.parentSubformName}</span>
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowTriggerWebhookDialog(false);
                setTestSubmissionIdInput('');
                setTestResendCountInput('0');
                setSelectedFieldForWebhook(null);
              }}
              disabled={isTriggeringWebhook}
            >
              Cancel
            </Button>
            <Button
              onClick={handleTriggerWebhook}
              disabled={isTriggeringWebhook || !testSubmissionIdInput.trim()}
              className="gap-2 bg-green-600 hover:bg-green-700"
            >
              {isTriggeringWebhook ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Triggering...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Trigger Test Webhook
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

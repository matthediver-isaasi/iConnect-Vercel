import React, { useState, useEffect, useCallback, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Save, AlertCircle, Calculator, Loader2, NotebookText, X, RotateCcw, FileText, Download, ExternalLink, Eye, Mail, CheckCircle2, Phone, Calendar, History, RefreshCw, RepeatIcon } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import ReactQuill from 'react-quill';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { format } from 'date-fns';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

import ReviewFieldEditor from "../components/review/ReviewFieldEditor";
import StaticQuestionReview from "../components/review/StaticQuestionReview";
import ScoreGradient from "../components/review/ScoreGradient";
import { useNavigationGuard } from "@/components/NavigationGuard";
import SubmissionHistoryLog from "../components/review/SubmissionHistoryLog";

export default function ReviewSubmission() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const submissionId = urlParams.get('id');
  const { setHasUnsavedChanges, attemptNavigation } = useNavigationGuard();

  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [initialLoadedFormData, setInitialLoadedFormData] = useState({});
  const [originalFormData, setOriginalFormData] = useState({});
  const [reviewedFormData, setReviewedFormData] = useState({});
  const [fieldReviewStatus, setFieldReviewStatus] = useState({});
  const [fieldNotes, setFieldNotes] = useState({});
  const [staticQuestionResponses, setStaticQuestionResponses] = useState({});
  const [staticQuestionNotes, setStaticQuestionNotes] = useState({});

  const [status, setStatus] = useState('');
  const [notes, setNotes] = useState('');
  const [showNotesEditor, setShowNotesEditor] = useState(false);
  const [isCalculatingScore, setIsCalculatingScore] = useState(false);
  const [isAutoCalculating, setIsAutoCalculating] = useState(false);
  const [hasInitialized, setHasInitialized] = useState(false);

  const [showResetModal, setShowResetModal] = useState(false);
  const [resetConfirmText, setResetConfirmText] = useState('');
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const [lastSavedState, setLastSavedState] = useState(null);

  const [crmAttachments, setCrmAttachments] = React.useState([]);
  const [loadingAttachments, setLoadingAttachments] = React.useState(false);
  const [attachmentsError, setAttachmentsError] = React.useState(null);
  const [showAttachmentsModal, setShowAttachmentsModal] = React.useState(false);
  
  const [previewAttachment, setPreviewAttachment] = React.useState(null);
  const [showPreviewModal, setShowPreviewModal] = React.useState(false);

  const [attachmentApprovals, setAttachmentApprovals] = React.useState({});
  const [selectedLogoAttachmentId, setSelectedLogoAttachmentId] = React.useState(null);

  const [showStatusChangeDialog, setShowStatusChangeDialog] = useState(false);
  const [pendingStatusChange, setPendingStatusChange] = useState(null);
  const [wasFirstReview, setWasFirstReview] = useState(false); // Track if this was first review on page load
  
  const [showCustomMessageDialog, setShowCustomMessageDialog] = useState(false);
  const [customMessageInput, setCustomMessageInput] = useState('');
  const [pendingWebhooksWithMessages, setPendingWebhooksWithMessages] = useState([]);
  
  const [showSwapFormDialog, setShowSwapFormDialog] = useState(false);
  const [selectedTargetFormId, setSelectedTargetFormId] = useState('');
  const [isSwapping, setIsSwapping] = useState(false)

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submission, isLoading } = useQuery({
    queryKey: ['submission', submissionId],
    queryFn: async () => {
      const subs = await base44.entities.Submission.filter({ id: submissionId });
      return subs[0];
    },
    enabled: !!submissionId && isAuthenticated === true,
  });

  const { data: formConfig } = useQuery({
    queryKey: ['formConfig', submission?.form_config_id],
    queryFn: async () => {
      const configs = await base44.entities.FormConfiguration.filter({ id: submission.form_config_id });
      return configs[0];
    },
    enabled: !!submission?.form_config_id && isAuthenticated === true,
  });

  const { data: allFormConfigs = [] } = useQuery({
    queryKey: ['allFormConfigs'],
    queryFn: async () => {
      return await base44.entities.FormConfiguration.list();
    },
    enabled: isAuthenticated === true,
  });

  const workflowStages = formConfig?.workflow_stages || [
    { id: "new", label: "New", color: "#f97316", order: 0, is_initial: true },
    { id: "in_review", label: "In Review", color: "#a855f7", order: 1 },
    { id: "verified", label: "Verified", color: "#3b82f6", order: 2 },
    { id: "approved", label: "Approved", color: "#22c55e", order: 3 },
    { id: "rejected", label: "Rejected", color: "#ef4444", order: 4 }
  ];

  const sortedStages = [...workflowStages].sort((a, b) => (a.order || 0) - (b.order || 0));

  // NEW: Function to evaluate if a stage's selection conditions are met
  const evaluateStageConditions = useCallback((stage) => {
    if (!stage.selection_conditions) {
      return { canSelect: true, reasons: [] };
    }

    const conditions = stage.selection_conditions;
    const reasons = [];

    // Check signature requirement
    if (conditions.require_all_signatures) {
      const allAgreements = submission?.agreements_status || [];
      const allSigned = allAgreements.length > 0 && allAgreements.every(ag => ag.is_signed === true);
      
      if (!allSigned) {
        const signedCount = allAgreements.filter(ag => ag.is_signed).length;
        reasons.push(`All signatures required (${signedCount}/${allAgreements.length} signed)`);
      }
    }

    // Check attachments requirement
    if (conditions.require_all_attachments_approved) {
      const allAttachments = submission?.crm_attachments_status || [];
      const allApproved = allAttachments.length > 0 && allAttachments.every(att => att.is_approved === true);
      
      if (!allApproved) {
        const approvedCount = allAttachments.filter(att => att.is_approved).length;
        reasons.push(`All documents must be approved (${approvedCount}/${allAttachments.length} approved)`);
      }
    }

    // Check logo requirement
    if (conditions.require_logo_designated) {
      const hasLogoDesignated = submission?.crm_attachments_status?.some(att => att.is_logo_attachment === true);
      
      if (!hasLogoDesignated) {
        reasons.push('Organization logo must be designated');
      }
    }

    // Check minimum score threshold
    if (conditions.min_score_threshold !== null && conditions.min_score_threshold !== undefined) {
      const currentScore = submission?.due_diligence_score;
      
      if (currentScore === null || currentScore === undefined) {
        reasons.push(`Minimum score of ${conditions.min_score_threshold}% required (score not calculated)`);
      } else if (currentScore < conditions.min_score_threshold) {
        reasons.push(`Minimum score of ${conditions.min_score_threshold}% required (current: ${currentScore}%)`);
      }
    }

    // Check maximum score threshold
    if (conditions.max_score_threshold !== null && conditions.max_score_threshold !== undefined) {
      const currentScore = submission?.due_diligence_score;
      
      if (currentScore === null || currentScore === undefined) {
        reasons.push(`Maximum score of ${conditions.max_score_threshold}% required (score not calculated)`);
      } else if (currentScore > conditions.max_score_threshold) {
        reasons.push(`Maximum score of ${conditions.max_score_threshold}% exceeded (current: ${currentScore}%)`);
      }
    }

    return {
      canSelect: reasons.length === 0,
      reasons
    };
  }, [submission]);

  const handleStatusChange = (newStatus) => {
    if (newStatus !== status) {
      // Evaluate conditions for the new status
      const targetStage = sortedStages.find(s => s.id === newStatus);
      if (targetStage) {
        const evaluation = evaluateStageConditions(targetStage);
        
        if (!evaluation.canSelect) {
          // Show error toast with reasons
          toast.error(
            <div>
              <p className="font-semibold mb-1">Cannot select "{targetStage.label}"</p>
              <ul className="text-xs space-y-0.5">
                {evaluation.reasons.map((reason, idx) => (
                  <li key={idx}>• {reason}</li>
                ))}
              </ul>
            </div>,
            { duration: 5000 }
          );
          return; // Don't proceed with status change
        }
      }
      
      setPendingStatusChange(newStatus);
      setShowStatusChangeDialog(true);
    }
  };

  const confirmStatusChange = (shouldTriggerWorkflows) => {
    if (pendingStatusChange) {
      setShowStatusChangeDialog(false);
      const newStatus = pendingStatusChange;
      setPendingStatusChange(null);
      
      // Check if any webhooks need custom messages BEFORE saving
      if (shouldTriggerWorkflows && formConfig?.status_change_webhooks) {
        const webhooksForThisStatus = formConfig.status_change_webhooks.filter(
          webhook => webhook.enabled !== false && 
                     webhook.trigger_status_id === newStatus
        );
        
        const webhooksNeedingMessages = webhooksForThisStatus.filter(w => w.prompt_for_custom_message);
        
        if (webhooksNeedingMessages.length > 0) {
          // Show custom message dialog BEFORE saving
          setPendingWebhooksWithMessages(webhooksNeedingMessages);
          // Store the new status to use after message is collected
          setPendingStatusChange(newStatus);
          setShowCustomMessageDialog(true);
          return;
        }
      }
      
      // No custom messages needed, proceed with save
      handleSave(newStatus, shouldTriggerWorkflows);
    }
  };

  const cancelStatusChange = () => {
    setShowStatusChangeDialog(false);
    setPendingStatusChange(null);
  };

  // NEW: Fetch CRM Attachment Metadata function
  const fetchCrmAttachmentMetadata = useCallback(async () => {
    if (!submission || !formConfig || !formConfig.crm_attachment_config?.enabled) {
      return;
    }

    try {
      const response = await base44.functions.invoke('getCrmAttachmentMetadata', {
        submissionId: submission.id,
        formConfigId: formConfig.id
      });

      if (response.data.success && response.data.attachments && response.data.attachments.length > 0) {
        // Update submission's crm_attachments_status with metadata only
        const metadataEntries = response.data.attachments.map(att => ({
          attachment_id: att.id,
          file_name: att.fileName,
          size: att.size,
          base44_file_uri: null, // Not downloaded yet, so no URI
          is_approved: false,
          approved_by: null,
          approved_date: null,
          is_logo_attachment: false
        }));

        // Only update if the submission doesn't already have attachment status entries
        // This is to pre-populate the status array if it's empty from a fresh submission
        if (!submission.crm_attachments_status || submission.crm_attachments_status.length === 0) {
          console.log('[fetchCrmAttachmentMetadata] Populating crm_attachments_status with metadata.');
          await base44.entities.Submission.update(submission.id, {
            crm_attachments_status: metadataEntries
          });
          
          // Refresh the submission data to reflect the new crm_attachments_status
          queryClient.invalidateQueries(['submission', submissionId]);
        } else {
            console.log('[fetchCrmAttachmentMetadata] crm_attachments_status already exists, skipping metadata fetch update.');
        }
      } else if (!response.data.success) {
        console.error('[fetchCrmAttachmentMetadata] API Error:', response.data.message);
        // Optionally toast an error here if needed, but might be too noisy for background operation
      }
    } catch (error) {
      console.error('[fetchCrmAttachmentMetadata] Exception:', error.response?.data?.message || error.message);
      // Optionally toast an error here if needed
    }
  }, [submission, formConfig, submissionId, queryClient]);

  // TODO: Re-enable CRM attachment metadata fetching once the underlying issue is resolved
  // useEffect(() => {
  //   if (submission && formConfig?.crm_attachment_config?.enabled && hasInitialized) {
  //     if (!submission.crm_attachments_status || submission.crm_attachments_status.length === 0) {
  //       console.log('[ReviewSubmission] Initializing: Checking for CRM attachment metadata.');
  //       fetchCrmAttachmentMetadata();
  //     }
  //   }
  // }, [submission, formConfig, hasInitialized, fetchCrmAttachmentMetadata]);


  useEffect(() => {
    if (submission && formConfig && !hasInitialized) {
      const trueOriginalData = submission.original_form_data || {};
      const currentData = submission.form_data || {};

      setInitialLoadedFormData({ ...trueOriginalData }); // Corrected to use trueOriginalData for initial data
      setOriginalFormData({ ...trueOriginalData });
      setReviewedFormData({ ...currentData });
      
      // TRACK IF THIS IS FIRST REVIEW - check ONCE when page loads
      const isFirstReviewOnLoad = !submission.reviewed_by;
      setWasFirstReview(isFirstReviewOnLoad);
      console.log('=== INITIAL LOAD CHECK ===');
      console.log('Is this the first review of this submission?', isFirstReviewOnLoad);
      console.log('reviewed_by on load:', submission.reviewed_by);

      const initialStageId = workflowStages.find(s => s.is_initial)?.id || 'new';
      const initialStatus = submission.status || initialStageId;
      setStatus(initialStatus);
      
      setNotes(submission.notes || '');
      setFieldNotes({ ...(submission.field_notes || {}) });

      const loadedResponses = submission.static_question_responses || {};
      setStaticQuestionResponses({ ...loadedResponses });

      const loadedQuestionNotes = submission.static_question_notes || {};
      setStaticQuestionNotes({ ...loadedQuestionNotes });

      if (formConfig.form_structure?.fields) {
        const initialStatusReview = {};
        const defaultState = formConfig.default_review_state || 'amended';
        
        formConfig.form_structure.fields.forEach(field => {
          // For composite fields, apply the default to their base name
          const baseFieldName = field.name.replace(/_First$|_Last$|_address1$|_address2$|_city$|_zipCode$|_country$/, '');
          initialStatusReview[baseFieldName] = defaultState;
          initialStatusReview[field.name] = defaultState; // Also apply to individual field name
        });
        setFieldReviewStatus(initialStatusReview);
      } else {
        setFieldReviewStatus({});
      }

      // Initialize attachment approvals and logo selection
      if (submission.crm_attachments_status) {
        const approvals = {};
        let logoId = null;
        
        submission.crm_attachments_status.forEach(att => {
          approvals[att.attachment_id] = {
            is_approved: att.is_approved || false,
            approved_by: att.approved_by,
            approved_date: att.approved_date,
            base44_file_uri: att.base44_file_uri // Ensure base44_file_uri is captured
          };
          
          if (att.is_logo_attachment === true) {
            logoId = att.attachment_id;
          }
        });
        
        setAttachmentApprovals(approvals);
        setSelectedLogoAttachmentId(logoId);
      }

      setLastSavedState({
        reviewedFormData: { ...currentData },
        status: initialStatus,
        notes: submission.notes || '',
        fieldNotes: { ...(submission.field_notes || {}) },
        staticQuestionResponses: { ...loadedResponses },
        staticQuestionNotes: { ...(submission.static_question_notes || {}) },
        attachmentApprovals: submission.crm_attachments_status ? submission.crm_attachments_status.reduce((acc, att) => {
          acc[att.attachment_id] = {
            is_approved: att.is_approved,
            approved_by: att.approved_by,
            approved_date: att.approved_date,
            base44_file_uri: att.base44_file_uri
          };
          return acc;
        }, {}) : {},
        selectedLogoAttachmentId: submission.crm_attachments_status?.find(att => att.is_logo_attachment === true)?.attachment_id || null
      });

      setHasInitialized(true);
    }
  }, [submission, formConfig, hasInitialized, workflowStages]);

  const fetchCrmAttachments = useCallback(async () => {
    if (!submission || !formConfig || !formConfig.crm_attachment_config?.enabled) {
      return;
    }

    setLoadingAttachments(true);
    setAttachmentsError(null);

    try {
      const response = await base44.functions.invoke('getZohoCrmAttachments', {
        submissionId: submission.id,
        formConfigId: formConfig.id
      });

      console.log('[fetchCrmAttachments] Full response:', response);

      if (response.data.success) {
        const fetchedAttachments = response.data.attachments || [];
        setCrmAttachments(fetchedAttachments);
        
        setAttachmentApprovals(prev => {
          const updated = { ...prev };
          fetchedAttachments.forEach(att => {
            if (!updated[att.id]) {
              const existingStatus = submission.crm_attachments_status?.find(s => s.attachment_id === att.id);
              updated[att.id] = {
                is_approved: existingStatus?.is_approved || false,
                approved_by: existingStatus?.approved_by,
                approved_date: existingStatus?.approved_date,
                base44_file_uri: att.base44FileUri || existingStatus?.base44_file_uri // Store Base44 file URI
              };
            }
          });
          return updated;
        });
      } else {
        console.error('[fetchCrmAttachments] Error:', response.data.message);
        setAttachmentsError(response.data.message);
      }
    } catch (error) {
      console.error('[fetchCrmAttachments] Exception:', error);
      // Extract error message from axios error response
      const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message;
      console.error('[fetchCrmAttachments] Error message:', errorMessage);
      setAttachmentsError(errorMessage);
    } finally {
      setLoadingAttachments(false);
    }
  }, [submission, formConfig]);

  const handleOpenAttachmentsModal = () => {
    setShowAttachmentsModal(true);
    fetchCrmAttachments();
  };

  const hasUnsavedChanges = useMemo(() => {
    if (!lastSavedState) return false;

    return (
      JSON.stringify(reviewedFormData) !== JSON.stringify(lastSavedState.reviewedFormData) ||
      status !== lastSavedState.status ||
      notes !== lastSavedState.notes ||
      JSON.stringify(fieldNotes) !== JSON.stringify(lastSavedState.fieldNotes) ||
      JSON.stringify(staticQuestionResponses) !== JSON.stringify(lastSavedState.staticQuestionResponses) ||
      JSON.stringify(staticQuestionNotes) !== JSON.stringify(lastSavedState.staticQuestionNotes) ||
      JSON.stringify(attachmentApprovals) !== JSON.stringify(lastSavedState.attachmentApprovals) ||
      selectedLogoAttachmentId !== lastSavedState.selectedLogoAttachmentId
    );
  }, [reviewedFormData, status, notes, fieldNotes, staticQuestionResponses, staticQuestionNotes, attachmentApprovals, selectedLogoAttachmentId, lastSavedState]);

  useEffect(() => {
    setHasUnsavedChanges(hasUnsavedChanges);
  }, [hasUnsavedChanges, setHasUnsavedChanges]);

  const handleFieldChange = useCallback((fieldName, value, type = 'amended') => {
    setReviewedFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
    
    const baseFieldName = fieldName.replace(/_First$|_Last$|_address1$|_address2$|_city$|_zipCode$|_country$/, '');
    
    // DEBUG: Log to understand what's happening with name field changes
    console.log(`[handleFieldChange] fieldName: ${fieldName}, baseFieldName: ${baseFieldName}, type: ${type}`);
    
    setFieldReviewStatus(prev => {
      // If it's a composite field component, apply status to the base field name
      const updated = { ...prev };
      if (baseFieldName !== fieldName) {
        updated[baseFieldName] = type;
      }
      updated[fieldName] = type; // Also apply to the specific field name
      console.log('[handleFieldChange] New fieldReviewStatus:', updated);
      return updated;
    });
  }, []);

  const handleFieldNoteChange = (fieldName, note) => {
    setFieldNotes(prev => ({
      ...prev,
      [fieldName]: note
    }));
  };

  const handleStaticQuestionNoteChange = (questionId, note) => {
    setStaticQuestionNotes(prev => ({
      ...prev,
      [questionId]: note
    }));
  };

  const handleStaticQuestionResponse = async (questionId, response) => {
    const updatedResponses = {
      ...staticQuestionResponses,
      [questionId]: response
    };

    setStaticQuestionResponses(updatedResponses);

    if (formConfig?.scoring_approach === 'static_traffic_light') {
      setIsAutoCalculating(true);
      try {
        const result = await base44.functions.invoke('calculateStaticTrafficLightScore', {
          submissionId: submissionId,
          responses: updatedResponses
        });

        if (result.data.success) {
          await queryClient.invalidateQueries(['submission', submissionId]);
        } else {
          console.error('Auto-calculation failed:', result.data.message);
          toast.error(result.data.message || 'Failed to auto-calculate score');
        }
      } catch (error) {
        console.error('Auto-calculation error:', error);
        toast.error('Error during auto-calculation: ' + error.message);
      } finally {
        setIsAutoCalculating(false);
      }
    }
  };

  const handleAttachmentApprovalToggle = async (attachmentId, fileName, size) => {
    const user = await base44.auth.me();
    const currentApproval = attachmentApprovals[attachmentId];
    const newApprovalState = !currentApproval?.is_approved;

    setAttachmentApprovals(prev => ({
      ...prev,
      [attachmentId]: {
        is_approved: newApprovalState,
        approved_by: newApprovalState ? user.email : null,
        approved_date: newApprovalState ? new Date().toISOString() : null,
        base44_file_uri: currentApproval?.base44_file_uri // Preserve URI
      }
    }));

    setHasUnsavedChanges(true);
  };

  const handleLogoSelection = (attachmentId) => {
    // Toggle: if clicking the same logo, deselect it
    setSelectedLogoAttachmentId(prevId => (prevId === attachmentId ? null : attachmentId));
    setHasUnsavedChanges(true);
  };

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();

      // Use the EXPLICIT status passed in data (not from state)
      // This ensures we always work with the intended new status
      const intendedNewStatus = data.status;
      const currentSubmissionStatus = submission.status;

      // AUTO-ADVANCE LOGIC: Move from initial stage to next stage on first save
      let finalStatus = intendedNewStatus;
      const isInitialStage = workflowStages.find(s => s.is_initial)?.id === currentSubmissionStatus;
      const isFirstSave = wasFirstReview; // Use the value captured when page loaded
      
      console.log('\n=== AUTO-ADVANCE CHECK ===');
      console.log('Current submission status (from DB):', currentSubmissionStatus);
      console.log('Intended new status (from user):', intendedNewStatus);
      console.log('Was first review when page loaded?', isFirstSave);
      console.log('Is initial stage?', isInitialStage);
      console.log('Will auto-advance?', isInitialStage && isFirstSave);
      console.log('Workflow stages:', workflowStages.map(s => ({ id: s.id, order: s.order, is_initial: s.is_initial })));
      
      if (isInitialStage && isFirstSave) {
        // Find next stage by order
        const currentStage = workflowStages.find(s => s.id === currentSubmissionStatus);
        console.log('Current stage found:', currentStage);
        
        const nextStage = workflowStages
          .filter(s => s.order > (currentStage?.order || 0))
          .sort((a, b) => a.order - b.order)[0];
        
        console.log('Next stage found:', nextStage);
        
        if (nextStage) {
          finalStatus = nextStage.id;
          console.log(`✓ AUTO-ADVANCING from '${currentSubmissionStatus}' to '${finalStatus}' on first save`);
          
          // Mark that we've now reviewed this submission
          setWasFirstReview(false);
        } else {
          console.log('⚠ No next stage found to advance to');
        }
      } else {
        console.log('✗ Auto-advance conditions not met:', {
          isInitialStage,
          isFirstSave,
          reason: !isInitialStage ? 'Not in initial stage' : 'Not first save (already reviewed)'
        });
      }
      console.log('Final status to save:', finalStatus);
      console.log('=== END AUTO-ADVANCE CHECK ===\n');

      const updateData = {
        status: finalStatus,
        notes: data.notes,
        reviewed_by: user.email,
        reviewed_date: new Date().toISOString(),
      };

      if (!submission.original_form_data) {
        updateData.original_form_data = initialLoadedFormData;
      }

      if (Object.keys(staticQuestionResponses).length > 0) {
        updateData.static_question_responses = staticQuestionResponses;
      }

      if (Object.keys(staticQuestionNotes).length > 0) {
        updateData.static_question_notes = staticQuestionNotes;
      }

      if (formConfig?.form_structure?.fields && formConfig.form_structure.fields.length > 0) {
        if (formConfig.scoring_approach === 'dynamic') {
          const finalFormData = {};
          formConfig.form_structure.fields.forEach(field => {
            if (field.visible !== false) {
              const baseFieldName = field.name.replace(/_First$|_Last$|_address1$|_address2$|_city$|_zipCode$|_country$/, '');
              const statusToConsider = fieldReviewStatus[baseFieldName] || fieldReviewStatus[field.name];

              if (field.type === 'name') {
                if (statusToConsider === 'approved') {
                  finalFormData[field.name + '_First'] = originalFormData[field.name + '_First'];
                  finalFormData[field.name + '_Last'] = originalFormData[field.name + '_Last'];
                } else {
                  finalFormData[field.name + '_First'] = reviewedFormData[field.name + '_First'];
                  finalFormData[field.name + '_Last'] = reviewedFormData[field.name + '_Last'];
                }
              } else {
                if (statusToConsider === 'approved') {
                  finalFormData[field.name] = originalFormData[field.name];
                } else {
                  finalFormData[field.name] = reviewedFormData[field.name];
                }
              }
            }
          });
          updateData.form_data = finalFormData;
          updateData.field_notes = fieldNotes;
        } else {
          updateData.form_data = reviewedFormData;
          updateData.field_notes = fieldNotes;
        }
      } else if (Object.keys(reviewedFormData).length > 0 || Object.keys(fieldNotes).length > 0) {
        updateData.form_data = reviewedFormData;
        updateData.field_notes = fieldNotes;
      }

      if (crmAttachments.length > 0 && (Object.keys(attachmentApprovals).length > 0 || selectedLogoAttachmentId !== null)) {
        // We need to merge the fetched crmAttachments data (which has fileName, size, signedUrl, base44FileUri from current fetch)
        // with the attachmentApprovals (which holds the is_approved, approved_by, approved_date, and base44_file_uri from existing status or user interaction)
        // Also ensure all existing metadata from submission.crm_attachments_status is preserved if not currently fetched.
        const allAttachmentsForSave = new Map();

        // 1. Add existing `crm_attachments_status` from submission, preserving all its fields
        submission.crm_attachments_status?.forEach(att => {
            allAttachmentsForSave.set(att.attachment_id, { ...att });
        });

        // 2. Overlay with currently fetched attachments (these will have latest file_name, size, base44_file_uri)
        crmAttachments.forEach(att => {
            const existing = allAttachmentsForSave.get(att.id) || {};
            allAttachmentsForSave.set(att.id, {
                attachment_id: att.id,
                file_name: att.fileName || existing.file_name,
                size: att.size || existing.size,
                base44_file_uri: att.base44FileUri || existing.base44_file_uri, // Prefer newly fetched URI if available
                is_approved: existing.is_approved || false,
                approved_by: existing.approved_by || null,
                approved_date: existing.approved_date || null,
                is_logo_attachment: existing.is_logo_attachment || false
            });
        });

        // 3. Apply `attachmentApprovals` (user's approval state)
        for (const attachmentId in attachmentApprovals) {
            const approvalState = attachmentApprovals[attachmentId];
            const current = allAttachmentsForSave.get(attachmentId) || { attachment_id: attachmentId }; // Create if not exists
            allAttachmentsForSave.set(attachmentId, {
                ...current,
                is_approved: approvalState.is_approved,
                approved_by: approvalState.approved_by,
                approved_date: approvalState.approved_date,
                base44_file_uri: current.base44_file_uri || approvalState.base44_file_uri // Ensure base44_file_uri is saved, prefer existing or approvalState's
            });
        }

        // 4. Apply `selectedLogoAttachmentId`
        allAttachmentsForSave.forEach((att, id) => {
            att.is_logo_attachment = (id === selectedLogoAttachmentId);
        });

        updateData.crm_attachments_status = Array.from(allAttachmentsForSave.values());
      }


      // CRITICAL FIX: Reconstruct agreements_status from reviewedFormData
      // This ensures newly added subform entries with signature emails are included
      console.log('\n=== RECONSTRUCTING AGREEMENTS_STATUS ===');
      const updatedAgreementsStatus = [];
      const existingAgreements = submission.agreements_status || [];
      
      if (formConfig?.form_structure?.fields) {
        // Helper function to create agreement entry identifier
        const getAgreementKey = (fieldName, parentSubformName, index) => {
          return `${fieldName}|${parentSubformName || 'null'}|${index !== null ? index : 'null'}`;
        };
        
        // Map existing agreements by their unique key for easy lookup
        const existingAgreementsMap = new Map();
        existingAgreements.forEach(agreement => {
          const key = getAgreementKey(
            agreement.signature_field_name,
            agreement.parent_subform_name,
            agreement.subform_entry_index
          );
          existingAgreementsMap.set(key, agreement);
        });
        
        // Iterate through form structure to find all signature fields
        formConfig.form_structure.fields.forEach(field => {
          // Handle top-level signature email fields
          if (field.type === 'email' && field.is_signature_email) {
            const emailValue = reviewedFormData[field.name];
            
            if (emailValue) {
              const key = getAgreementKey(field.name, null, null);
              const existing = existingAgreementsMap.get(key);
              
              // If already signed, preserve it; otherwise create/update entry
              if (existing) {
                updatedAgreementsStatus.push(existing);
              } else {
                updatedAgreementsStatus.push({
                  signature_field_name: field.name,
                  parent_subform_name: null,
                  subform_entry_index: null,
                  subform_entry_email: emailValue, // Use current reviewed email
                  is_signed: false,
                  signing_form_config_id: field.signing_form_config_id || null,
                  resend_count: 0
                });
              }
              console.log(`✓ Added top-level signature field: ${field.name}`);
            }
          }
          
          // Handle subform signature email fields
          if (field.type === 'subform' && field.subfields) {
            const signatureSubfields = field.subfields.filter(
              sf => sf.type === 'email' && sf.is_signature_email
            );
            
            if (signatureSubfields.length > 0) {
              const subformData = reviewedFormData[field.name];
              
              if (Array.isArray(subformData)) {
                subformData.forEach((row, index) => {
                  signatureSubfields.forEach(signatureSubfield => {
                    const emailValue = row[signatureSubfield.name];
                    
                    if (emailValue) {
                      const key = getAgreementKey(signatureSubfield.name, field.name, index);
                      const existing = existingAgreementsMap.get(key);
                      
                      // If already signed, preserve it; otherwise create/update entry
                      if (existing) {
                        // Update the email in case it changed
                        updatedAgreementsStatus.push({
                          ...existing,
                          subform_entry_email: emailValue
                        });
                      } else {
                        updatedAgreementsStatus.push({
                          signature_field_name: signatureSubfield.name,
                          parent_subform_name: field.name,
                          subform_entry_index: index,
                          subform_entry_email: emailValue,
                          is_signed: false,
                          signing_form_config_id: signatureSubfield.signing_form_config_id || null,
                          resend_count: 0
                        });
                      }
                      console.log(`✓ Added subform signature field: ${signatureSubfield.name} at index ${index}, email: ${emailValue}`);
                    }
                  });
                });
              }
            }
          }
        });
      }
      
      console.log(`Total agreements to be saved: ${updatedAgreementsStatus.length}`);
      updateData.agreements_status = updatedAgreementsStatus;

      // Build history log entries
      const historyEntries = [];
      const statusBeforeThisSave = lastSavedState?.status || submission.status;
      const statusActuallyChanged = statusBeforeThisSave !== finalStatus;

      // Log status change
      if (statusActuallyChanged) {
        const oldStage = workflowStages.find(s => s.id === statusBeforeThisSave);
        const newStage = workflowStages.find(s => s.id === finalStatus);
        
        historyEntries.push({
          timestamp: new Date().toISOString(),
          event_type: 'status_changed',
          user_email: user.email,
          details: {
            old_status: statusBeforeThisSave,
            old_status_label: oldStage?.label || statusBeforeThisSave,
            new_status: finalStatus,
            new_status_label: newStage?.label || finalStatus,
            workflows_triggered: data.triggerWorkflowsFlag, // Use explicit flag from data
            auto_advanced: isInitialStage && isFirstSave // Flag if this was auto-advanced
          }
        });
      }

      // Log general update
      // Check if there are changes compared to lastSavedState for a general update entry
      const notesUpdated = data.notes !== (lastSavedState?.notes || '');
      const formDataUpdated = JSON.stringify(reviewedFormData) !== JSON.stringify(lastSavedState?.reviewedFormData || {});
      const attachmentsUpdated = JSON.stringify(attachmentApprovals) !== JSON.stringify(lastSavedState?.attachmentApprovals || {});
      const staticQuestionsUpdated = JSON.stringify(staticQuestionResponses) !== JSON.stringify(lastSavedState?.staticQuestionResponses || {});
      const staticQuestionNotesUpdated = JSON.stringify(staticQuestionNotes) !== JSON.stringify(lastSavedState?.staticQuestionNotes || {});
      const logoSelectedStatusChanged = selectedLogoAttachmentId !== (lastSavedState?.selectedLogoAttachmentId || null);


      if (notesUpdated || formDataUpdated || attachmentsUpdated || staticQuestionsUpdated || staticQuestionNotesUpdated || logoSelectedStatusChanged) {
        historyEntries.push({
          timestamp: new Date().toISOString(),
          event_type: 'submission_updated',
          user_email: user.email,
          details: {
            notes_updated: notesUpdated,
            form_data_updated: formDataUpdated,
            field_notes_updated: JSON.stringify(fieldNotes) !== JSON.stringify(lastSavedState?.fieldNotes || {}),
            static_question_responses_updated: staticQuestionsUpdated,
            static_question_notes_updated: staticQuestionNotesUpdated,
            attachments_updated: attachmentsUpdated,
            logo_selection_updated: logoSelectedStatusChanged,
          }
        });
      }


      // Append to existing history
      updateData.history_log = [...(submission.history_log || []), ...historyEntries];

      return base44.entities.Submission.update(submissionId, updateData);
    },
    onSuccess: async (updatedSubmission, variables) => {
      // Update UI state to match the saved status
      setStatus(updatedSubmission.status);

      if (updatedSubmission.form_data) {
        setReviewedFormData({ ...updatedSubmission.form_data });
      }

      setLastSavedState({
        reviewedFormData: { ...updatedSubmission.form_data },
        status: updatedSubmission.status,
        notes: updatedSubmission.notes || '',
        fieldNotes: { ...(updatedSubmission.field_notes || {}) },
        staticQuestionResponses: { ...(updatedSubmission.static_question_responses || {}) },
        staticQuestionNotes: { ...(updatedSubmission.static_question_notes || {}) }, // Fixed typo here
        attachmentApprovals: updatedSubmission.crm_attachments_status ? updatedSubmission.crm_attachments_status.reduce((acc, att) => {
          acc[att.attachment_id] = {
            is_approved: att.is_approved,
            approved_by: att.approved_by,
            approved_date: att.approved_date,
            base44_file_uri: att.base44_file_uri
          };
          return acc;
        }, {}) : {},
        selectedLogoAttachmentId: updatedSubmission.crm_attachments_status?.find(att => att.is_logo_attachment === true)?.attachment_id || null
      });

      // Explicitly clear the navigation guard after successful save
      setHasUnsavedChanges(false);

      queryClient.invalidateQueries(['submission', submissionId]);
      queryClient.invalidateQueries(['submissions']);
      toast.success('Submission updated successfully');
      setShowNotesEditor(false);

      // Track the status BEFORE this save operation
      const statusBeforeThisSave = lastSavedState?.status || submission.status;
      const statusAfterThisSave = updatedSubmission.status;
      const statusActuallyChanged = statusBeforeThisSave !== statusAfterThisSave;

      // Get the explicit trigger flag from the mutation variables
      const shouldTriggerWorkflows = variables.triggerWorkflowsFlag || false;

      console.log('\n=== WORKFLOW TRIGGER CHECK ===');
      console.log('Status before save:', statusBeforeThisSave);
      console.log('Status after save:', statusAfterThisSave);
      console.log('Status actually changed:', statusActuallyChanged);
      console.log('User chose to trigger workflows:', shouldTriggerWorkflows);

      // CRITICAL: Only trigger workflows if BOTH conditions are true:
      // 1. Status actually changed from last saved value
      // 2. User explicitly chose to trigger workflows via the dialog
      if (!statusActuallyChanged) {
        console.log('✓ Status unchanged - skipping all workflow triggers');
        return;
      }

      if (!shouldTriggerWorkflows) {
        console.log('✓ User disabled workflows - skipping all workflow triggers');
        return;
      }

      console.log('→ Proceeding with workflow triggers...');

      // CHECKING FOR SIGNATURE WEBHOOKS
      if (formConfig?.form_structure?.fields) {
        const signatureFieldsToTrigger = [];

        const findSignatureFields = (fieldsArray) => {
          for (const field of fieldsArray) {
            if (field.type === 'email' && field.is_signature_email === true) {
              const triggerStage = field.signature_trigger_stage_id || 'verified';
              
              // Trigger only if status *changed to* the trigger stage
              if (statusBeforeThisSave !== triggerStage && updatedSubmission.status === triggerStage) {
                if (field.signature_webhook_address && field.signature_form_permalink && field.signing_form_config_id) {
                  signatureFieldsToTrigger.push(field);
                } else {
                  console.warn(`Signature field ${field.name} is configured to trigger on '${triggerStage}' but is missing full configuration.`);
                }
              }
            } else if (field.type === 'subform' && field.subfields) {
              for (const subfield of field.subfields) {
                if (subfield.type === 'email' && subfield.is_signature_email === true) {
                  const triggerStage = subfield.signature_trigger_stage_id || 'verified';
                  
                  // Trigger only if status *changed to* the trigger stage
                  if (statusBeforeThisSave !== triggerStage && updatedSubmission.status === triggerStage) {
                    if (subfield.signature_webhook_address && subfield.signature_form_permalink && subfield.signing_form_config_id) {
                      signatureFieldsToTrigger.push(subfield);
                    } else {
                      console.warn(`Signature subfield ${subfield.name} is configured to trigger on '${triggerStage}' but is missing full configuration.`);
                    }
                  }
                }
              }
            }
          }
        };
        
        findSignatureFields(formConfig.form_structure.fields);

        if (signatureFieldsToTrigger.length > 0) {
          toast.info(`Triggering ${signatureFieldsToTrigger.length} signature request(s) for status '${updatedSubmission.status}'`);
          try {
            const results = await Promise.allSettled(signatureFieldsToTrigger.map(async (field) => {
              try {
                const result = await base44.functions.invoke('triggerSignatureWebhook', {
                  submissionId: updatedSubmission.id,
                  signatureFieldName: field.name,
                });

                return { field, result };
              } catch (error) {
                return { field, error };
              }
            }));

            let successCount = 0;
            let failureCount = 0;

            results.forEach((promiseResult) => {
              if (promiseResult.status === 'fulfilled') {
                const { field, result, error } = promiseResult.value;
                if (error) {
                  console.error(`Failed to trigger signature for '${field.label || field.name}':`, error);
                  toast.error(`Failed to trigger signature for '${field.label || field.name}': ${error.message}`);
                  failureCount++;
                } else if (result?.data?.success) {
                  toast.success(`Signature request sent for '${field.label || field.name}'`);
                  successCount++;
                } else {
                  toast.error(`Failed to trigger signature for '${field.label || field.name}': ${result?.data?.message || 'Unknown error'}`);
                  failureCount++;
                }
              } else {
                failureCount++;
                console.error('Promise rejected:', promiseResult.reason);
              }
            });

            if (successCount > 0 && failureCount === 0) {
              toast.success(`All ${successCount} signature request(s) sent successfully`);
            } else if (successCount > 0 && failureCount > 0) {
              toast.info(`${successCount} signature request(s) sent, ${failureCount} failed`);
            } else if (failureCount > 0) {
              toast.error(`Failed to send ${failureCount} signature request(s)`);
            }
          } catch (error) {
            console.error('Error triggering signature webhooks:', error);
            toast.error('An error occurred while triggering signature requests');
          }
        } else {
          console.log(`No signature fields configured to trigger on status change to '${updatedSubmission.status}'`);
        }
      }

      console.log('\n=== CHECKING FOR STATUS CHANGE WEBHOOKS ===');
      if (formConfig?.status_change_webhooks && formConfig.status_change_webhooks.length > 0) {
        const webhooksToTrigger = formConfig.status_change_webhooks.filter(
          webhook => webhook.enabled !== false && 
                     webhook.trigger_status_id === updatedSubmission.status &&
                     statusBeforeThisSave !== updatedSubmission.status // Only trigger if status actually changed
        );

        // Custom message prompting is now handled BEFORE mutation in confirmStatusChange
        // So webhooksToTrigger here will already have custom messages if needed

        if (webhooksToTrigger.length > 0) {
          console.log(`Found ${webhooksToTrigger.length} status webhook(s) to trigger for status '${updatedSubmission.status}'`);
          toast.info(`Triggering ${webhooksToTrigger.length} status webhook(s)...`);

          try {
            const webhookResults = await Promise.allSettled(webhooksToTrigger.map(async (webhookConfig) => {
              try {
                console.log(`→ Triggering webhook: ${webhookConfig.name}`);

                const invokeParams = {
                  submissionId: updatedSubmission.id,
                  webhookConfig: webhookConfig,
                  oldStatus: statusBeforeThisSave,
                  newStatus: updatedSubmission.status
                };

                // Add custom message if this webhook requires it
                if (webhookConfig.prompt_for_custom_message && variables.customWebhookMessages) {
                  const messageData = variables.customWebhookMessages.find(m => m.webhookId === webhookConfig.id);
                  if (messageData) {
                    invokeParams.customMessage = messageData.message;
                  }
                }

                const result = await base44.functions.invoke('triggerStatusWebhook', invokeParams);

                return { webhookConfig, result };
              } catch (error) {
                return { webhookConfig, error };
              }
            }));

            let successCount = 0;
            let failureCount = 0;

            webhookResults.forEach((promiseResult) => {
              if (promiseResult.status === 'fulfilled') {
                const { webhookConfig, result, error } = promiseResult.value;
                if (error) {
                  console.error(`Failed to trigger webhook '${webhookConfig.name}':`, error);
                  toast.error(`Failed to trigger webhook '${webhookConfig.name}': ${error.message}`);
                  failureCount++;
                } else if (result?.data?.success) {
                  toast.success(`Webhook '${webhookConfig.name}' triggered successfully`);
                  successCount++;
                } else {
                  toast.error(`Failed to trigger webhook '${webhookConfig.name}': ${result?.data?.message || 'Unknown error'}`);
                  failureCount++;
                }
              } else {
                failureCount++;
                console.error('Promise rejected:', promiseResult.reason);
              }
            });

            if (successCount > 0 && failureCount === 0) {
              toast.success(`All ${successCount} status webhook(s) triggered successfully`);
            } else if (successCount > 0 && failureCount > 0) {
              toast.info(`${successCount} webhook(s) triggered, ${failureCount} failed`);
            } else if (failureCount > 0) {
              toast.error(`Failed to trigger ${failureCount} webhook(s)`);
            }
          } catch (error) {
            console.error('Error triggering status webhooks:', error);
            toast.error('An error occurred while triggering status webhooks');
          }
        } else {
          console.log(`No status webhooks configured or triggered for status change to '${updatedSubmission.status}'`);
        }
      }

      // TRIGGER LOGO UPLOAD TO CRM IF STATUS MATCHES CONFIGURED TRIGGER
      const logoConfig = formConfig?.crm_logo_upload_config;
      const logoTriggerStatus = logoConfig?.trigger_status_id || 'approved'; // Default to 'approved' for backward compatibility
      
      if (logoConfig?.enabled && selectedLogoAttachmentId && 
          statusBeforeThisSave !== logoTriggerStatus && updatedSubmission.status === logoTriggerStatus) { // Only trigger if status *changed to* the trigger stage
        console.log('\n=== TRIGGERING LOGO UPLOAD TO CRM ===');
        console.log(`Status changed to '${updatedSubmission.status}' - triggering logo upload`);
        toast.info('Uploading organization logo to CRM...');
        
        try {
          const logoUploadResult = await base44.functions.invoke('uploadLogoToCrm', {
            submissionId: updatedSubmission.id
          });

          if (logoUploadResult.data.success) {
            toast.success(`Logo uploaded to CRM successfully: ${logoUploadResult.data.message}`);
          } else {
            toast.error(`Failed to upload logo to CRM: ${logoUploadResult.data.message}`);
          }
        } catch (error) {
          console.error('Error uploading logo to CRM:', error);
          toast.error(`Error uploading logo to CRM: ${error.message}`);
        }
      } else if (logoConfig?.enabled && selectedLogoAttachmentId) {
        console.log(`\nLogo upload not triggered: Current status is '${updatedSubmission.status}', trigger status is '${logoTriggerStatus}'`);
      }
    },
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      const user = await base44.auth.me();
      const dataToRevertTo = submission.original_form_data || {};
      const initialStageId = workflowStages.find(s => s.is_initial)?.id || 'new';

      const historyEntry = {
        timestamp: new Date().toISOString(),
        event_type: 'submission_reset',
        user_email: user.email,
        details: {
          previous_status: submission.status,
          previous_score: submission.due_diligence_score,
          previous_risk_level: submission.risk_level
        }
      };

      return base44.entities.Submission.update(submissionId, {
        status: initialStageId,
        notes: '',
        field_notes: {},
        static_question_responses: {},
        static_question_notes: {},
        due_diligence_score: null,
        risk_level: null,
        reviewed_by: null,
        reviewed_date: null,
        form_data: dataToRevertTo,
        crm_attachments_status: [], // Clear all attachment statuses, including logo
        history_log: [...(submission.history_log || []), historyEntry],
        agreements_status: [] // Clear all agreements on reset
      });
    },
    onSuccess: () => {
      const dataToRevertTo = submission.original_form_data || {};
      const initialStageId = workflowStages.find(s => s.is_initial)?.id || 'new';

      setStatus(initialStageId);
      setNotes('');
      setFieldNotes({});
      setStaticQuestionResponses({});
      setStaticQuestionNotes({});
      setFieldReviewStatus({}); // Reset all field review statuses
      setReviewedFormData({ ...dataToRevertTo });
      setAttachmentApprovals({});
      setSelectedLogoAttachmentId(null); // Reset selected logo

      setShowNotesEditor(false);

      setLastSavedState({
        reviewedFormData: { ...dataToRevertTo },
        status: initialStageId,
        notes: '',
        fieldNotes: {},
        staticQuestionResponses: {},
        staticQuestionNotes: {},
        attachmentApprovals: {},
        selectedLogoAttachmentId: null
      });

      setHasUnsavedChanges(false); // Clear navigation guard after reset

      queryClient.invalidateQueries(['submission', submissionId]);
      queryClient.invalidateQueries(['submissions']);
      toast.success('Submission has been reset successfully');
      setShowResetModal(false);
      setResetConfirmText('');
    },
    onError: (error) => {
      toast.error('Failed to reset submission: ' + error.message);
    }
  });

  const calculateScore = async () => {
    setIsCalculatingScore(true);
    try {
      let response;

      if (formConfig.scoring_approach === 'static_traffic_light') {
        response = await base44.functions.invoke('calculateStaticTrafficLightScore', {
          submissionId: submissionId,
          responses: staticQuestionResponses
        });
      } else {
        response = await base44.functions.invoke('calculateDueDiligenceScore', {
          submissionId: submissionId
        });
      }

      if (response.data.success) {
        toast.success(`Score calculated: ${response.data.score}% (${response.data.riskLevel} risk)`);
        queryClient.invalidateQueries(['submission', submissionId]);
      } else {
        toast.error(response.data.message || 'Failed to calculate score');
      }
    } catch (error) {
      toast.error('Error calculating score: ' + error.message);
    } finally {
      setIsCalculatingScore(false);
    }
  };

  const handleSave = (explicitStatus, explicitTriggerFlag) => {
    // Use explicit parameters if provided, otherwise fall back to state
    const statusToSave = explicitStatus !== undefined ? explicitStatus : status;
    const triggerFlag = explicitTriggerFlag !== undefined ? explicitTriggerFlag : false; // Default to false if not provided explicitly
    
    updateMutation.mutate({ 
      status: statusToSave, 
      notes,
      triggerWorkflowsFlag: triggerFlag,
      customWebhookMessages: undefined // Will be set when custom messages are provided
    });
  };
  
  const handleCustomMessageSubmit = async () => {
    if (!customMessageInput.trim()) {
      toast.error('Please enter a message');
      return;
    }
    
    setShowCustomMessageDialog(false);
    
    // Create message data for all pending webhooks
    const messageData = pendingWebhooksWithMessages.map(webhook => ({
      webhookId: webhook.id,
      message: customMessageInput.trim()
    }));
    
    // Use pendingStatusChange (the new status) instead of current status state
    const newStatus = pendingStatusChange;
    
    // Continue with the mutation, passing the custom messages
    updateMutation.mutate({
      status: newStatus,
      notes,
      triggerWorkflowsFlag: true,
      customWebhookMessages: messageData
    });
    
    // Reset
    setCustomMessageInput('');
    setPendingWebhooksWithMessages([]);
    setPendingStatusChange(null);
  };

  const handleReset = () => {
    if (resetConfirmText === 'RESET') {
      resetMutation.mutate();
    }
  };

  const handleResendSignature = async (signatureFieldName, parentSubformName = null, subformEntryIndex = null) => {
    try {
      toast.info('Resending signature request...');
      
      const result = await base44.functions.invoke('triggerSignatureWebhook', {
        submissionId: submission.id,
        signatureFieldName: signatureFieldName,
        parentSubformName: parentSubformName,
        subformEntryIndex: subformEntryIndex
      });

      if (result.data.success) {
        toast.success('Signature request resent successfully');
        queryClient.invalidateQueries(['submission', submissionId]);
      } else {
        toast.error(result.data.message || 'Failed to resend signature request');
      }
    } catch (error) {
      toast.error('Error resending signature: ' + error.message);
    }
  };

  const handleBackNavigation = () => {
    attemptNavigation(createPageUrl('Submissions'));
  };

  const handleSwapFormType = async () => {
    if (!selectedTargetFormId) {
      toast.error('Please select a target form');
      return;
    }

    setIsSwapping(true);
    try {
      const result = await base44.functions.invoke('swapSubmissionFormType', {
        sourceSubmissionId: submission.id,
        targetFormConfigId: selectedTargetFormId
      });

      if (result.data.success) {
        toast.success(`Swapped to new form: ${result.data.fieldsCopied}/${result.data.totalFields} fields copied`);
        setShowSwapFormDialog(false);
        
        // Navigate to the new submission
        setTimeout(() => {
          navigate(createPageUrl(`ReviewSubmission?id=${result.data.newSubmissionId}`));
        }, 1000);
      } else {
        toast.error(result.data.message || 'Failed to swap form type');
      }
    } catch (error) {
      toast.error('Error swapping form: ' + error.message);
    } finally {
      setIsSwapping(false);
    }
  };

  const getFileExtension = (filename) => {
    return filename?.split('.').pop()?.toLowerCase() || '';
  };

  const isImageFile = (filename) => {
    const ext = getFileExtension(filename);
    return ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'].includes(ext);
  };

  const isPdfFile = (filename) => {
    return getFileExtension(filename) === 'pdf';
  };

  const handlePreviewAttachment = (attachment) => {
    setPreviewAttachment(attachment);
    setShowPreviewModal(true);
  };

  const getSignatureStatusForField = (fieldName) => {
    if (!submission?.agreements_status) return null;
    return submission.agreements_status.find(
      agreement => agreement.signature_field_name === fieldName && !agreement.parent_subform_name
    );
  };

  const getSubformSignatureStatuses = (subformFieldName, subfields) => {
    if (!subfields || !submission?.agreements_status) return {};
    
    const statuses = {};
    
    subfields.forEach(subfield => {
      if (subfield.type === 'email' && subfield.is_signature_email) {
        const agreementsForField = submission.agreements_status.filter(
          agreement => 
            agreement.signature_field_name === subfield.name &&
            agreement.parent_subform_name === subformFieldName
        );
        
        agreementsForField.forEach(agreement => {
          const index = agreement.subform_entry_index;
          if (index !== null && index !== undefined) {
            const key = `${subfield.name}_${index}`;
            statuses[key] = agreement;
          }
        });
      }
    });
    
    return statuses;
  };

  if (isAuthenticated === null || isLoading) {
    return (
      <div className="p-6 md:p-8">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      </div>
    );
  }

  if (!submission) {
    return (
      <div className="p-6 md:p-8">
        <Card>
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 mx-auto text-red-500 mb-4" />
            <p className="text-lg font-medium">Submission not found</p>
            <Button
              onClick={() => navigate(createPageUrl('Submissions'))}
              className="mt-4"
            >
              Back to Submissions
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const statusColors = {
    new: "bg-orange-100 text-orange-800",
    in_review: "bg-purple-100 text-purple-800",
    verified: "bg-blue-100 text-blue-800",
    approved: "bg-green-100 text-green-800",
    rejected: "bg-red-100 text-red-800",
  };

  const riskColors = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  const isDynamicScoring = formConfig?.scoring_approach === 'dynamic';
  const isStaticScoring = formConfig?.scoring_approach === 'static_traffic_light';
  const hasCrmDocs = formConfig?.crm_attachment_config?.enabled === true;

  // Get organization name from form data
  const organizationName = formConfig?.applicant_organization_name_field 
    ? submission.form_data?.[formConfig.applicant_organization_name_field] || 'Organization Not Specified'
    : submission.applicant_name || 'Unnamed Applicant';

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6 md:p-8 font-sans flex flex-col">
      <div className="max-w-7xl mx-auto w-full flex flex-col h-full space-y-6">
        <div className="flex-shrink-0 relative">
          <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 shadow-lg border border-white/20">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                onClick={handleBackNavigation}
                className="hover:bg-blue-50 transition-colors px-4 py-2 flex items-center gap-2" // Adjust padding to accommodate text, remove size="icon"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <h1 className="text-2xl font-bold text-gray-900">{organizationName}</h1>
                  {hasUnsavedChanges && (
                    <Badge className="bg-orange-100 text-orange-800 border-orange-300">
                      Unsaved Changes
                    </Badge>
                  )}
                  {submission.dd_call_date && (
                    <Badge className="bg-cyan-100 text-cyan-800 border-cyan-300 gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      DD Call: {format(new Date(submission.dd_call_date), 'MMM d, yyyy h:mm a')}
                    </Badge>
                  )}
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium text-gray-700">{submission.applicant_name || 'Unnamed Applicant'}</p>
                  <p className="text-sm text-gray-600">{submission.applicant_email}</p>
                </div>
              </div>
              <div className="flex items-end gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setShowNotesEditor(!showNotesEditor)}
                  className="hover:bg-blue-50 transition-colors"
                  title="Open Notes Editor"
                >
                  <NotebookText className="w-5 h-5" />
                </Button>
                <div>
                  <Label className="text-sm font-semibold mb-1 block text-gray-700">Status</Label>
                  <Select value={status} onValueChange={handleStatusChange}>
                    <SelectTrigger className="w-48 border-2 hover:border-blue-500 transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <TooltipProvider>
                        {sortedStages.map((stage) => {
                          const evaluation = evaluateStageConditions(stage);
                          const isDisabled = !evaluation.canSelect;
                          
                          const itemContent = (
                            <div className="flex items-center gap-2">
                              <span>{stage.label}</span>
                              {isDisabled && (
                                <span className="text-xs text-orange-600">
                                  🔒
                                </span>
                              )}
                            </div>
                          );

                          return (
                            <SelectItem 
                              key={stage.id} 
                              value={stage.id}
                              disabled={isDisabled}
                              className={cn(
                                isDisabled && "opacity-50 cursor-not-allowed"
                              )}
                            >
                              {isDisabled ? (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    {itemContent}
                                  </TooltipTrigger>
                                  <TooltipContent className="bg-red-800 text-white border-red-900 shadow-lg max-w-xs">
                                    <p className="font-semibold mb-1">Cannot select "{stage.label}"</p>
                                    <ul className="text-xs list-disc list-inside space-y-0.5">
                                      {evaluation.reasons.map((reason, idx) => (
                                        <li key={idx}>{reason}</li>
                                      ))}
                                    </ul>
                                  </TooltipContent>
                                </Tooltip>
                              ) : (
                                itemContent
                              )}
                            </SelectItem>
                          );
                        })}
                      </TooltipProvider>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  onClick={() => handleSave(undefined, false)} // Default save, no explicit status change, no workflow trigger
                  disabled={updateMutation.isPending || !hasUnsavedChanges}
                  className={cn(
                    "gap-2 shadow-lg transition-all",
                    !hasUnsavedChanges 
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed" 
                      : "bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white"
                  )}
                >
                  <Save className="w-4 h-4" />
                  {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
                <Button
                  onClick={() => setShowHistoryModal(true)}
                  className="gap-2 bg-slate-600 hover:bg-slate-700 text-white shadow-lg"
                >
                  <History className="w-4 h-4" />
                  History
                </Button>
                <Button
                  onClick={() => setShowSwapFormDialog(true)}
                  className="gap-2 bg-purple-600 hover:bg-purple-700 text-white shadow-lg"
                >
                  <RepeatIcon className="w-4 h-4" />
                  Swap Form
                </Button>
                <Button
                  onClick={() => setShowResetModal(true)}
                  disabled={resetMutation.isPending}
                  className="gap-2 bg-red-100 hover:bg-red-200 text-red-700 shadow-lg"
                  variant="outline"
                >
                  <RotateCcw className="w-4 h-4" />
                  Reset
                </Button>
              </div>
            </div>
          </div>

          <div
            className={`absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-2xl border-2 border-blue-200 overflow-hidden transition-all duration-300 ease-in-out z-50 ${
              showNotesEditor ? 'max-h-[600px] opacity-100' : 'max-h-0 opacity-0'
            }`}
          >
            <div className="bg-gradient-to-r from-slate-700 to-slate-800 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <NotebookText className="w-5 h-5" />
                <h3 className="font-semibold text-lg">Due Diligence Notes</h3>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowNotesEditor(false)}
                className="hover:bg-slate-600 text-white"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="p-6">
              <ReactQuill
                value={notes}
                onChange={setNotes}
                className="bg-white"
                style={{ height: '400px', marginBottom: '50px' }}
                modules={{
                  toolbar: [
                    [{ 'header': [1, 2, 3, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                    [{ 'color': [] }, { 'background': [] }],
                    ['link'],
                    ['clean']
                  ]
                }}
                placeholder="Add your due diligence notes here..."
              />
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 flex-1 overflow-hidden">
          <div className="lg:col-span-2 flex flex-col overflow-hidden">
            <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm flex flex-col flex-1 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg flex-shrink-0">
                <CardTitle className="text-xl">
                  Application Fields Review
                </CardTitle>
                <p className="text-blue-100 text-sm mt-1">
                  Review each submitted field. For forms with static (traffic light) questions, please refer to the right panel.
                </p>
              </CardHeader>
              <CardContent className="p-6 overflow-y-auto flex-1">
                {formConfig?.form_structure?.fields?.length > 0 ? (
                  <div className="grid grid-cols-2 gap-6">
                    <div className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Original Submission</div>
                    <div className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Reviewer's Amendment</div>
                    {formConfig.form_structure.fields
                      .filter(field => field.visible !== false)
                      .map((field, index) => {
                        let signatureStatus = null;
                        let subformSignatureStatuses = {};
                        
                        if (field.type === 'email' && field.is_signature_email) {
                          signatureStatus = getSignatureStatusForField(field.name);
                        } else if (field.type === 'subform' && field.subfields) {
                          subformSignatureStatuses = getSubformSignatureStatuses(field.name, field.subfields);
                        }

                        // Get the base field name to handle composite fields like Name_First/Name_Last
                        const baseFieldName = field.name.replace(/_First$|_Last$|_address1$|_address2$|_city$|_zipCode$|_country$/, '');
                        const reviewStatusForField = fieldReviewStatus[baseFieldName] || fieldReviewStatus[field.name];

                        return (
                          <ReviewFieldEditor
                            key={field.name}
                            field={field}
                            originalFormData={originalFormData}
                            reviewedFormData={reviewedFormData}
                            reviewStatus={reviewStatusForField}
                            onChange={handleFieldChange}
                            sequenceNumber={index + 1}
                            note={fieldNotes[field.name] || ''}
                            onNoteChange={handleFieldNoteChange}
                            signatureStatus={signatureStatus}
                            subformSignatureStatuses={subformSignatureStatuses}
                            onResendSignature={handleResendSignature}
                            submissionId={submission.id}
                          />
                        );
                      })}
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>
                      No form fields are configured for review in this form structure.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-col gap-6 overflow-hidden h-full">
            <div className="flex-shrink-0 bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-xl p-4 shadow-lg">
              <div className="mb-4">
                <span className="text-sm font-medium text-blue-100">Due Diligence Score</span>
              </div>
              <ScoreGradient
                score={submission.due_diligence_score}
                riskLevel={submission.risk_level}
                customRiskLevels={formConfig?.custom_risk_levels}
              />
            </div>

            {hasCrmDocs && (
              <Button
                onClick={handleOpenAttachmentsModal}
                variant="outline"
                className="flex flex-col h-auto p-4 items-start bg-white/90 backdrop-blur-sm shadow-xl border-2 border-purple-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 transition-all text-left flex-shrink-0"
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <div className="flex items-center gap-2 text-gray-900">
                    <FileText className="w-5 h-5 text-purple-600" />
                    <span className="text-lg font-semibold">{formConfig.crm_attachment_config.label || 'Documents'}</span>
                  </div>
                  <Badge className="bg-purple-100 text-purple-700 border-purple-300">
                    {submission.crm_attachments_status?.filter(a => a.is_approved).length || 0}/{submission.crm_attachments_status?.length || 0} Approved
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">
                  Click to view and manage CRM documents
                </p>
              </Button>
            )}

            {isStaticScoring && formConfig.static_questions?.length > 0 && (
              <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm flex flex-col flex-1 overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-lg flex-shrink-0">
                  <CardTitle className="text-lg">Due Diligence Questions</CardTitle>
                  <p className="text-purple-100 text-sm mt-1">Answer each question using the traffic light system</p>
                </CardHeader>
                <CardContent className="p-4 space-y-4 overflow-y-auto flex-1">
                  {formConfig.static_questions.map((item, index) => {
                    const itemWithType = item.type ? item : { ...item, type: 'question' };
                    
                    const questionNumber = formConfig.static_questions
                      .slice(0, index)
                      .filter(q => (q.type || 'question') === 'question').length + 1;
                    
                    return (
                      <StaticQuestionReview
                        key={item.id || `item-${index}`}
                        item={itemWithType}
                        response={staticQuestionResponses[item.id]}
                        onChange={handleStaticQuestionResponse}
                        questionNumber={itemWithType.type === 'question' ? questionNumber : null}
                        note={staticQuestionNotes[item.id] || ''}
                        onNoteChange={handleStaticQuestionNoteChange}
                      />
                    );
                  })}
                </CardContent>
              </Card>
            )}

            {!formConfig?.scoring_rules && !formConfig?.static_questions && (
              <Alert className="bg-blue-800 border-blue-700 text-white">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-xs text-blue-100">
                  No scoring rules (for dynamic scoring) or static questions (for traffic light scoring) configured for this form.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </div>
      </div>

      <Dialog open={showResetModal} onOpenChange={setShowResetModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              Reset Submission
            </DialogTitle>
            <DialogDescription className="space-y-3 pt-4">
              <p className="font-semibold text-gray-900">
                This action will permanently delete all review data including:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                <li>All field amendments and approvals</li>
                <li>All field notes</li>
                <li>Static question responses and notes</li>
                <li>Due diligence score and risk level</li>
                <li>General notes</li>
                <li>Review history</li>
                <li>CRM document approvals</li>
                <li>All pending signature requests</li>
              </ul>
              <p className="font-semibold text-red-700 pt-2">
                The submission will return to its original state as if never reviewed.
              </p>
              <div className="pt-4">
                <Label htmlFor="reset-confirm" className="text-sm font-semibold text-gray-700">
                  Type <span className="font-mono bg-gray-100 px-2 py-1 rounded">RESET</span> to confirm:
                </Label>
                <Input
                  id="reset-confirm"
                  value={resetConfirmText}
                  onChange={(e) => setResetConfirmText(e.target.value)}
                  placeholder="Type RESET here"
                  className="mt-2 font-mono"
                  autoComplete="off"
                />
              </div>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setShowResetModal(false);
                setResetConfirmText('');
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleReset}
              disabled={resetConfirmText !== 'RESET' || resetMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {resetMutation.isPending ? 'Resetting...' : 'Confirm Reset'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showPreviewModal} onOpenChange={setShowPreviewModal}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-purple-600" />
              {previewAttachment?.fileName}
            </DialogTitle>
            <DialogDescription className="flex items-center gap-4 text-sm">
              <span>{previewAttachment?.size ? `${(previewAttachment.size / 1024).toFixed(1)} KB` : 'Unknown size'}</span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  const link = document.createElement('a');
                  link.href = previewAttachment.signedUrl;
                  link.download = previewAttachment.fileName;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                }}
                className="gap-2"
              >
                <Download className="w-3 h-3" />
                Download
              </Button>
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 overflow-hidden mt-4">
            {previewAttachment && (
              <>
                {isPdfFile(previewAttachment.fileName) ? (
                  <iframe
                    src={previewAttachment.signedUrl}
                    className="w-full h-full border rounded-lg"
                    title={previewAttachment.fileName}
                  />
                ) : isImageFile(previewAttachment.fileName) ? (
                  <div className="w-full h-full flex items-center justify-center bg-gray-50 rounded-lg overflow-auto">
                    <img
                      src={previewAttachment.signedUrl}
                      alt={previewAttachment.fileName}
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gray-50 rounded-lg p-8">
                    <FileText className="w-16 h-16 text-gray-400 mb-4" />
                    <p className="text-lg font-medium text-gray-700 mb-2">Preview not available</p>
                    <p className="text-sm text-gray-500 mb-6 text-center">
                      This file type cannot be previewed in the browser. Please download the file to view it.
                    </p>
                    <Button
                      onClick={() => {
                        const link = document.createElement('a');
                        link.href = previewAttachment.signedUrl;
                        link.download = previewAttachment.fileName;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      }}
                      className="gap-2 bg-purple-600 hover:bg-purple-700"
                    >
                      <Download className="w-4 h-4" />
                      Download File
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showAttachmentsModal} onOpenChange={setShowAttachmentsModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-purple-600" />
              {formConfig?.crm_attachment_config?.label || 'CRM Documents'}
            </DialogTitle>
            {crmAttachments.length > 0 && (
              <DialogDescription className="flex items-center gap-3">
                <Badge className="bg-purple-100 text-purple-700">
                  {Object.values(attachmentApprovals).filter(a => a.is_approved).length}/{crmAttachments.length} Approved
                </Badge>
                {selectedLogoAttachmentId && (
                  <Badge className="bg-blue-100 text-blue-700">
                    Organization Logo Set
                  </Badge>
                )}
              </DialogDescription>
            )}
          </DialogHeader>
          <div className="flex-1 overflow-y-auto mt-4">
            {loadingAttachments ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
                <span className="ml-2 text-sm text-gray-600">Loading documents...</span>
              </div>
            ) : attachmentsError ? (
              <Alert className="bg-orange-50 border-orange-200">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-sm text-orange-800">
                  {attachmentsError}
                </AlertDescription>
              </Alert>
            ) : crmAttachments.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p className="text-sm">No documents found</p>
              </div>
            ) : (
              <div className="space-y-2">
                {crmAttachments.map((att) => {
                  const isApproved = attachmentApprovals[att.id]?.is_approved || false;
                  const isLogo = selectedLogoAttachmentId === att.id;
                  
                  return (
                    <div 
                      key={att.id} 
                      className={cn(
                        "flex items-center justify-between p-3 border rounded-lg transition-all",
                        isLogo ? "bg-blue-50 border-blue-300" : (isApproved ? "bg-green-50 border-green-200" : "hover:bg-purple-50")
                      )}
                    >
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            id={`approve-${att.id}`}
                            checked={isApproved}
                            onChange={() => handleAttachmentApprovalToggle(att.id, att.fileName, att.size)}
                            className="w-5 h-5 rounded border-gray-300 text-green-600 focus:ring-green-500 cursor-pointer"
                          />
                          <Label htmlFor={`approve-${att.id}`} className="text-xs text-gray-600 cursor-pointer">
                            Approved
                          </Label>
                        </div>
                        <div className="flex items-center gap-2 ml-7">
                          <input
                            type="radio"
                            id={`logo-${att.id}`}
                            name="organization-logo"
                            checked={isLogo}
                            onChange={() => handleLogoSelection(att.id)}
                            className="w-4 h-4 text-blue-600 focus:ring-blue-500 cursor-pointer"
                          />
                          <Label htmlFor={`logo-${att.id}`} className="text-xs text-gray-600 cursor-pointer">
                            Set as Logo
                          </Label>
                        </div>
                      </div>
                      <div className="flex-1 min-w-0 ml-4">
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-sm truncate">{att.fileName}</p>
                          {isApproved && (
                            <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                          )}
                          {isLogo && (
                            <Badge className="bg-blue-100 text-blue-700 text-xs">Organization Logo</Badge>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">
                          {att.size ? `${(att.size / 1024).toFixed(1)} KB` : 'Unknown size'}
                        </p>
                        {isApproved && attachmentApprovals[att.id]?.approved_by && (
                          <p className="text-xs text-green-700 mt-1">
                            Approved by {attachmentApprovals[att.id].approved_by}
                          </p>
                        )}
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handlePreviewAttachment(att)}
                          className="gap-1"
                          title="Preview"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = att.signedUrl;
                            link.download = att.fileName;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                          }}
                          className="gap-1"
                          title="Download"
                        >
                          <Download className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Status Change Confirmation Dialog */}
      <Dialog open={showStatusChangeDialog} onOpenChange={setShowStatusChangeDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-orange-700">
              <AlertCircle className="w-5 h-5" />
              Confirm Status Change
            </DialogTitle>
            <DialogDescription className="space-y-4 pt-4">
              <p className="font-semibold text-gray-900">
                You are changing the status from{' '}
                <span className="text-blue-700">
                  {sortedStages.find(s => s.id === status)?.label}
                </span>
                {' '}to{' '}
                <span className="text-green-700">
                  {sortedStages.find(s => s.id === pendingStatusChange)?.label}
                </span>
              </p>
              
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 space-y-2">
                <p className="font-semibold text-amber-900">
                  This status change may trigger:
                </p>
                <ul className="list-disc list-inside space-y-1 text-sm text-amber-800">
                  <li>Signature request emails</li>
                  <li>Status change webhooks</li>
                  <li>Logo uploads to CRM</li>
                  <li>Other automated workflows</li>
                </ul>
              </div>

              <p className="text-sm text-gray-700">
                Do you want to proceed with this status change and trigger the associated workflows?
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex-col gap-2 sm:flex-col">
            <Button
              onClick={() => confirmStatusChange(true)}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              Change Status & Trigger Workflows
            </Button>
            <Button
              onClick={() => confirmStatusChange(false)}
              variant="outline"
              className="w-full"
            >
              Change Status Only (No Workflows)
            </Button>
            <Button
              onClick={cancelStatusChange}
              variant="ghost"
              className="w-full"
            >
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Custom Message Dialog */}
      <Dialog open={showCustomMessageDialog} onOpenChange={setShowCustomMessageDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-600" />
              {pendingWebhooksWithMessages[0]?.custom_message_prompt_label || 'Custom Message'}
            </DialogTitle>
            <DialogDescription className="space-y-3 pt-2">
              <p className="text-sm text-gray-700">
                This webhook requires a custom message. Please enter your message below:
              </p>
              {pendingWebhooksWithMessages.length > 1 && (
                <p className="text-xs text-gray-600 bg-blue-50 p-2 rounded">
                  This message will be sent with {pendingWebhooksWithMessages.length} webhooks: {pendingWebhooksWithMessages.map(w => w.name).join(', ')}
                </p>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea
              value={customMessageInput}
              onChange={(e) => setCustomMessageInput(e.target.value)}
              placeholder="Enter your message here..."
              rows={5}
              className="resize-none"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowCustomMessageDialog(false);
                setCustomMessageInput('');
                setPendingWebhooksWithMessages([]);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleCustomMessageSubmit}
              disabled={!customMessageInput.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Send Message
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* History Modal */}
      <Dialog open={showHistoryModal} onOpenChange={setShowHistoryModal}>
        <DialogContent className="max-w-4xl h-[90vh] flex flex-col">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2 text-xl">
                <History className="w-6 h-6" />
                Submission History
              </DialogTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => queryClient.invalidateQueries(['submission', submissionId])}
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Refresh
              </Button>
            </div>
            </DialogHeader>
            <div className="flex-1 overflow-hidden">
            <SubmissionHistoryLog 
              historyLog={submission?.history_log || []} 
              sentWebhookMessages={submission?.sent_webhook_messages || []}
            />
            </div>
        </DialogContent>
      </Dialog>

      {/* Swap Form Type Dialog */}
      <Dialog open={showSwapFormDialog} onOpenChange={setShowSwapFormDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <RepeatIcon className="w-5 h-5 text-purple-600" />
              Swap Form Type
            </DialogTitle>
            <DialogDescription className="space-y-3 pt-4">
              <p className="text-sm text-gray-700">
                This will convert this submission to a different form type. Fields that exist in both forms will be copied over.
              </p>
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-xs font-semibold text-amber-900">Warning:</p>
                <p className="text-xs text-amber-800 mt-1">
                  This action cannot be undone. The original submission will be deleted.
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="target-form" className="text-sm font-semibold mb-2 block">
              Select Target Form
            </Label>
            <Select value={selectedTargetFormId} onValueChange={setSelectedTargetFormId}>
              <SelectTrigger id="target-form">
                <SelectValue placeholder="Choose a form..." />
              </SelectTrigger>
              <SelectContent>
                {allFormConfigs
                  .filter(config => config.id !== submission?.form_config_id)
                  .map(config => (
                    <SelectItem key={config.id} value={config.id}>
                      {config.form_name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowSwapFormDialog(false);
                setSelectedTargetFormId('');
              }}
              disabled={isSwapping}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSwapFormType}
              disabled={!selectedTargetFormId || isSwapping}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isSwapping ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Swapping...
                </>
              ) : (
                'Swap Form Type'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      </div>
      );
      }
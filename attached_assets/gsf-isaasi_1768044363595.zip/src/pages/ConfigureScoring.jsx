import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle, Plus, Trash2, Save, GripVertical, Heading, Zap, Loader2, Image } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import RiskLevelEditor from "../components/scoring/RiskLevelEditor";
import WorkflowStageEditor from "../components/scoring/WorkflowStageEditor";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from 'react-router-dom'; // Assuming react-router-dom for useNavigate

export default function ConfigureScoring() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const formConfigId = urlParams.get('id');
  const queryClient = useQueryClient();

  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [scoringApproach, setScoringApproach] = useState('dynamic');
  const [defaultReviewState, setDefaultReviewState] = useState('amended');
  const [scoringRules, setScoringRules] = useState({
    rules: [],
    risk_thresholds: { low: 80, medium: 50, high: 20, critical: 0 },
    form_structure: null
  });
  const [staticQuestions, setStaticQuestions] = useState([]);
  const [customRiskLevels, setCustomRiskLevels] = useState([
    { name: "Low Risk", threshold: 80, color: "#22c55e" },
    { name: "Medium Risk", threshold: 50, color: "#f59e0b" },
    { name: "High Risk", threshold: 20, color: "#f97316" },
    { name: "Critical Risk", threshold: 0, color: "#ef4444" }
  ]);
  const [workflowStages, setWorkflowStages] = useState([
    { id: "new", label: "New", color: "#f97316", is_initial: true, order: 0, _internalId: "new_initial_id" },
    { id: "in_review", label: "In Review", color: "#a855f7", is_initial: false, order: 1, _internalId: "in_review_initial_id" },
    { id: "verified", label: "Verified", color: "#3b82f6", is_initial: false, order: 2, _internalId: "verified_initial_id" },
    { id: "approved", label: "Approved", color: "#22c55e", is_initial: false, order: 3, _internalId: "approved_initial_id" },
    { id: "rejected", label: "Rejected", color: "#ef4444", is_initial: false, order: 4, _internalId: "rejected_initial_id" }
  ]);
  const [statusWebhooks, setStatusWebhooks] = useState([]);

  // CRM Logo Upload Config State
  const [crmLogoUploadConfig, setCrmLogoUploadConfig] = useState({
    enabled: false,
    module_name: '',
    field_name: '',
    submission_org_name_field: '', // Added new field
    crm_lookup_field: 'Name' // Added new field
  });

  // Test webhook state
  const [testWebhookDialog, setTestWebhookDialog] = useState({
    open: false,
    webhook: null,
    submissionId: '',
    testReminderCount: 0,
    customMessage: '',
    loading: false
  });

  // Test logo upload state
  const [testLogoUploadDialog, setTestLogoUploadDialog] = useState({
    open: false,
    submissionId: '',
    loading: false
  });

  // Check authentication status on component mount
  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: formConfig, isLoading } = useQuery({
    queryKey: ['formConfig', formConfigId],
    queryFn: async () => {
      if (!formConfigId) throw new Error('No form ID provided');
      const configs = await base44.entities.FormConfiguration.filter({ id: formConfigId });
      if (configs.length === 0) throw new Error('Form not found');
      return configs[0];
    },
    enabled: !!formConfigId && isAuthenticated === true,
    staleTime: Infinity, // Never mark as stale
    refetchOnWindowFocus: false,
    refetchOnMount: false,
    refetchOnReconnect: false,
    refetchInterval: false,
  });

  // Track if we've initialized data to prevent resetting after saves
  const [hasInitialized, setHasInitialized] = React.useState(false);

  useEffect(() => {
    if (formConfig && !hasInitialized) {
      console.log('=== INITIALIZING FROM FORM CONFIG (FIRST LOAD) ===');
      
      setScoringApproach(formConfig.scoring_approach || 'dynamic');
      setDefaultReviewState(formConfig.default_review_state || 'amended');
      
      setScoringRules(prev => {
        const loadedRules = (formConfig.scoring_rules?.rules || []).map(rule => {
          const fieldInStructure = formConfig.form_structure?.fields?.find(f => f.name === rule.field);
          const isTextBasedField = fieldInStructure && ['text', 'email', 'number', 'phone', 'textarea', 'paragraph', 'name'].includes(fieldInStructure.type);
          return {
            ...rule,
            type: rule.type || (isTextBasedField ? 'notEmpty' : 'option'),
            notEmptyScore: rule.notEmptyScore !== undefined ? rule.notEmptyScore : 0,
            scoring: rule.scoring || {}
          };
        });

        return {
          ...prev,
          rules: loadedRules,
          risk_thresholds: formConfig.scoring_rules?.risk_thresholds || prev.risk_thresholds,
          form_structure: formConfig.form_structure ? {
            ...formConfig.form_structure,
            fields: formConfig.form_structure.fields.map(field => ({
              ...field,
              visible: field.visible === false ? false : true
            }))
          } : null
        };
      });
      
      // Load static questions - preserve ALL properties
      setStaticQuestions(
        formConfig.static_questions?.map(item => {
          // Generate a unique ID if missing
          const baseId = item.id || `${item.type === 'header' ? 'h' : 'q'}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
          
          // If no type, assume it's a question (backward compatibility)
          if (!item.type) {
            return {
              ...item,
              id: baseId,
              type: 'question',
            };
          }
          
          // Return item with all its properties preserved
          return {
            ...item,
            id: item.id || baseId
          };
        }) || []
      );
      
      if (formConfig.custom_risk_levels && formConfig.custom_risk_levels.length > 0) {
        setCustomRiskLevels(formConfig.custom_risk_levels);
      }

      // Load workflow stages with stable internal IDs
      if (formConfig.workflow_stages && formConfig.workflow_stages.length > 0) {
        setWorkflowStages(formConfig.workflow_stages.map(stage => ({
          ...stage,
          _internalId: stage._internalId || `internal_${Date.now()}_${Math.random()}_${stage.id}`
        })));
      }

      // Load status change webhooks
      if (formConfig.status_change_webhooks && formConfig.status_change_webhooks.length > 0) {
        setStatusWebhooks(formConfig.status_change_webhooks.map(w => ({
          ...w,
          // Ensure new fields have default values if not present in loaded config
          reminder_interval_days: w.reminder_interval_days ?? 0,
          max_reminders: w.max_reminders ?? 0,
          stop_condition_field: w.stop_condition_field ?? '',
          stop_condition_operator: w.stop_condition_operator ?? 'not_empty',
          stop_condition_value: w.stop_condition_value ?? '',
          payload_type: w.payload_type ?? 'default',
          custom_payload_template: w.custom_payload_template ?? ''
        })));
      }

      // Initialize CRM Logo Upload Config
      if (formConfig.crm_logo_upload_config) {
        setCrmLogoUploadConfig({
          enabled: formConfig.crm_logo_upload_config.enabled || false,
          module_name: formConfig.crm_logo_upload_config.module_name || '',
          field_name: formConfig.crm_logo_upload_config.field_name || '',
          submission_org_name_field: formConfig.crm_logo_upload_config.submission_org_name_field || '', // Initialize new field
          crm_lookup_field: formConfig.crm_logo_upload_config.crm_lookup_field || 'Name' // Initialize new field
        });
      }
      
      setHasInitialized(true);
    }
  }, [formConfig, hasInitialized, isAuthenticated]);

  const saveMutation = useMutation({
    mutationFn: async (dataToSave) => {
      console.log('=== CALLING BACKEND SAVE FUNCTION ===');
      console.log('Data to save:', JSON.stringify(dataToSave, null, 2));
      
      const response = await base44.functions.invoke('saveFormConfiguration', {
        formConfigId: formConfigId,
        updateData: {
          scoring_approach: dataToSave.scoring_approach,
          default_review_state: dataToSave.default_review_state,
          scoring_rules: {
            rules: dataToSave.rules,
            risk_thresholds: dataToSave.risk_thresholds
          },
          static_questions: dataToSave.static_questions,
          custom_risk_levels: dataToSave.custom_risk_levels,
          workflow_stages: dataToSave.workflow_stages,
          status_change_webhooks: dataToSave.status_change_webhooks,
          crm_logo_upload_config: dataToSave.crm_logo_upload_config
        }
      });
      
      console.log('=== BACKEND RESPONSE ===');
      console.log('Response:', JSON.stringify(response.data, null, 2));
      
      if (!response.data.success) {
        throw new Error(response.data.error || 'Save failed');
      }
      
      return response.data.data;
    },
    onSuccess: () => {
      console.log('=== SAVE SUCCESSFUL ===');
      toast.success('Configuration saved successfully');
    },
    onError: (error) => {
      console.error('=== SAVE FAILED ===');
      console.error('Error:', error.message);
      toast.error('Failed to save configuration: ' + error.message);
    }
  });

  // Memoized derived values
  const availableFields = useMemo(() => {
    return scoringRules.form_structure?.fields || [];
  }, [scoringRules.form_structure]);

  const sortedStages = useMemo(() => {
    return [...workflowStages].sort((a, b) => a.order - b.order);
  }, [workflowStages]);

  const submissionEntityFields = useMemo(() => [
    { value: 'application_uid', label: 'Application UID', type: 'string' },
    { value: 'applicant_name', label: 'Applicant Name', type: 'string' },
    { value: 'applicant_email', label: 'Applicant Email', type: 'string' },
    { value: 'status', label: 'Status', type: 'string' },
    { value: 'dd_call_date', label: 'DD Call Date', type: 'date-time' },
    { value: 'due_diligence_score', label: 'Due Diligence Score', type: 'number' },
    { value: 'risk_level', label: 'Risk Level', type: 'string' },
    { value: 'notes', label: 'Notes', type: 'string' },
    { value: 'reviewed_by', label: 'Reviewed By', type: 'string' },
    { value: 'reviewed_date', label: 'Reviewed Date', type: 'date-time' },
  ], []);

  const stopConditionOperators = useMemo(() => [
    { value: 'not_empty', label: 'Is Not Empty', requiresValue: false },
    { value: 'is_empty', label: 'Is Empty', requiresValue: false },
    { value: 'equals', label: 'Equals', requiresValue: true },
    { value: 'not_equals', label: 'Does Not Equal', requiresValue: true },
    { value: 'contains', label: 'Contains', requiresValue: true },
  ], []);

  const availablePlaceholders = useMemo(() => [
    { category: "Submission", items: [
      { placeholder: "{{submission.id}}", description: "Submission ID" },
      { placeholder: "{{submission.application_uid}}", description: "Application UID" },
      { placeholder: "{{submission.applicant_name}}", description: "Applicant Name" },
      { placeholder: "{{submission.applicant_email}}", description: "Applicant Email" },
      { placeholder: "{{submission.status}}", description: "Current Status" },
      { placeholder: "{{submission.due_diligence_score}}", description: "DD Score" },
      { placeholder: "{{submission.risk_level}}", description: "Risk Level" },
      { placeholder: "{{submission.dd_call_date}}", description: "DD Call Date" },
      { placeholder: "{{submission.notes}}", description: "Notes" },
    ]},
    { category: "Status Change", items: [
      { placeholder: "{{oldStatus}}", description: "Previous Status ID" },
      { placeholder: "{{newStatus}}", description: "New Status ID" },
      { placeholder: "{{reminderCount}}", description: "Reminder Count (0 = initial)" },
    ]},
    { category: "Form", items: [
      { placeholder: "{{formName}}", description: "Form Name" },
      { placeholder: "{{formConfig.id}}", description: "Form Config ID" },
    ]},
    { category: "Organization", items: [
      { placeholder: "{{applicantOrganizationName}}", description: "Organization Name" },
    ]},
    { category: "Metadata", items: [
      { placeholder: "{{timestamp}}", description: "ISO Timestamp" },
    ]},
    { category: "Form Data", items: [
      ...(formConfig?.form_structure?.fields || []).map(field => {
        // Handle subform fields
        if (field.type === 'subform' && field.subfields) {
          return {
            placeholder: `{{form_data.${field.name}}}`,
            description: `${field.label} (Subform Array)`,
            isSubform: true,
            subfields: field.subfields.map(subfield => ({
              placeholder: `{{form_data.${field.name}[0].${subfield.name}}}`,
              description: `${field.label} → ${subfield.label}`
            }))
          };
        }
        
        return {
          placeholder: `{{form_data.${field.name}}}`,
          description: field.label || field.name
        };
      })
    ]},
  ], [formConfig?.form_structure?.fields]);

  const addRule = useCallback(() => {
    setScoringRules(prev => ({
      ...prev,
      rules: [...prev.rules, { field: '', type: 'option', scoring: {}, notEmptyScore: 0 }]
    }));
  }, []);

  const removeRule = useCallback((index) => {
    setScoringRules(prev => ({
      ...prev,
      rules: prev.rules.filter((_, i) => i !== index)
    }));
  }, []);

  const updateRule = useCallback((index, fieldName, value) => {
    setScoringRules(prev => {
      const newRules = [...prev.rules];
      
      if (fieldName === 'field' && value) {
        const selectedField = availableFields.find(f => f.name === value);
        const isTextBased = ['text', 'email', 'number', 'phone', 'textarea', 'paragraph', 'name'].includes(selectedField?.type);
        
        newRules[index] = { 
          ...newRules[index], 
          [fieldName]: value,
          type: isTextBased ? 'notEmpty' : 'option',
          scoring: isTextBased ? {} : (newRules[index].scoring || {}),
          notEmptyScore: isTextBased ? (newRules[index].notEmptyScore || 0) : 0
        };
      } else {
        newRules[index] = { ...newRules[index], [fieldName]: value };
      }
      
      return { ...prev, rules: newRules };
    });
  }, [availableFields]);

  const updateNotEmptyScore = useCallback((ruleIndex, score) => {
    setScoringRules(prev => {
      const newRules = [...prev.rules];
      newRules[ruleIndex] = { ...newRules[ruleIndex], notEmptyScore: parseInt(score) || 0 };
      return { ...prev, rules: newRules };
    });
  }, []);

  const addScoring = useCallback((ruleIndex, optionValue) => {
    setScoringRules(prev => {
      const newRules = [...prev.rules];
      if (!newRules[ruleIndex].scoring) {
          newRules[ruleIndex].scoring = {};
      }
      newRules[ruleIndex].scoring[optionValue] = 0;
      return { ...prev, rules: newRules };
    });
  }, []);

  const updateScoring = useCallback((ruleIndex, optionValue, score) => {
    setScoringRules(prev => {
      const newRules = [...prev.rules];
      if (!newRules[ruleIndex].scoring) {
          newRules[ruleIndex].scoring = {};
      }
      newRules[ruleIndex].scoring[optionValue] = parseInt(score) || 0;
      return { ...prev, rules: newRules };
    });
  }, []);

  const removeScoring = useCallback((ruleIndex, optionValue) => {
    setScoringRules(prev => {
      const newRules = [...prev.rules];
      if (newRules[ruleIndex].scoring) {
        delete newRules[ruleIndex].scoring[optionValue];
      }
      return { ...prev, rules: newRules };
    });
  }, []);

  const addStaticQuestion = useCallback(() => {
    setStaticQuestions(prev => [...prev, {
      id: `q_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'question',
      question: '',
      green_points: 10,
      amber_points: 5,
      red_points: 0
    }]);
  }, []);

  const addSectionHeader = useCallback(() => {
    const newHeader = {
      id: `h_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'header',
      title: 'Section Header',
      backgroundColor: '#3b82f6',
      textColor: '#ffffff'
    };
    
    console.log('=== ADDING SECTION HEADER ===');
    console.log('New header object:', JSON.stringify(newHeader, null, 2));
    
    setStaticQuestions(prev => {
      const updated = [...prev, newHeader];
      console.log('Updated staticQuestions array:', JSON.stringify(updated, null, 2));
      return updated;
    });
  }, []);

  const removeStaticQuestion = useCallback((index) => {
    setStaticQuestions(prev => prev.filter((_, i) => i !== index));
  }, []);

  const updateStaticQuestion = useCallback((index, field, value) => {
    setStaticQuestions(prev => {
      const newQuestions = [...prev];
      // Ensure numeric values are parsed for question points
      if (['green_points', 'amber_points', 'red_points'].includes(field)) {
        newQuestions[index] = { ...newQuestions[index], [field]: parseInt(value) || 0 };
      } else {
        newQuestions[index] = { ...newQuestions[index], [field]: value };
      }
      return newQuestions;
    });
  }, []);

  const onDragEnd = useCallback((result) => {
    if (!result.destination) {
      return;
    }

    const reorderedItems = Array.from(staticQuestions);
    const [movedItem] = reorderedItems.splice(result.source.index, 1);
    reorderedItems.splice(result.destination.index, 0, movedItem);

    setStaticQuestions(reorderedItems);
  }, [staticQuestions]);

  // Status webhook management functions
  const addStatusWebhook = useCallback(() => {
    const newWebhook = {
      id: `webhook_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      name: 'New Webhook',
      trigger_status_id: sortedStages[0]?.id || 'approved', // Default to first stage or 'approved'
      webhook_url: '',
      enabled: true,
      reminder_interval_days: 0,
      max_reminders: 0,
      stop_condition_field: '',
      stop_condition_operator: 'not_empty',
      stop_condition_value: '',
      payload_type: 'default',
      custom_payload_template: ''
    };
    setStatusWebhooks(prev => [...prev, newWebhook]);
  }, [sortedStages]);

  const updateStatusWebhook = useCallback((index, field, value) => {
    setStatusWebhooks(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  }, []);

  const removeStatusWebhook = useCallback((index) => {
    setStatusWebhooks(prev => prev.filter((_, i) => i !== index));
  }, []);

  // Test webhook functions
  const handleOpenTestDialog = useCallback((webhook) => {
    setTestWebhookDialog({
      open: true,
      webhook: webhook,
      submissionId: '',
      testReminderCount: 0,
      customMessage: '',
      loading: false
    });
  }, []);

  const handleCloseTestDialog = useCallback(() => {
    setTestWebhookDialog({
      open: false,
      webhook: null,
      submissionId: '',
      testReminderCount: 0,
      customMessage: '',
      loading: false
    });
  }, []);

  const handleTestWebhook = useCallback(async () => {
    if (!testWebhookDialog.submissionId) {
      toast.error('Please enter a Submission ID');
      return;
    }

    setTestWebhookDialog(prev => ({ ...prev, loading: true }));

    try {
      const invokeParams = {
        submissionId: testWebhookDialog.submissionId,
        webhookConfig: testWebhookDialog.webhook,
        oldStatus: null, // For testing, we assume this is a fresh trigger or a status change. The backend will handle the actual logic.
        newStatus: testWebhookDialog.webhook.trigger_status_id,
        testReminderCount: testWebhookDialog.testReminderCount
      };
      
      // Include custom message if provided
      if (testWebhookDialog.customMessage && testWebhookDialog.customMessage.trim()) {
        invokeParams.customMessage = testWebhookDialog.customMessage.trim();
      }
      
      const result = await base44.functions.invoke('triggerStatusWebhook', invokeParams);

      if (result.data.success) {
        toast.success(
          <div>
            <p className="font-semibold">Test webhook triggered successfully!</p>
            <p className="text-xs mt-1">Reminder Count: {testWebhookDialog.testReminderCount}</p>
            <p className="text-xs">No database changes were made.</p>
          </div>,
          { duration: 5000 }
        );
        handleCloseTestDialog();
      } else {
        toast.error(result.data.message || 'Failed to trigger test webhook');
      }
    } catch (error) {
      toast.error('Error triggering test webhook: ' + error.message);
    } finally {
      setTestWebhookDialog(prev => ({ ...prev, loading: false }));
    }
  }, [testWebhookDialog, handleCloseTestDialog]);

  // Test logo upload functions
  const handleOpenTestLogoUploadDialog = useCallback(() => {
    setTestLogoUploadDialog({
      open: true,
      submissionId: '',
      loading: false
    });
  }, []);

  const handleCloseTestLogoUploadDialog = useCallback(() => {
    setTestLogoUploadDialog({
      open: false,
      submissionId: '',
      loading: false
    });
  }, []);

  const handleTestLogoUpload = useCallback(async () => {
    if (!testLogoUploadDialog.submissionId) {
      toast.error('Please enter a Submission ID');
      return;
    }

    setTestLogoUploadDialog(prev => ({ ...prev, loading: true }));

    try {
      const result = await base44.functions.invoke('uploadLogoToCrm', {
        submissionId: testLogoUploadDialog.submissionId
      });

      if (result.data.success) {
        toast.success(
          <div>
            <p className="font-semibold">Logo upload test successful!</p>
            <p className="text-xs mt-1">File: {result.data.fileName}</p>
            <p className="text-xs">CRM Record ID: {result.data.crmRecordId}</p>
          </div>,
          { duration: 5000 }
        );
        handleCloseTestLogoUploadDialog();
      } else {
        toast.error(
          <div>
            <p className="font-semibold">Logo upload test failed</p>
            <p className="text-xs mt-1">{result.data.message}</p>
          </div>,
          { duration: 7000 }
        );
      }
    } catch (error) {
      toast.error(
        <div>
          <p className="font-semibold">Error during logo upload test</p>
          <p className="text-xs mt-1">{error.message}</p>
        </div>,
        { duration: 7000 }
      );
    } finally {
      setTestLogoUploadDialog(prev => ({ ...prev, loading: false }));
    }
  }, [testLogoUploadDialog, handleCloseTestLogoUploadDialog]);

  const handleSave = useCallback(() => {
    console.log('=== HANDLE SAVE CALLED ===');
    console.log('Current staticQuestions state:', JSON.stringify(staticQuestions, null, 2));
    console.log('Current scoringApproach:', scoringApproach);
    console.log('Current defaultReviewState:', defaultReviewState);
    console.log('Current workflowStages:', JSON.stringify(workflowStages, null, 2));
    console.log('Current statusWebhooks:', JSON.stringify(statusWebhooks, null, 2));
    console.log('Current crmLogoUploadConfig:', JSON.stringify(crmLogoUploadConfig, null, 2));
    
    const dataToSave = {
      scoring_approach: scoringApproach,
      default_review_state: defaultReviewState,
      rules: scoringRules.rules,
      risk_thresholds: scoringRules.risk_thresholds,
      static_questions: staticQuestions,
      custom_risk_levels: customRiskLevels,
      // Remove _internalId before saving
      workflow_stages: workflowStages.map(({ _internalId, ...rest }) => rest), 
      status_change_webhooks: statusWebhooks,
      crm_logo_upload_config: crmLogoUploadConfig
    };
    
    console.log('Data being passed to saveMutation:', JSON.stringify(dataToSave, null, 2));
    
    saveMutation.mutate(dataToSave);
  }, [scoringApproach, defaultReviewState, scoringRules, staticQuestions, customRiskLevels, workflowStages, statusWebhooks, crmLogoUploadConfig, saveMutation]);

  // Initial loading state for authentication and form data
  if (isAuthenticated === null || isLoading) {
    return (
      <div className="p-6 md:p-8">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      </div>
    );
  }

  if (!formConfigId) {
    return (
      <div className="p-6 md:p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>No form ID provided</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!formConfig) {
    return (
      <div className="p-6 md:p-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>Form not found</AlertDescription>
        </Alert>
      </div>
    );
  }

  const defaultColors = [
    { name: "Blue", value: "#3b82f6" },
    { name: "Indigo", value: "#6366f1" },
    { name: "Purple", value: "#a855f7" },
    { name: "Pink", value: "#ec4899" },
    { name: "Red", value: "#ef4444" },
    { name: "Orange", value: "#f97316" },
    { name: "Amber", value: "#f59e0b" },
    { name: "Green", value: "#22c55e" },
    { name: "Teal", value: "#14b8a6" },
    { name: "Cyan", value: "#06b6d4" },
    { name: "Slate", value: "#64748b" },
    { name: "Gray", value: "#6b7280" },
    { name: "White", value: "#ffffff" },
    { name: "Black", value: "#000000" },
  ];

  return (
    <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{formConfig.form_name}</h1>
        <p className="text-gray-600 mt-1">Configure Due Diligence Scoring</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Scoring Approach</CardTitle>
          <p className="text-sm text-gray-600 mt-2">Choose how submissions for this form will be evaluated</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm font-semibold mb-2 block">Scoring Method</Label>
            <Select value={scoringApproach} onValueChange={setScoringApproach}>
              <SelectTrigger className="w-full md:w-96">
                <SelectValue placeholder="Select scoring approach" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dynamic">Dynamic Field-Based Scoring</SelectItem>
                <SelectItem value="static_traffic_light">Static Traffic Light Questions</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-gray-500 mt-2">
              {scoringApproach === 'dynamic' 
                ? 'Score based on actual form field values and responses'
                : 'Score based on reviewer answers to predefined questions using traffic light system'}
            </p>
          </div>

          <div className="border-t pt-4">
            <Label className="text-sm font-semibold mb-2 block">Default Review State</Label>
            <Select value={defaultReviewState} onValueChange={setDefaultReviewState}>
              <SelectTrigger className="w-full md:w-96">
                <SelectValue placeholder="Select default state" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="amended">
                  <div className="flex flex-col">
                    <span className="font-medium">Start with Amended</span>
                    <span className="text-xs text-gray-500">Review each field and approve individually</span>
                  </div>
                </SelectItem>
                <SelectItem value="approved">
                  <div className="flex flex-col">
                    <span className="font-medium">Start with Approved</span>
                    <span className="text-xs text-gray-500">All fields approved by default, amend only what needs changing</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-sm text-gray-500 mt-2">
              {defaultReviewState === 'amended' 
                ? '✏️ Reviewers will see the editable form first and must explicitly approve each field'
                : '✅ Reviewers will see original data approved by default and only need to amend exceptions'}
            </p>
            <Alert className="mt-3 bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-xs text-blue-800">
                <strong>Note:</strong> This setting only affects the initial state when a submission is loaded. 
                The two-column layout (original vs amended) remains unchanged - reviewers can always toggle between approved and amended for any field.
              </AlertDescription>
            </Alert>
          </div>
        </CardContent>
      </Card>

      {scoringApproach === 'dynamic' && (
        <>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Scoring Rules</CardTitle>
                <Button onClick={addRule} size="sm" className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add Rule
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {scoringRules.rules.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No scoring rules defined yet</p>
                  <p className="text-sm mt-1">Click "Add Rule" to get started</p>
                </div>
              ) : (
                scoringRules.rules.map((rule, ruleIndex) => {
                  const isTextBased = rule.type === 'notEmpty';
                  
                  return (
                    <Card key={ruleIndex} className="bg-gray-50">
                      <CardContent className="pt-6 space-y-4">
                        <div className="flex gap-4 items-start">
                          <div className="flex-1">
                            <Label>Field</Label>
                            <Select
                              value={rule.field}
                              onValueChange={(value) => updateRule(ruleIndex, 'field', value)}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select field" />
                              </SelectTrigger>
                              <SelectContent>
                                {availableFields.map((field) => (
                                  field.visible !== false && ( // Only show visible fields for scoring
                                    <SelectItem key={field.name} value={field.name}>
                                      {field.label || field.name} ({field.type})
                                    </SelectItem>
                                  )
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <Button
                            variant="destructive"
                            size="icon"
                            onClick={() => removeRule(ruleIndex)}
                            className="mt-6"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>

                        {rule.field && (
                          <div className="space-y-3 pl-4 border-l-2 border-gray-300">
                            {isTextBased ? (
                              <div>
                                <Label htmlFor={`not-empty-score-${ruleIndex}`}>Points if Field is Not Empty</Label>
                                <Input
                                  id={`not-empty-score-${ruleIndex}`}
                                  type="number"
                                  value={rule.notEmptyScore}
                                  onChange={(e) => updateNotEmptyScore(ruleIndex, e.target.value)}
                                  placeholder="Points"
                                  className="w-32"
                                />
                                <p className="text-xs text-gray-500 mt-1">
                                  Award these points if the applicant provides any value for this field
                                </p>
                              </div>
                            ) : (
                              <>
                                <Label>Point Values for Responses</Label>
                                {Object.entries(rule.scoring || {}).map(([optionValue, score]) => (
                                  <div key={optionValue} className="flex gap-2 items-center">
                                    <Input
                                      value={optionValue}
                                      readOnly
                                      className="flex-1"
                                    />
                                    <Input
                                      type="number"
                                      value={score}
                                      onChange={(e) => updateScoring(ruleIndex, optionValue, e.target.value)}
                                      placeholder="Points"
                                      className="w-24"
                                    />
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => removeScoring(ruleIndex, optionValue)}
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                ))}
                                <div className="flex gap-2">
                                  <Input
                                    placeholder="Option value"
                                    onKeyPress={(e) => {
                                      if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                                        if (rule.scoring && rule.scoring[e.currentTarget.value.trim()]) {
                                          toast.error('Option value already exists for this field.');
                                        } else {
                                          addScoring(ruleIndex, e.currentTarget.value.trim());
                                          e.currentTarget.value = '';
                                        }
                                      }
                                    }}
                                  />
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={(e) => {
                                      const input = e.currentTarget.closest('div').querySelector('input');
                                      if (input.value.trim()) {
                                        if (rule.scoring && rule.scoring[input.value.trim()]) {
                                          toast.error('Option value already exists for this field.');
                                        } else {
                                          addScoring(ruleIndex, input.value.trim());
                                          input.value = '';
                                        }
                                      }
                                    }}
                                  >
                                    Add
                                  </Button>
                                </div>
                              </>
                            )}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </CardContent>
          </Card>
        </>
      )}

      {scoringApproach === 'static_traffic_light' && (
        <>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Traffic Light Questions</CardTitle>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button size="sm" className="gap-2">
                      <Plus className="w-4 h-4" />
                      Add Item
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={addStaticQuestion}>
                      <span className="mr-2">❓</span> Add Question
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={addSectionHeader}>
                      <Heading className="w-4 h-4 mr-2" />
                      Add Section Header
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Define questions with Green, Amber, and Red point values. Add section headers to organize questions. Drag to reorder.
              </p>
            </CardHeader>
            <CardContent>
              {staticQuestions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>No questions defined yet</p>
                  <p className="text-sm mt-1">Click "Add Item" to get started</p>
                </div>
              ) : (
                <DragDropContext onDragEnd={onDragEnd}>
                  <Droppable droppableId="static-questions">
                    {(provided) => (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        className="space-y-6"
                      >
                        {staticQuestions.map((item, index) => (
                          <Draggable 
                            key={item.id} 
                            draggableId={item.id} 
                            index={index}
                          >
                            {(provided, snapshot) => (
                              <Card 
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                className={`bg-gray-50 transition-shadow ${
                                  snapshot.isDragging ? 'shadow-2xl' : ''
                                }`}
                              >
                                <CardContent className="pt-6 space-y-4">
                                  {item.type === 'header' ? (
                                    // Section Header
                                    <div className="flex gap-4 items-start">
                                      <div 
                                        {...provided.dragHandleProps}
                                        className="mt-6 cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600 transition-colors"
                                      >
                                        <GripVertical className="w-5 h-5" />
                                      </div>
                                      <div className="flex-1 space-y-4">
                                        <div className="flex items-center gap-2">
                                          <Heading className="w-5 h-5 text-purple-600" />
                                          <span className="text-sm font-semibold text-purple-600">Section Header</span>
                                        </div>
                                        <div>
                                          <Label>Header Title</Label>
                                          <Input
                                            value={item.title || ''}
                                            onChange={(e) => updateStaticQuestion(index, 'title', e.target.value)}
                                            placeholder="Enter section title..."
                                          />
                                        </div>
                                        
                                        <div className="grid grid-cols-2 gap-4">
                                          <div>
                                            <Label className="mb-2 block">Background Color</Label>
                                            <div className="flex gap-2 items-center">
                                              <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                  <button
                                                    type="button"
                                                    className="w-12 h-10 rounded-md border-2 border-gray-300 hover:border-gray-400 transition-colors shadow-sm"
                                                    style={{ backgroundColor: item.backgroundColor || '#3b82f6' }}
                                                  />
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent>
                                                  <div className="grid grid-cols-4 gap-2 p-2">
                                                    {defaultColors.map((color) => (
                                                      <button
                                                        key={color.value}
                                                        type="button"
                                                        onClick={() => updateStaticQuestion(index, 'backgroundColor', color.value)}
                                                        className="w-8 h-8 rounded-md border-2 border-gray-300 hover:scale-110 transition-transform"
                                                        style={{ backgroundColor: color.value }}
                                                        title={color.name}
                                                      />
                                                    ))}
                                                  </div>
                                                </DropdownMenuContent>
                                              </DropdownMenu>
                                              <Input
                                                type="text"
                                                value={item.backgroundColor || '#3b82f6'}
                                                onChange={(e) => updateStaticQuestion(index, 'backgroundColor', e.target.value)}
                                                className="flex-1"
                                                placeholder="#3b82f6"
                                              />
                                            </div>
                                          </div>
                                          
                                          <div>
                                            <Label className="mb-2 block">Text Color</Label>
                                            <div className="flex gap-2 items-center">
                                              <DropdownMenu>
                                                <DropdownMenuTrigger asChild>
                                                  <button
                                                    type="button"
                                                    className="w-12 h-10 rounded-md border-2 border-gray-300 hover:border-gray-400 transition-colors shadow-sm"
                                                    style={{ backgroundColor: item.textColor || '#ffffff' }}
                                                  />
                                                </DropdownMenuTrigger>
                                                <DropdownMenuContent>
                                                  <div className="grid grid-cols-4 gap-2 p-2">
                                                    {defaultColors.map((color) => (
                                                      <button
                                                        key={color.value}
                                                        type="button"
                                                        onClick={() => updateStaticQuestion(index, 'textColor', color.value)}
                                                        className="w-8 h-8 rounded-md border-2 border-gray-300 hover:scale-110 transition-transform"
                                                        style={{ backgroundColor: color.value }}
                                                        title={color.name}
                                                      />
                                                    ))}
                                                  </div>
                                                </DropdownMenuContent>
                                              </DropdownMenu>
                                              <Input
                                                type="text"
                                                value={item.textColor || '#ffffff'}
                                                onChange={(e) => updateStaticQuestion(index, 'textColor', e.target.value)}
                                                className="flex-1"
                                                placeholder="#ffffff"
                                              />
                                            </div>
                                          </div>
                                        </div>

                                        <div 
                                          className="p-4 rounded-lg shadow-sm border border-gray-200" 
                                          style={{ backgroundColor: item.backgroundColor || '#3b82f6', color: item.textColor || '#ffffff' }}
                                        >
                                          <h3 className="text-lg font-bold">Preview: {item.title || 'Section Header'}</h3>
                                        </div>
                                      </div>
                                      <Button
                                        variant="destructive"
                                        size="icon"
                                        onClick={() => removeStaticQuestion(index)}
                                        className="mt-6"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  ) : (
                                    // Regular Question
                                    <div className="flex gap-4 items-start">
                                      <div 
                                        {...provided.dragHandleProps}
                                        className="mt-6 cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600 transition-colors"
                                      >
                                        <GripVertical className="w-5 h-5" />
                                      </div>
                                      <div className="flex-1 space-y-4">
                                        <div>
                                          {/* Filter only questions for numbering */}
                                          <Label>Question {staticQuestions.filter(q => q.type === 'question').indexOf(item) + 1}</Label>
                                          <Textarea
                                            value={item.question}
                                            onChange={(e) => updateStaticQuestion(index, 'question', e.target.value)}
                                            placeholder="Enter your due diligence question..."
                                            rows={2}
                                          />
                                        </div>
                                        
                                        <div className="grid grid-cols-3 gap-4">
                                          <div>
                                            <Label className="text-green-700">🟢 Green Points</Label>
                                            <Input
                                              type="number"
                                              value={item.green_points}
                                              onChange={(e) => updateStaticQuestion(index, 'green_points', e.target.value)}
                                              className="border-green-300 focus:border-green-500"
                                            />
                                          </div>
                                          <div>
                                            <Label className="text-amber-700">🟡 Amber Points</Label>
                                            <Input
                                              type="number"
                                              value={item.amber_points}
                                              onChange={(e) => updateStaticQuestion(index, 'amber_points', e.target.value)}
                                              className="border-amber-300 focus:border-amber-500"
                                            />
                                          </div>
                                          <div>
                                            <Label className="text-red-700">🔴 Red Points</Label>
                                            <Input
                                              type="number"
                                              value={item.red_points}
                                              onChange={(e) => updateStaticQuestion(index, 'red_points', e.target.value)}
                                              className="border-red-300 focus:border-red-500"
                                            />
                                          </div>
                                        </div>
                                      </div>
                                      <Button
                                        variant="destructive"
                                        size="icon"
                                        onClick={() => removeStaticQuestion(index)}
                                        className="mt-6"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  )}
                                </CardContent>
                              </Card>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              )}
            </CardContent>
          </Card>
        </>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Workflow Stages</CardTitle>
          <p className="text-sm text-gray-600 mt-2">Configure the workflow stages for this form's submissions</p>
        </CardHeader>
        <CardContent>
          <WorkflowStageEditor
            stages={workflowStages}
            onChange={setWorkflowStages}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Status Change Webhooks</CardTitle>
              <p className="text-sm text-gray-600 mt-2">
                Configure webhooks that trigger when a submission's status changes, with optional reminder system.
              </p>
            </div>
            <Button onClick={addStatusWebhook} size="sm" className="gap-2">
              <Plus className="w-4 h-4" />
              Add Webhook
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {statusWebhooks.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No status change webhooks configured</p>
              <p className="text-sm mt-1">Click "Add Webhook" to create one</p>
            </div>
          ) : (
            statusWebhooks.map((webhook, index) => (
              <Card key={webhook.id} className="bg-slate-50 border-slate-200">
                <CardContent className="pt-6">
                  <div className="flex gap-4 items-start">
                    <div className="flex-1 space-y-4">
                      {/* Basic Configuration */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm font-semibold">Webhook Name</Label>
                          <Input
                            value={webhook.name}
                            onChange={(e) => updateStatusWebhook(index, 'name', e.target.value)}
                            placeholder="e.g., DD Call Booking Request"
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-sm font-semibold">Trigger on Status</Label>
                          <Select
                            value={webhook.trigger_status_id}
                            onValueChange={(value) => updateStatusWebhook(index, 'trigger_status_id', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue placeholder="Select status" />
                            </SelectTrigger>
                            <SelectContent>
                              {sortedStages.map((stage) => (
                                <SelectItem key={stage.id} value={stage.id}>
                                  <div className="flex items-center gap-2">
                                    <div 
                                      className="w-3 h-3 rounded-full" 
                                      style={{ backgroundColor: stage.color }}
                                    />
                                    {stage.label}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label className="text-sm font-semibold">Webhook URL</Label>
                        <Input
                          value={webhook.webhook_url}
                          onChange={(e) => updateStatusWebhook(index, 'webhook_url', e.target.value)}
                          placeholder="https://flow.zoho.eu/..."
                          className="mt-1 font-mono text-sm"
                        />
                      </div>

                      {/* Payload Configuration */}
                      <div className="border-t pt-4">
                        <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                          <Zap className="w-4 h-4 text-indigo-600" />
                          Webhook Payload
                        </h4>
                        
                        <div className="mb-3">
                          <Label className="text-sm">Payload Type</Label>
                          <Select
                            value={webhook.payload_type || 'default'}
                            onValueChange={(value) => updateStatusWebhook(index, 'payload_type', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="default">Default Payload (Hardcoded)</SelectItem>
                              <SelectItem value="custom">Custom Payload (Template)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {webhook.payload_type === 'custom' && (
                          <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-4 space-y-3">
                            <div>
                              <Label className="text-sm font-semibold text-indigo-900">Custom Payload Template (JSON)</Label>
                              <p className="text-xs text-indigo-700 mb-2">
                                Use placeholders like <code className="bg-indigo-100 px-1 py-0.5 rounded">{'{{submission.applicant_name}}'}</code> to insert dynamic values
                              </p>
                              <Textarea
                                value={webhook.custom_payload_template || ''}
                                onChange={(e) => updateStatusWebhook(index, 'custom_payload_template', e.target.value)}
                                placeholder={'{\n  "submissionId": "{{submission.id}}",\n  "applicantName": "{{submission.applicant_name}}",\n  "applicantEmail": "{{submission.applicant_email}}",\n  "status": "{{newStatus}}",\n  "reminderNumber": "{{reminderCount}}"\n}'}
                                className="font-mono text-xs bg-white h-40"
                              />
                            </div>

                            <div>
                              <Label className="text-xs font-semibold text-indigo-900 mb-2 block">Available Placeholders:</Label>
                              <div className="bg-white rounded-lg p-3 max-h-64 overflow-y-auto space-y-3">
                                {availablePlaceholders.map((group) => (
                                  <div key={group.category}>
                                    <p className="text-xs font-bold text-gray-700 mb-1">{group.category}:</p>
                                    <div className="grid grid-cols-1 gap-1">
                                      {group.items.map((item, idx) => (
                                        <div key={idx}>
                                          <div className="flex items-start gap-2 text-xs">
                                            <code className="bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded font-mono flex-shrink-0">
                                              {item.placeholder}
                                            </code>
                                            <span className="text-gray-600">{item.description}</span>
                                          </div>
                                          {item.isSubform && item.subfields && (
                                            <div className="ml-4 mt-1 space-y-1 border-l-2 border-indigo-200 pl-2">
                                              {item.subfields.map((subfield, subIdx) => (
                                                <div key={subIdx} className="flex items-start gap-2 text-xs">
                                                  <code className="bg-purple-100 text-purple-800 px-1.5 py-0.5 rounded font-mono flex-shrink-0 text-[10px]">
                                                    {subfield.placeholder}
                                                  </code>
                                                  <span className="text-gray-500 text-[10px]">{subfield.description}</span>
                                                </div>
                                              ))}
                                              <p className="text-[10px] text-gray-500 italic mt-1">
                                                Note: Use [0] for first entry, [1] for second, etc.
                                              </p>
                                            </div>
                                          )}
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <Alert className="bg-indigo-100 border-indigo-300">
                              <AlertCircle className="h-4 w-4 text-indigo-700" />
                              <AlertDescription className="text-xs text-indigo-800">
                                <strong>Note:</strong> Your template must be valid JSON. The system will replace all placeholders with actual values at runtime.
                                If a placeholder references a non-existent field, it will be replaced with an empty string.
                                For subform arrays, access individual entries using array notation (e.g., <code className="bg-indigo-200 px-1 rounded">{'{{form_data.Referees[0].firstName}}'}</code>).
                              </AlertDescription>
                            </Alert>
                          </div>
                        )}

                        {webhook.payload_type === 'default' && (
                          <Alert className="bg-blue-50 border-blue-200">
                            <AlertCircle className="h-4 w-4 text-blue-700" />
                            <AlertDescription className="text-xs text-blue-800">
                              Using default payload with: submissionId, applicationUid, applicantName, applicantEmail, 
                              applicantOrganizationName, oldStatus, newStatus, formName, timestamp, reminderCount
                            </AlertDescription>
                          </Alert>
                        )}
                        
                        <div className="space-y-3 pt-3 border-t">
                          <div className="flex items-center justify-between">
                            <Label className="text-sm font-medium">Custom Message Prompt</Label>
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                id={`prompt-${webhook.id}`}
                                checked={webhook.prompt_for_custom_message || false}
                                onChange={(e) => updateStatusWebhook(index, 'prompt_for_custom_message', e.target.checked)}
                                className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                              />
                              <Label htmlFor={`prompt-${webhook.id}`} className="text-sm text-gray-600 cursor-pointer">
                                Prompt for custom message
                              </Label>
                            </div>
                          </div>
                          
                          {webhook.prompt_for_custom_message && (
                            <div className="grid grid-cols-2 gap-3 pl-6">
                              <div>
                                <Label className="text-xs text-gray-600">Prompt Label</Label>
                                <Input
                                  value={webhook.custom_message_prompt_label || 'Custom Message'}
                                  onChange={(e) => updateStatusWebhook(index, 'custom_message_prompt_label', e.target.value)}
                                  placeholder="e.g., Rejection Reason"
                                  className="text-sm mt-1"
                                />
                              </div>
                              <div>
                                <Label className="text-xs text-gray-600">Payload Key</Label>
                                <Input
                                  value={webhook.custom_message_payload_key || 'custom_message'}
                                  onChange={(e) => updateStatusWebhook(index, 'custom_message_payload_key', e.target.value)}
                                  placeholder="e.g., rejection_reason"
                                  className="text-sm mt-1 font-mono"
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Reminder Configuration */}
                      <div className="border-t pt-4">
                        <h4 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-blue-600" />
                          Reminder System (Optional)
                        </h4>
                        
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                            <Label className="text-sm">Reminder Interval (Days)</Label>
                            <Input
                              type="number"
                              min="0"
                              value={webhook.reminder_interval_days || 0}
                              onChange={(e) => updateStatusWebhook(index, 'reminder_interval_days', parseInt(e.target.value) || 0)}
                              placeholder="0"
                              className="mt-1"
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Set to 0 to disable reminders
                            </p>
                          </div>
                          <div>
                            <Label className="text-sm">Max Reminders</Label>
                            <Input
                              type="number"
                              min="0"
                              max="10"
                              value={webhook.max_reminders || 0}
                              onChange={(e) => updateStatusWebhook(index, 'max_reminders', parseInt(e.target.value) || 0)}
                              placeholder="0"
                              className="mt-1"
                            />
                            <p className="text-xs text-gray-500 mt-1">
                              Maximum number of reminder attempts
                            </p>
                          </div>
                        </div>

                        {/* Stop Condition Configuration */}
                        {(webhook.reminder_interval_days > 0 && webhook.max_reminders > 0) && (
                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <h5 className="text-sm font-semibold text-blue-900 mb-3">
                              Stop Condition
                            </h5>
                            <p className="text-xs text-blue-800 mb-3">
                              Reminders will automatically stop when this condition is met:
                            </p>
                            
                            <div className="grid grid-cols-3 gap-3">
                              <div>
                                <Label className="text-xs font-semibold">Submission Field</Label>
                                <Select
                                  value={webhook.stop_condition_field || ''}
                                  onValueChange={(value) => updateStatusWebhook(index, 'stop_condition_field', value)}
                                >
                                  <SelectTrigger className="mt-1 bg-white">
                                    <SelectValue placeholder="Select field" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {submissionEntityFields.map((field) => (
                                      <SelectItem key={field.value} value={field.value}>
                                        {field.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              
                              <div>
                                <Label className="text-xs font-semibold">Condition</Label>
                                <Select
                                  value={webhook.stop_condition_operator || 'not_empty'}
                                  onValueChange={(value) => updateStatusWebhook(index, 'stop_condition_operator', value)}
                                >
                                  <SelectTrigger className="mt-1 bg-white">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {stopConditionOperators.map((op) => (
                                      <SelectItem key={op.value} value={op.value}>
                                        {op.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              
                              {stopConditionOperators.find(op => op.value === webhook.stop_condition_operator)?.requiresValue && (
                                <div>
                                  <Label className="text-xs font-semibold">Value</Label>
                                  <Input
                                    value={webhook.stop_condition_value || ''}
                                    onChange={(e) => updateStatusWebhook(index, 'stop_condition_value', e.target.value)}
                                    placeholder="Expected value"
                                    className="mt-1 bg-white"
                                  />
                                </div>
                              )}
                            </div>

                            {webhook.stop_condition_field && (
                              <div className="mt-3 bg-white rounded p-2 text-xs font-mono text-gray-700">
                                <strong>Example:</strong> Stop reminders when <code className="bg-blue-100 px-1 py-0.5 rounded">{webhook.stop_condition_field}</code> {webhook.stop_condition_operator === 'not_empty' ? 'has a value' : webhook.stop_condition_operator === 'is_empty' ? 'is empty' : `${webhook.stop_condition_operator} "${webhook.stop_condition_value}"`}
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={webhook.enabled}
                            onCheckedChange={(checked) => updateStatusWebhook(index, 'enabled', checked)}
                            className="data-[state=checked]:bg-green-600"
                          />
                          <Label className="text-sm">
                            {webhook.enabled ? 'Enabled' : 'Disabled'}
                          </Label>
                        </div>
                        
                        <Button
                          onClick={() => handleOpenTestDialog(webhook)}
                          variant="outline"
                          size="sm"
                          className="gap-2 bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-300"
                        >
                          <Zap className="w-4 h-4" />
                          Test Webhook
                        </Button>
                      </div>
                    </div>

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeStatusWebhook(index)}
                      className="text-red-500 hover:text-red-700 hover:bg-red-50 mt-6"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}

          {statusWebhooks.length > 0 && (
            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-sm text-blue-800">
                <p className="font-semibold mb-2">💡 How It Works</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li><strong>Initial Trigger:</strong> Webhook fires when submission reaches the configured status</li>
                  <li><strong>Reminders:</strong> If configured, webhook fires again every X days (up to max reminders)</li>
                  <li><strong>Auto-Stop:</strong> Reminders automatically stop when the stop condition is met</li>
                  <li><strong>No External Config:</strong> Your external apps just update submission fields as normal</li>
                  <li><strong>Testing:</strong> Use "Test Webhook" button to simulate different reminder counts without modifying data</li>
                </ul>
                <p className="mt-3 text-xs">
                  <strong>Webhook Payload includes:</strong> submissionId, applicationUid, applicantName, applicantEmail, applicantOrganizationName, oldStatus, newStatus, formName, timestamp, reminderCount (for reminder emails)
                </p>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card className="bg-orange-50 border-orange-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Image className="w-5 h-5 text-orange-600" />
              <CardTitle className="text-base">CRM Logo Upload</CardTitle>
            </div>
            <Switch
              checked={crmLogoUploadConfig.enabled}
              onCheckedChange={(checked) => setCrmLogoUploadConfig(prev => ({ ...prev, enabled: checked }))}
              className="data-[state=checked]:bg-orange-600"
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-gray-600">
            Configure where to upload the designated organization logo to Zoho CRM. The logo must first be approved in the Documents section and designated as the organization's logo.
          </p>

          {crmLogoUploadConfig.enabled && (
            <div className="space-y-3 bg-white p-4 rounded-lg border">
              <div>
                <Label htmlFor="logo-org-field" className="text-sm font-medium">Organization Name Field (From Form)</Label>
                <Select
                  value={crmLogoUploadConfig.submission_org_name_field || ''}
                  onValueChange={(value) => setCrmLogoUploadConfig(prev => ({ ...prev, submission_org_name_field: value }))}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select organization name field" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableFields.map((field) => (
                      <SelectItem key={field.name} value={field.name}>
                        {field.label || field.name} ({field.type})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500 mt-1">
                  The form field containing the organization's name. This value will be used to search for or create the organization in CRM.
                </p>
              </div>

              <div>
                <Label htmlFor="logo-module" className="text-sm font-medium">CRM Module Name</Label>
                <Input
                  id="logo-module"
                  value={crmLogoUploadConfig.module_name || ''}
                  onChange={(e) => setCrmLogoUploadConfig(prev => ({ ...prev, module_name: e.target.value }))}
                  placeholder="e.g., isaasi_Organisations or Accounts"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The API name of the CRM module where the logo will be uploaded. Check Zoho CRM API documentation for exact module names.
                </p>
              </div>

              <div>
                <Label htmlFor="logo-crm-lookup" className="text-sm font-medium">CRM Lookup Field Name</Label>
                <Input
                  id="logo-crm-lookup"
                  value={crmLogoUploadConfig.crm_lookup_field || ''}
                  onChange={(e) => setCrmLogoUploadConfig(prev => ({ ...prev, crm_lookup_field: e.target.value }))}
                  placeholder="e.g., Name or Account_Name"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The field name in the CRM module to use for searching and matching organizations. This is typically "Name" but may vary by module.
                </p>
              </div>

              <div>
                <Label htmlFor="logo-field" className="text-sm font-medium">CRM Logo Field Name</Label>
                <Input
                  id="logo-field"
                  value={crmLogoUploadConfig.field_name || ''}
                  onChange={(e) => setCrmLogoUploadConfig(prev => ({ ...prev, field_name: e.target.value }))}
                  placeholder="e.g., Logo or Organization_Logo"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  The API name of the logo/image field within the CRM module where the file should be uploaded.
                </p>
              </div>

              <div className="flex justify-end pt-2 border-t">
                <Button
                  onClick={handleOpenTestLogoUploadDialog}
                  variant="outline"
                  size="sm"
                  className="gap-2 bg-orange-50 hover:bg-orange-100 text-orange-700 border-orange-300"
                >
                  <Zap className="w-4 h-4" />
                  Test Logo Upload
                </Button>
              </div>

              <Alert className="bg-orange-50 border-orange-300">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-xs text-orange-800">
                  <strong>UPSERT Logic:</strong> The system will search for an organization in the CRM module using the lookup field. 
                  If found, it updates the existing record with the logo. If not found, it creates a new organization record with the lookup field populated and uploads the logo.
                  Logo upload only happens when a submission status is moved to "Approved".
                </AlertDescription>
              </Alert>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Risk Level Configuration</CardTitle>
          <p className="text-sm text-gray-600 mt-2">Define custom risk levels with thresholds, names, and colors</p>
        </CardHeader>
        <CardContent>
          <RiskLevelEditor
            riskLevels={customRiskLevels}
            onChange={setCustomRiskLevels}
          />
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="gap-2"
        >
          <Save className="w-4 h-4" />
          {saveMutation.isPending ? 'Saving...' : 'Save Configuration'}
        </Button>
      </div>

      {/* Test Webhook Dialog */}
      <Dialog open={testWebhookDialog.open} onOpenChange={(open) => !open && handleCloseTestDialog()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-600" />
              Test Status Change Webhook
            </DialogTitle>
            <DialogDescription>
              {testWebhookDialog.webhook && (
                <div className="mt-2 space-y-2">
                  <p className="font-semibold text-gray-900">{testWebhookDialog.webhook.name}</p>
                  <p className="text-xs text-gray-600">
                    Trigger Status: <Badge variant="outline">{testWebhookDialog.webhook.trigger_status_id}</Badge>
                  </p>
                  <Alert className="bg-amber-50 border-amber-200 mt-3">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-xs text-amber-800">
                      This will trigger the webhook with test parameters. No database changes will be made to the submission.
                    </AlertDescription>
                  </Alert>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="test-submission-id" className="text-sm font-semibold">
                Submission ID *
              </Label>
              <Input
                id="test-submission-id"
                value={testWebhookDialog.submissionId}
                onChange={(e) => setTestWebhookDialog(prev => ({ ...prev, submissionId: e.target.value }))}
                placeholder="Enter submission ID to test with"
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                The submission data will be used in the webhook payload
              </p>
            </div>

            <div>
              <Label htmlFor="test-reminder-count" className="text-sm font-semibold">
                Test Reminder Count
              </Label>
              <Input
                id="test-reminder-count"
                type="number"
                min="0"
                max="100"
                value={testWebhookDialog.testReminderCount}
                onChange={(e) => setTestWebhookDialog(prev => ({ ...prev, testReminderCount: parseInt(e.target.value) || 0 }))}
                placeholder="0"
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                0 = Initial trigger, 1+ = Reminder number (for testing email templates)
              </p>
            </div>

            {testWebhookDialog.webhook?.prompt_for_custom_message && (
              <div>
                <Label htmlFor="test-custom-message" className="text-sm font-semibold">
                  {testWebhookDialog.webhook.custom_message_prompt_label || 'Custom Message'} (Optional)
                </Label>
                <Textarea
                  id="test-custom-message"
                  value={testWebhookDialog.customMessage}
                  onChange={(e) => setTestWebhookDialog(prev => ({ ...prev, customMessage: e.target.value }))}
                  placeholder="Enter your custom message here..."
                  rows={3}
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  This will be included in the payload as <code className="bg-blue-100 px-1 py-0.5 rounded">{testWebhookDialog.webhook.custom_message_payload_key || 'custom_message'}</code>
                </p>
              </div>
            )}

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-xs text-blue-800">
                <strong>Payload will include:</strong> submissionId, applicantName, applicantEmail, status info, <code className="bg-blue-100 px-1 py-0.5 rounded">reminderCount: {testWebhookDialog.testReminderCount}</code>
                {testWebhookDialog.webhook?.prompt_for_custom_message && testWebhookDialog.customMessage && (
                  <>, and <code className="bg-blue-100 px-1 py-0.5 rounded">{testWebhookDialog.webhook.custom_message_payload_key || 'custom_message'}</code></>
                )}
              </AlertDescription>
            </Alert>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={handleCloseTestDialog}
              disabled={testWebhookDialog.loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleTestWebhook}
              disabled={!testWebhookDialog.submissionId || testWebhookDialog.loading}
              className="gap-2 bg-purple-600 hover:bg-purple-700"
            >
              {testWebhookDialog.loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Triggering...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Trigger Test
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Test Logo Upload Dialog */}
      <Dialog open={testLogoUploadDialog.open} onOpenChange={(open) => !open && handleCloseTestLogoUploadDialog()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Image className="w-5 h-5 text-orange-600" />
              Test CRM Logo Upload
            </DialogTitle>
            <DialogDescription>
              <div className="mt-2 space-y-2">
                <p className="text-sm text-gray-700">
                  Test the logo upload functionality with an existing submission that has an approved and designated logo.
                </p>
                <Alert className="bg-amber-50 border-amber-200">
                  <AlertCircle className="h-4 w-4 text-amber-600" />
                  <AlertDescription className="text-xs text-amber-800">
                    This will actually upload the logo to your CRM. Make sure you're using a test submission or are ready for the logo to be uploaded.
                  </AlertDescription>
                </Alert>
              </div>
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="test-logo-submission-id" className="text-sm font-semibold">
                Submission ID *
              </Label>
              <Input
                id="test-logo-submission-id"
                value={testLogoUploadDialog.submissionId}
                onChange={(e) => setTestLogoUploadDialog(prev => ({ ...prev, submissionId: e.target.value }))}
                placeholder="Enter submission ID"
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                The submission must have an approved logo designated in the Documents section
              </p>
            </div>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-xs text-blue-800">
                <strong>Requirements:</strong>
                <ul className="list-disc list-inside mt-1 space-y-0.5">
                  <li>Submission must exist</li>
                  <li>Logo must be approved in Documents section</li>
                  <li>Logo must be designated as organization logo</li>
                  <li>Organization name must match a CRM record</li>
                </ul>
              </AlertDescription>
            </Alert>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={handleCloseTestLogoUploadDialog}
              disabled={testLogoUploadDialog.loading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleTestLogoUpload}
              disabled={!testLogoUploadDialog.submissionId || testLogoUploadDialog.loading}
              className="gap-2 bg-orange-600 hover:bg-orange-700"
            >
              {testLogoUploadDialog.loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Testing...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Test Upload
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
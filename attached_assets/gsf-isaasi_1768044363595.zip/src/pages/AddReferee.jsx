import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { UserPlus, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function AddReferee() {
  const urlParams = new URLSearchParams(window.location.search);
  const submissionId = urlParams.get('submissionId');
  const subformFieldName = urlParams.get('subformFieldName');

  const [refereeData, setRefereeData] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const { data: submission, isLoading: loadingSubmission } = useQuery({
    queryKey: ['submission', submissionId],
    queryFn: async () => {
      const subs = await base44.entities.Submission.filter({ id: submissionId });
      return subs[0];
    },
    enabled: !!submissionId,
  });

  const { data: formConfig, isLoading: loadingConfig } = useQuery({
    queryKey: ['formConfig', submission?.form_config_id],
    queryFn: async () => {
      const configs = await base44.entities.FormConfiguration.filter({ id: submission.form_config_id });
      return configs[0];
    },
    enabled: !!submission?.form_config_id,
  });

  // Find the subform field from the form structure
  const subformField = formConfig?.form_structure?.fields?.find(
    field => field.name === subformFieldName && field.type === 'subform'
  );

  const visibleSubfields = subformField?.subfields?.filter(sf => sf.visible !== false) || [];

  const handleInputChange = (subfieldName, value) => {
    setRefereeData(prev => ({
      ...prev,
      [subfieldName]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate required fields
    const missingRequired = visibleSubfields
      .filter(sf => sf.required)
      .filter(sf => !refereeData[sf.name] || refereeData[sf.name].trim() === '');
    
    if (missingRequired.length > 0) {
      toast.error(`Please fill in all required fields: ${missingRequired.map(f => f.label).join(', ')}`);
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await base44.functions.invoke('addRefereeToSubmission', {
        submissionId,
        subformFieldName,
        newRefereeData: refereeData
      });

      if (response.data.success) {
        setSubmitSuccess(true);
        toast.success('New referee added successfully!');
      } else {
        toast.error(response.data.message || 'Failed to add referee');
      }
    } catch (error) {
      console.error('Error adding referee:', error);
      toast.error('An error occurred while adding the referee');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!submissionId || !subformFieldName) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 mx-auto text-red-500 mb-4" />
            <p className="text-lg font-medium text-gray-900 mb-2">Invalid Link</p>
            <p className="text-sm text-gray-600">
              This link is missing required parameters. Please use the link provided in your email.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loadingSubmission || loadingConfig) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="py-12 text-center">
            <Loader2 className="w-12 h-12 mx-auto text-blue-600 mb-4 animate-spin" />
            <p className="text-lg font-medium text-gray-900">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!submission || !formConfig || !subformField) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 mx-auto text-red-500 mb-4" />
            <p className="text-lg font-medium text-gray-900 mb-2">Not Found</p>
            <p className="text-sm text-gray-600">
              The submission or form configuration could not be found.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (submitSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6 flex items-center justify-center">
        <Card className="max-w-2xl">
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="w-16 h-16 mx-auto text-green-600 mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Referee Added Successfully!</h2>
            <p className="text-gray-600 mb-6">
              The new referee has been added to your application. They will receive a signature request shortly.
            </p>
            <Alert className="bg-blue-50 border-blue-200 text-left">
              <AlertDescription className="text-sm text-gray-700">
                <strong>What happens next?</strong>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Your new referee will receive an email with the signature form</li>
                  <li>Once they complete it, our team will be notified</li>
                  <li>Your application will continue through the review process</li>
                </ul>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100 p-6">
      <div className="max-w-3xl mx-auto">
        <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
            <div className="flex items-center gap-3">
              <UserPlus className="w-8 h-8" />
              <div>
                <CardTitle className="text-2xl">Add New Referee</CardTitle>
                <p className="text-blue-100 text-sm mt-1">
                  Application: {submission.applicant_name || 'Unknown'}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <Alert className="bg-amber-50 border-amber-200 mb-6">
              <AlertCircle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-sm text-gray-700">
                <strong>Why am I seeing this?</strong>
                <br />
                One of your referees has not responded within the required timeframe. Please provide details for a replacement referee below.
              </AlertDescription>
            </Alert>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="bg-gray-50 rounded-lg p-4 border-2 border-gray-200">
                <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-blue-600" />
                  New {subformField.label || 'Referee'} Details
                </h3>
                
                <div className="space-y-4">
                  {visibleSubfields.map((subfield) => (
                    <div key={subfield.name}>
                      <Label htmlFor={subfield.name} className="text-sm font-semibold text-gray-700">
                        {subfield.label || subfield.name}
                        {subfield.required && <span className="text-red-500 ml-1">*</span>}
                      </Label>
                      <Input
                        id={subfield.name}
                        type={subfield.type === 'email' ? 'email' : 'text'}
                        value={refereeData[subfield.name] || ''}
                        onChange={(e) => handleInputChange(subfield.name, e.target.value)}
                        placeholder={subfield.label}
                        required={subfield.required}
                        className="mt-1"
                      />
                      {subfield.description && (
                        <p className="text-xs text-gray-500 mt-1">{subfield.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <p className="text-sm text-gray-700">
                  <strong>Note:</strong> After you submit this form, your new referee will receive an email with instructions to complete their part of the application. This will be added to your existing referees without removing any previous entries.
                </p>
              </div>

              <div className="flex gap-3 justify-end">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Adding Referee...
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" />
                      Add Referee
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Need help? Contact our support team
          </p>
        </div>
      </div>
    </div>
  );
}
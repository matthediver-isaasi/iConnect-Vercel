
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Download, RefreshCw, CheckCircle, AlertCircle, Loader2, Link as LinkIcon, FileEdit, Settings, Code } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function SyncForms() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState(null);
  const [editingPermalink, setEditingPermalink] = useState({});
  const [schemaDialogOpen, setSchemaDialogOpen] = useState(false);
  const [selectedFormSchema, setSelectedFormSchema] = useState(null);
  const [showRawSchema, setShowRawSchema] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: forms, isLoading } = useQuery({
    queryKey: ['forms'],
    queryFn: () => base44.entities.FormConfiguration.list("-created_date"),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const syncFromZoho = async () => {
    setSyncing(true);
    setSyncResult(null);
    
    try {
      const result = await base44.functions.invoke('syncZohoForms');
      setSyncResult(result.data);
      queryClient.invalidateQueries(['forms']);
    } catch (error) {
      setSyncResult({ 
        success: false, 
        message: error.message || 'Failed to sync forms. Please check your Zoho API credentials.' 
      });
    }
    
    setSyncing(false);
  };

  const scrapeFormSchema = async (formConfigId, permalink) => {
    try {
      const result = await base44.functions.invoke('scrapeFormSchema', {
        formConfigId,
        permalink
      });
      
      if (result.data.success) {
        toast.success(result.data.message);
        queryClient.invalidateQueries(['forms']);
        setEditingPermalink(prev => ({ ...prev, [formConfigId]: '' }));
      } else {
        toast.error(result.data.message);
      }
    } catch (error) {
      toast.error('Failed to scrape form schema: ' + error.message);
    }
  };

  const showSchema = (form) => {
    setSelectedFormSchema(form);
    setSchemaDialogOpen(true);
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sync Zoho Forms</h1>
        <p className="text-gray-500 mt-1">Import forms from your Zoho Forms account</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Sync Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <p className="font-medium">Connected Forms</p>
              <p className="text-sm text-gray-600 mt-1">{forms.length} form{forms.length !== 1 ? 's' : ''} configured</p>
            </div>
            <Button 
              onClick={syncFromZoho} 
              disabled={syncing}
              className="gap-2"
            >
              {syncing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  Sync Forms List
                </>
              )}
            </Button>
          </div>

          {syncResult && (
            <Alert variant={syncResult.success ? "default" : "destructive"}>
              {syncResult.success ? (
                <CheckCircle className="h-4 w-4" />
              ) : (
                <AlertCircle className="h-4 w-4" />
              )}
              <AlertDescription>
                {syncResult.message}
              </AlertDescription>
            </Alert>
          )}

          <div className="border-t pt-4">
            <h3 className="font-semibold mb-3">Setup Instructions</h3>
            <ol className="space-y-2 text-sm text-gray-600">
              <li className="flex gap-2">
                <span className="font-semibold text-blue-600">1.</span>
                <span>Click "Sync Forms List" to import your forms from Zoho</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold text-blue-600">2.</span>
                <span>For each form below, add its public permalink URL</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold text-blue-600">3.</span>
                <span>The system will automatically extract the form schema</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold text-blue-600">4.</span>
                <span>Go to Setup → Scoring to configure scoring rules</span>
              </li>
            </ol>
          </div>
        </CardContent>
      </Card>

      {forms.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Forms Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {forms.map((form) => {
                const hasSchema = form.form_structure?.fields?.length > 0;
                const isEditing = editingPermalink[form.id] !== undefined;
                
                return (
                  <div 
                    key={form.id}
                    className="border rounded-lg p-4 space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{form.form_name}</h3>
                        <p className="text-sm text-gray-600">Link Name: {form.zoho_form_id}</p>
                        <p className="text-xs text-gray-500 font-mono mt-1">ID: {form.id}</p>
                        {hasSchema && (
                          <p className="text-sm text-green-600 mt-1">
                            ✓ {form.form_structure.fields.length} fields configured
                          </p>
                        )}
                      </div>
                      <Badge variant={hasSchema ? "default" : "secondary"}>
                        {hasSchema ? 'Schema Ready' : 'Needs Permalink'}
                      </Badge>
                    </div>

                    {form.permalink && (
                      <div className="text-sm text-gray-600 bg-gray-50 p-2 rounded">
                        <span className="font-medium">Permalink:</span> {form.permalink}
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Input
                        placeholder="Paste form permalink URL here..."
                        value={isEditing ? editingPermalink[form.id] : form.permalink || ''}
                        onChange={(e) => setEditingPermalink(prev => ({ 
                          ...prev, 
                          [form.id]: e.target.value 
                        }))}
                        className="flex-1"
                      />
                      <Button
                        onClick={() => scrapeFormSchema(
                          form.id, 
                          isEditing ? editingPermalink[form.id] : form.permalink
                        )}
                        disabled={!(isEditing ? editingPermalink[form.id] : form.permalink)}
                        className="gap-2"
                      >
                        <LinkIcon className="w-4 h-4" />
                        {hasSchema ? 'Update' : 'Fetch'} Schema
                      </Button>
                    </div>

                    <div className="flex gap-2">
                      {hasSchema && (
                        <>
                          <Button 
                            variant="outline" 
                            className="gap-2 flex-1"
                            onClick={() => showSchema(form)}
                          >
                            <Code className="w-4 h-4" />
                            View Schema
                          </Button>
                          <Link to={createPageUrl(`FillForm?id=${form.id}`)} className="flex-1">
                            <Button variant="outline" className="w-full gap-2">
                              <FileEdit className="w-4 h-4" />
                              Fill This Form
                            </Button>
                          </Link>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={schemaDialogOpen} onOpenChange={(open) => {
        setSchemaDialogOpen(open);
        if (!open) setShowRawSchema(false); // Reset to formatted view when closing
      }}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <Code className="w-5 h-5" />
                Form Schema: {selectedFormSchema?.form_name}
              </DialogTitle>
              <Button
                variant={showRawSchema ? "default" : "outline"}
                size="sm"
                onClick={() => setShowRawSchema(!showRawSchema)}
                className="gap-2"
              >
                <Code className="w-4 h-4" />
                {showRawSchema ? 'Show Formatted' : 'Show Raw JSON'}
              </Button>
            </div>
          </DialogHeader>
          
          {selectedFormSchema?.form_structure && (
            <ScrollArea className="h-[60vh] pr-4">
              {showRawSchema ? (
                <div className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-auto">
                  <pre className="text-xs font-mono">
                    {JSON.stringify(selectedFormSchema.form_structure, null, 2)}
                  </pre>
                </div>
              ) : (
                <div className="space-y-4">
                  <Alert>
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Field Names</strong> are what Zoho sends in the webhook payload. Use these exact names when mapping webhook data.
                    </AlertDescription>
                  </Alert>

                  {selectedFormSchema.form_structure.fields.map((field, index) => (
                    <Card key={field.name} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold">
                                {index + 1}
                              </span>
                              <h4 className="font-semibold text-lg">{field.label || field.name}</h4>
                            </div>
                            <div className="flex gap-2">
                              <Badge variant="outline">{field.type}</Badge>
                              {field.required && <Badge className="bg-red-100 text-red-800">Required</Badge>}
                              {field.visible === false && <Badge variant="secondary">Hidden</Badge>}
                            </div>
                          </div>
                          
                          <div className="bg-gray-50 p-3 rounded-lg space-y-1 font-mono text-sm">
                            <div>
                              <span className="text-gray-600">Field Name:</span>{' '}
                              <code className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded">{field.name}</code>
                            </div>
                            {field.compname && (
                              <div>
                                <span className="text-gray-600">Component:</span>{' '}
                                <span className="text-gray-800">{field.compname}</span>
                              </div>
                            )}
                            {field.placeholder && (
                              <div>
                                <span className="text-gray-600">Placeholder:</span>{' '}
                                <span className="text-gray-800">{field.placeholder}</span>
                              </div>
                            )}
                            {field.description && (
                              <div>
                                <span className="text-gray-600">Description:</span>{' '}
                                <span className="text-gray-800">{field.description}</span>
                              </div>
                            )}
                          </div>

                          {field.options && field.options.length > 0 && (
                            <div className="mt-2">
                              <p className="text-sm font-medium text-gray-700 mb-2">Options:</p>
                              <div className="space-y-1">
                                {field.options.map((option, idx) => (
                                  <div key={idx} className="text-sm bg-gray-50 px-3 py-1.5 rounded border">
                                    <code className="text-blue-600">{option.value || option}</code>
                                    {option.label && option.label !== option.value && (
                                      <span className="text-gray-600 ml-2">({option.label})</span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  {selectedFormSchema.form_structure.numeric_id && (
                    <Alert>
                      <AlertDescription>
                        <strong>Numeric Form ID:</strong>{' '}
                        <code className="bg-gray-100 px-2 py-1 rounded">{selectedFormSchema.form_structure.numeric_id}</code>
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              )}
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

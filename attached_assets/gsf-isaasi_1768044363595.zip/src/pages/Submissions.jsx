import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Loader2, ChevronRight, AlertCircle } from "lucide-react";

export default function Submissions() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submissions = [], isLoading: submissionsLoading } = useQuery({
    queryKey: ['submissions-page-list'],
    queryFn: async () => {
      const result = await base44.entities.Submission.list("-created_date");
      return result;
    },
    enabled: isAuthenticated === true,
  });

  const { data: formConfigs = [], isLoading: configsLoading } = useQuery({
    queryKey: ['submissions-page-configs'],
    queryFn: async () => {
      const result = await base44.entities.FormConfiguration.list();
      return result;
    },
    enabled: isAuthenticated === true,
  });

  if (isAuthenticated === null || submissionsLoading || configsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  // Group submissions by form
  const submissionsByForm = formConfigs.map(form => {
    const formSubmissions = submissions.filter(sub => sub.form_config_id === form.id);
    
    // Count by status
    const statusCounts = {};
    formSubmissions.forEach(sub => {
      statusCounts[sub.status] = (statusCounts[sub.status] || 0) + 1;
    });

    // Get stage display info
    const getStageDisplay = (stageId) => {
      const stage = form.workflow_stages?.find(s => s.id === stageId);
      if (stage) {
        return { label: stage.label, color: stage.color };
      }
      return { label: stageId, color: "#6b7280" };
    };

    return {
      form,
      totalCount: formSubmissions.length,
      statusCounts,
      getStageDisplay
    };
  }).filter(item => item.totalCount > 0); // Only show forms with submissions

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Submissions</h1>
        <p className="text-gray-500 mt-1">
          {submissions.length} total submission{submissions.length !== 1 ? 's' : ''} across {submissionsByForm.length} form{submissionsByForm.length !== 1 ? 's' : ''}
        </p>
      </div>

      {submissionsByForm.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
            <p className="text-lg font-medium text-gray-900">No submissions found</p>
            <p className="text-sm text-gray-500 mt-1">
              Submissions will appear here when forms are submitted
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {submissionsByForm.map(({ form, totalCount, statusCounts, getStageDisplay }) => (
            <Link 
              key={form.id} 
              to={createPageUrl(`FormSubmissions?formId=${form.id}`)}
              className="block"
            >
              <Card className="h-full hover:shadow-lg transition-all duration-200 hover:border-blue-300 cursor-pointer group">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                        {form.form_name}
                      </CardTitle>
                      <p className="text-xs text-gray-500 mt-1 truncate">
                        {form.zoho_form_id}
                      </p>
                    </div>
                    <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-600 transition-colors flex-shrink-0 ml-2" />
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Total Submissions</span>
                    <Badge variant="secondary" className="text-lg font-bold px-3">
                      {totalCount}
                    </Badge>
                  </div>

                  {Object.keys(statusCounts).length > 0 && (
                    <div className="space-y-2 pt-2 border-t">
                      <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                        By Status
                      </p>
                      {Object.entries(statusCounts)
                        .sort((a, b) => b[1] - a[1]) // Sort by count descending
                        .slice(0, 3) // Show top 3 statuses
                        .map(([status, count]) => {
                          const stageDisplay = getStageDisplay(status);
                          return (
                            <div key={status} className="flex items-center justify-between text-sm">
                              <div className="flex items-center gap-2">
                                <div 
                                  className="w-3 h-3 rounded-full flex-shrink-0"
                                  style={{ backgroundColor: stageDisplay.color }}
                                />
                                <span className="text-gray-700 truncate">{stageDisplay.label}</span>
                              </div>
                              <span className="font-semibold text-gray-900">{count}</span>
                            </div>
                          );
                        })}
                      {Object.keys(statusCounts).length > 3 && (
                        <p className="text-xs text-gray-500 italic pt-1">
                          +{Object.keys(statusCounts).length - 3} more status{Object.keys(statusCounts).length - 3 > 1 ? 'es' : ''}
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
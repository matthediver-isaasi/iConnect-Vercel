
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle, Save, ArrowLeft, Trash2, FileJson, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function ManageSubmissions() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [selectedSubmissionId, setSelectedSubmissionId] = useState(null);
  const [editedFormData, setEditedFormData] = useState({});
  const [showRawPayloadModal, setShowRawPayloadModal] = useState(false);
  const [rawPayloadContent, setRawPayloadContent] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submissions, isLoading: submissionsLoading } = useQuery({
    queryKey: ['submissions'],
    queryFn: () => base44.entities.Submission.list("-created_date"),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const { data: formConfigs } = useQuery({
    queryKey: ['formConfigs'],
    queryFn: () => base44.entities.FormConfiguration.list(),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const selectedSubmission = submissions.find(s => s.id === selectedSubmissionId);
  const formConfig = formConfigs.find(f => f.id === selectedSubmission?.form_config_id);

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Submission.update(selectedSubmissionId, data),
    onSuccess: () => {
      queryClient.invalidateQueries(['submissions']);
      toast.success('Submission updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update submission: ' + error.message);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Submission.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['submissions']);
      toast.success('Submission deleted successfully');
      setSelectedSubmissionId(null);
    },
    onError: (error) => {
      toast.error('Failed to delete submission: ' + error.message);
    }
  });

  const handleSelectSubmission = (submission) => {
    setSelectedSubmissionId(submission.id);
    setEditedFormData({ ...submission.form_data } || {});
  };

  const handleViewRawPayload = (submission) => {
    const payload = submission.form_data || {};
    setRawPayloadContent(JSON.stringify(payload, null, 2));
    setShowRawPayloadModal(true);
  };

  const handleFieldChange = (fieldName, value) => {
    setEditedFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const handleSave = () => {
    updateMutation.mutate({
      form_data: editedFormData,
      original_form_data: editedFormData, // Update both so reset works properly
      applicant_name: editedFormData.Name_First && editedFormData.Name_Last 
        ? `${editedFormData.Name_First} ${editedFormData.Name_Last}`
        : editedFormData.Name || selectedSubmission.applicant_name,
      applicant_email: editedFormData.Email || selectedSubmission.applicant_email
    });
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this submission?')) {
      deleteMutation.mutate(selectedSubmissionId);
    }
  };

  const renderFieldInput = (field, value) => {
    if (field.type === 'name') {
      return (
        <div className="space-y-2">
          <div>
            <Label className="text-xs text-gray-500">First Name</Label>
            <Input
              type="text"
              value={editedFormData[`${field.name}_First`] || ''}
              onChange={(e) => handleFieldChange(`${field.name}_First`, e.target.value)}
              placeholder="First Name"
            />
          </div>
          <div>
            <Label className="text-xs text-gray-500">Last Name</Label>
            <Input
              type="text"
              value={editedFormData[`${field.name}_Last`] || ''}
              onChange={(e) => handleFieldChange(`${field.name}_Last`, e.target.value)}
              placeholder="Last Name"
            />
          </div>
        </div>
      );
    }

    if (field.type === 'address') {
      return (
        <div className="space-y-2">
          <div>
            <Label className="text-xs text-gray-500">Address Line 1</Label>
            <Input
              type="text"
              value={editedFormData[`${field.name}_address1`] || ''}
              onChange={(e) => handleFieldChange(`${field.name}_address1`, e.target.value)}
              placeholder="Address Line 1"
            />
          </div>
          <div>
            <Label className="text-xs text-gray-500">Address Line 2</Label>
            <Input
              type="text"
              value={editedFormData[`${field.name}_address2`] || ''}
              onChange={(e) => handleFieldChange(`${field.name}_address2`, e.target.value)}
              placeholder="Address Line 2"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-xs text-gray-500">City</Label>
              <Input
                type="text"
                value={editedFormData[`${field.name}_city`] || ''}
                onChange={(e) => handleFieldChange(`${field.name}_city`, e.target.value)}
                placeholder="City"
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500">Postal/Zip Code</Label>
              <Input
                type="text"
                value={editedFormData[`${field.name}_zipCode`] || ''}
                onChange={(e) => handleFieldChange(`${field.name}_zipCode`, e.target.value)}
                placeholder="Postal/Zip Code"
              />
            </div>
          </div>
          <div>
            <Label className="text-xs text-gray-500">Country</Label>
            <Input
              type="text"
              value={editedFormData[`${field.name}_country`] || ''}
              onChange={(e) => handleFieldChange(`${field.name}_country`, e.target.value)}
              placeholder="Country"
            />
          </div>
        </div>
      );
    }

    switch (field.type) {
      case 'text':
      case 'email':
      case 'number':
      case 'phone':
        return (
          <Input
            type={field.type === 'number' ? 'number' : field.type === 'email' ? 'email' : 'text'}
            value={value || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            placeholder={field.placeholder || ''}
          />
        );

      case 'textarea':
      case 'paragraph':
        return (
          <Textarea
            value={value || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            placeholder={field.placeholder || ''}
            rows={4}
          />
        );

      case 'checkbox':
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              checked={value === true || value === 'true'}
              onCheckedChange={(checked) => handleFieldChange(field.name, checked)}
            />
            <Label className="font-normal cursor-pointer">{field.label}</Label>
          </div>
        );

      case 'dropdown':
      case 'select':
        return (
          <Select 
            value={value || ''} 
            onValueChange={(val) => handleFieldChange(field.name, val)}
          >
            <SelectTrigger>
              <SelectValue placeholder={field.placeholder || 'Select an option'} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, idx) => (
                <SelectItem key={idx} value={option.value || option}>
                  {option.label || option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'radio':
        return (
          <div className="space-y-2">
            {field.options?.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="radio"
                  id={`${field.name}-${idx}`}
                  name={field.name}
                  value={option.value || option}
                  checked={value === (option.value || option)}
                  onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  className="w-4 h-4"
                />
                <Label htmlFor={`${field.name}-${idx}`} className="font-normal cursor-pointer">
                  {option.label || option}
                </Label>
              </div>
            ))}
          </div>
        );

      case 'date':
        return (
          <Input
            type="date"
            value={value || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
          />
        );

      default:
        return (
          <Input
            value={value || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            placeholder={field.placeholder || ''}
          />
        );
    }
  };

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (submissionsLoading) {
    return <div className="p-6 md:p-8">Loading...</div>;
  }

  if (selectedSubmission && formConfig) {
    return (
      <div className="p-6 md:p-8 max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setSelectedSubmissionId(null)}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">Edit Submission</h1>
              <p className="text-gray-600">{selectedSubmission.applicant_name || 'Unnamed'}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteMutation.isPending}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Delete
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateMutation.isPending}
              className="gap-2"
            >
              <Save className="w-4 h-4" />
              {updateMutation.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{formConfig.form_name}</CardTitle>
            <p className="text-sm text-gray-600">Edit all form fields below</p>
          </CardHeader>
          <CardContent>
            {formConfig.form_structure?.fields ? (
              <div className="space-y-6">
                {formConfig.form_structure.fields
                  .filter(field => field.visible !== false)
                  .map((field) => (
                    <div key={field.name} className="space-y-2">
                      <Label className="text-sm font-medium flex items-center gap-1">
                        {field.label || field.name}
                        {field.required && <span className="text-red-500">*</span>}
                      </Label>
                      {field.description && (
                        <p className="text-sm text-gray-500">{field.description}</p>
                      )}
                      {renderFieldInput(field, editedFormData[field.name])}
                    </div>
                  ))}
              </div>
            ) : (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  No form structure available for this form configuration
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Manage Test Submissions</h1>
        <p className="text-gray-600 mt-1">Create and edit test submissions for development</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          {submissions.length > 0 ? (
            <div className="space-y-3">
              {submissions.map((sub) => (
                <div
                  key={sub.id}
                  className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1 cursor-pointer" onClick={() => handleSelectSubmission(sub)}>
                    <h3 className="font-semibold">{sub.applicant_name || 'Unnamed Applicant'}</h3>
                    <p className="text-sm text-gray-600">{sub.applicant_email || 'No email'}</p>
                    <p className="text-xs text-gray-500 mt-1">Form: {formConfigs.find(f => f.id === sub.form_config_id)?.form_name || 'Unknown'}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleViewRawPayload(sub);
                      }}
                      className="gap-2"
                    >
                      <FileJson className="w-4 h-4" />
                      View Payload
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectSubmission(sub);
                      }}
                    >
                      Edit
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No submissions found</p>
              <p className="text-sm mt-1">Create test submissions using the insert action</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showRawPayloadModal} onOpenChange={setShowRawPayloadModal}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileJson className="w-5 h-5" />
              Raw Submission Payload
            </DialogTitle>
            <DialogDescription>
              Complete JSON structure of the form data as received from Zoho
            </DialogDescription>
          </DialogHeader>
          <ScrollArea className="h-[60vh] w-full rounded-md border p-4">
            <pre className="text-xs font-mono whitespace-pre-wrap break-words">
              {rawPayloadContent}
            </pre>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}



import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { LayoutDashboard, FileText, Settings, Download, Target, LogOut, Loader2 } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";
import { NavigationGuardProvider, useNavigationGuard } from "@/components/NavigationGuard";
import { Button } from "@/components/ui/button"; // Assuming Button component is located here
import { useNavigate } from "react-router-dom";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Submissions",
    url: createPageUrl("Submissions"),
    icon: FileText,
  },
  {
    title: "Sync Forms",
    url: createPageUrl("SyncForms"),
    icon: Download,
  },
];

const setupItems = [
  {
    title: "Scoring",
    url: createPageUrl("Scoring"),
    icon: Target,
  },
  {
    title: "Form Fields",
    url: createPageUrl("FormFields"),
    icon: Settings,
  },
];

const adminItems = [
  {
    title: "Manage Submissions",
    url: createPageUrl("ManageSubmissions"),
    icon: FileText,
  },
  {
    title: "Test CRM Attachments",
    url: createPageUrl("TestCrmAttachments"),
    icon: Settings,
  },
  {
    title: "Test Signed Agreement",
    url: createPageUrl("TestSignedAgreement"),
    icon: FileText,
  },
];

function GuardedLink({ to, children, className, ...props }) {
  const { attemptNavigation } = useNavigationGuard();

  const handleClick = (e) => {
    e.preventDefault();
    attemptNavigation(to);
  };

  return (
    <a href={to} onClick={handleClick} className={className} {...props}>
      {children}
    </a>
  );
}

function VerificationCheck({ children }) {
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const [isChecking, setIsChecking] = React.useState(true);

  React.useEffect(() => {
    const checkVerification = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        // Check verification_status - default to "pending" if not set
        const verificationStatus = currentUser.verification_status || "pending";
        const isVerified = verificationStatus === "verified";
        
        console.log('User verification check:', {
          email: currentUser.email,
          verification_status: currentUser.verification_status,
          isVerified: isVerified
        });
        
        if (!isVerified) {
          navigate(createPageUrl('PendingVerification'));
        }
      } catch (error) {
        console.error('Error checking user verification:', error);
      } finally {
        setIsChecking(false);
      }
    };

    checkVerification();
  }, [navigate]);

  return children({ isChecking });
}

function LayoutContent({ children, isChecking = false }) {
  const location = useLocation();
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => setUser(null));
  }, []);

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100">
      <Sidebar className="border-r border-gray-200 bg-white/80 backdrop-blur-sm">
        <SidebarHeader className="border-b border-gray-200 p-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-xl flex items-center justify-center shadow-lg">
              <FileText className="w-7 h-7 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-gray-900 text-lg">GSF</h2>
              <p className="text-xs text-gray-500 font-semibold">Due Diligence System</p>
            </div>
          </div>
        </SidebarHeader>
        
        <SidebarContent className="p-3">
          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-bold text-gray-500 uppercase tracking-wider px-2 py-3">
              Navigation
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {navigationItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl mb-1 ${
                        location.pathname === item.url ? 'bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-sm border border-blue-200' : ''
                      }`}
                    >
                      <GuardedLink to={item.url} className="flex items-center gap-3 px-4 py-3">
                        <item.icon className="w-5 h-5" />
                        <span className="font-semibold">{item.title}</span>
                      </GuardedLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-bold text-gray-500 uppercase tracking-wider px-2 py-3 mt-2">
              Setup
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <Collapsible defaultOpen className="group/collapsible">
                  <SidebarMenuItem>
                    <CollapsibleTrigger asChild>
                      <SidebarMenuButton className="hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl mb-1">
                        <Settings className="w-5 h-5" />
                        <span className="font-semibold">Configuration</span>
                        <ChevronDown className="ml-auto w-4 h-4 transition-transform group-data-[state=open]/collapsible:rotate-180" />
                      </SidebarMenuButton>
                    </CollapsibleTrigger>
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {setupItems.map((item) => (
                          <SidebarMenuSubItem key={item.title}>
                            <SidebarMenuSubButton 
                              asChild
                              className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl ${
                                location.pathname === item.url ? 'bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-sm border border-blue-200' : ''
                              }`}
                            >
                              <GuardedLink to={item.url} className="flex items-center gap-3 px-4 py-2">
                                <item.icon className="w-4 h-4" />
                                <span className="font-semibold">{item.title}</span>
                              </GuardedLink>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  </SidebarMenuItem>
                </Collapsible>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          <SidebarGroup>
            <SidebarGroupLabel className="text-xs font-bold text-gray-500 uppercase tracking-wider px-2 py-3 mt-2">
              Admin
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      asChild 
                      className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-xl mb-1 ${
                        location.pathname === item.url ? 'bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-sm border border-blue-200' : ''
                      }`}
                    >
                      <GuardedLink to={item.url} className="flex items-center gap-3 px-4 py-3">
                        <item.icon className="w-5 h-5" />
                        <span className="font-semibold">{item.title}</span>
                      </GuardedLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

        </SidebarContent>

        <SidebarFooter className="border-t border-gray-200 p-4 bg-gradient-to-r from-slate-50 to-blue-50">
          <div className="space-y-3">
            <div className="text-xs text-gray-600">
              <p className="font-bold text-gray-800">Member Registration</p>
              <p className="font-semibold">Due Diligence Management</p>
            </div>
            
            {user && (
              <div className="pt-2 border-t border-gray-200">
                <div className="text-xs text-gray-600 mb-2">
                  <p className="font-semibold truncate">{user.full_name}</p>
                  <p className="text-gray-500 truncate">{user.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="flex-1 gap-2 hover:bg-red-50 hover:text-red-700 hover:border-red-200 transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Log Out
                  </Button>
                  {isChecking && (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-600 flex-shrink-0" />
                  )}
                </div>
              </div>
            )}
          </div>
        </SidebarFooter>
      </Sidebar>

      <main className="flex-1 flex flex-col">
        <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 px-6 py-4 md:hidden shadow-sm">
          <div className="flex items-center gap-4">
            <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-lg transition-colors duration-200" />
            <h1 className="text-xl font-bold text-gray-900">GSF Due Diligence</h1>
          </div>
        </header>

        <div className="flex-1 overflow-auto">
          {children}
        </div>

        <footer className="bg-white border-t border-slate-200 py-6">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <a 
              href="https://isaasi.co.uk" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-block mb-3 hover:opacity-80 transition-opacity"
            >
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68efc20f3e0a30fafad6dde7/fe03f7c5e_linked-aa.png" 
                alt="isaasi"
                className="w-[50px] mx-auto"
              />
            </a>
            <p className="text-sm text-slate-600">
              <span style={{ color: '#eb008c' }}>i</span>Connect by{' '}
              <a 
                href="https://isaasi.co.uk" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hover:opacity-80 transition-opacity font-medium"
                style={{ color: '#eb008c' }}
              >
                isaasi
              </a>
              {' '}- © Copyright {new Date().getFullYear() === 2025 ? '2025' : `2025-${new Date().getFullYear()}`}
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  // List of public pages that should NOT have the layout wrapper
  const publicPages = ['AddReferee', 'FillForm', 'PendingVerification'];
  
  // Check if the current page is a public page
  const isPublicPage = publicPages.includes(currentPageName);
  
  // Font style to be applied universally
  const globalFontStyle = (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Source+Sans+3:wght@300;400;600;700;900&display=swap');
      
      * {
        font-family: 'Source Sans 3', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      }
    `}</style>
  );

  // If it's a public page, render children directly without layout
  if (isPublicPage) {
    return (
      <>
        {globalFontStyle}
        {children}
      </>
    );
  }
  
  // For authenticated pages, use the full layout with verification check
  return (
    <SidebarProvider>
      {globalFontStyle}
      
      <NavigationGuardProvider>
        <VerificationCheck>
          {({ isChecking }) => (
            <LayoutContent isChecking={isChecking}>{children}</LayoutContent>
          )}
        </VerificationCheck>
      </NavigationGuardProvider>
    </SidebarProvider>
  );
}


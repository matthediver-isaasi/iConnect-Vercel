
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, AlertCircle, Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Scoring() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: forms, isLoading } = useQuery({
    queryKey: ['forms'],
    queryFn: () => base44.entities.FormConfiguration.list("-created_date"),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Scoring Configuration</h1>
        <p className="text-gray-500 mt-1">Configure due diligence scoring rules for each form</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Available Forms</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="p-4 border rounded-lg">
                  <Skeleton className="h-6 w-64 mb-2" />
                  <Skeleton className="h-4 w-32" />
                </div>
              ))}
            </div>
          ) : forms.length > 0 ? (
            <div className="space-y-4">
              {forms.map((form) => {
                const hasSchema = form.form_structure?.fields?.length > 0;
                const hasScoringRules = form.scoring_rules?.rules?.length > 0 || form.static_questions?.length > 0;
                
                return (
                  <div
                    key={form.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="font-semibold text-lg">{form.form_name}</h3>
                        {form.scoring_approach && (
                          <Badge variant="outline">
                            {form.scoring_approach === 'dynamic' ? 'Dynamic Scoring' : 'Traffic Light'}
                          </Badge>
                        )}
                        {hasScoringRules && (
                          <Badge className="bg-green-100 text-green-800">
                            ✓ Configured
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">Link Name: {form.zoho_form_id}</p>
                      {!hasSchema && (
                        <p className="text-sm text-orange-600 mt-1">
                          ⚠ No schema available - please add permalink in Sync Forms
                        </p>
                      )}
                    </div>
                    <Link to={createPageUrl(`ConfigureScoring?id=${form.id}`)}>
                      <Button 
                        variant={hasScoringRules ? "outline" : "default"}
                        className="gap-2"
                        disabled={!hasSchema}
                      >
                        <Settings className="w-4 h-4" />
                        {hasScoringRules ? 'Edit' : 'Configure'}
                      </Button>
                    </Link>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <AlertCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-lg font-medium">No forms available</p>
              <p className="text-sm mt-1">Sync your Zoho Forms to get started</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

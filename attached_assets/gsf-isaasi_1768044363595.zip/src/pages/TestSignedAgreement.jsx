
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Send, AlertCircle, CheckCircle2, Loader2, Copy } from "lucide-react";
import { toast } from "sonner";

export default function TestSignedAgreement() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [applicationUid, setApplicationUid] = useState(''); // Added from outline, though not used in provided logic
  const [selectedSubmissionId, setSelectedSubmissionId] = useState('');
  const [selectedSignatureField, setSelectedSignatureField] = useState('');
  const [testPayload, setTestPayload] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  const { data: submissions, isLoading: submissionsLoading } = useQuery({
    queryKey: ['submissions-test'],
    queryFn: () => base44.entities.Submission.list('-created_date'),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const { data: formConfigs, isLoading: configsLoading } = useQuery({
    queryKey: ['formConfigs-test'],
    queryFn: () => base44.entities.FormConfiguration.list(),
    initialData: [],
    enabled: isAuthenticated === true,
  });

  const selectedSubmission = submissions.find(s => s.id === selectedSubmissionId);
  const formConfig = formConfigs.find(f => f.id === selectedSubmission?.form_config_id);

  // Get all signature email fields from the form config
  const signatureFields = React.useMemo(() => {
    if (!formConfig?.form_structure?.fields) return [];
    
    const fields = [];
    
    formConfig.form_structure.fields.forEach(field => {
      if (field.type === 'email' && field.is_signature_email) {
        fields.push({
          name: field.name,
          label: field.label || field.name,
          signingFormConfigId: field.signing_form_config_id
        });
      }
      
      // Check subform fields
      if (field.type === 'subform' && field.subfields) {
        field.subfields.forEach(subfield => {
          if (subfield.type === 'email' && subfield.is_signature_email) {
            fields.push({
              name: subfield.name,
              label: `${field.label || field.name} > ${subfield.label || subfield.name}`,
              signingFormConfigId: subfield.signing_form_config_id,
              parentSubform: field.name
            });
          }
        });
      }
    });
    
    return fields;
  }, [formConfig]);

  const selectedFieldInfo = signatureFields.find(f => f.name === selectedSignatureField);
  const signingFormConfig = formConfigs.find(f => f.id === selectedFieldInfo?.signingFormConfigId);

  // Generate example payload when submission and field are selected
  React.useEffect(() => {
    if (selectedSubmission && selectedSignatureField && signingFormConfig) {
      const examplePayload = {
        applicationUid: selectedSubmission.application_uid,
        signatureFieldName: selectedSignatureField,
        signerEmail: "test@example.com",
        zohoSigningFormId: signingFormConfig.zoho_form_id,
        // Add example fields from the signing form
        ...(signingFormConfig.form_structure?.fields?.reduce((acc, field) => {
          if (field.type === 'text' || field.type === 'email') {
            acc[field.name] = `Sample ${field.label || field.name}`;
          } else if (field.type === 'checkbox') {
            acc[field.name] = true;
          } else if (field.type === 'date') {
            acc[field.name] = new Date().toISOString().split('T')[0];
          }
          return acc;
        }, {}) || {})
      };
      
      setTestPayload(JSON.stringify(examplePayload, null, 2));
    }
  }, [selectedSubmission, selectedSignatureField, signingFormConfig]);

  const handleTest = async () => {
    if (!testPayload.trim()) {
      toast.error("Please enter a test payload");
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      // Parse the payload to validate it
      const parsedPayload = JSON.parse(testPayload);

      // Call the receiveSignedAgreement function
      const response = await base44.functions.invoke('receiveSignedAgreement', parsedPayload);

      setTestResult({
        success: response.data.success,
        data: response.data,
        rawResponse: response
      });

      if (response.data.success) {
        toast.success("Webhook test successful!");
      } else {
        toast.error(response.data.message || "Webhook test failed");
      }
    } catch (error) {
      setTestResult({
        success: false,
        error: error.message,
        stack: error.stack
      });
      toast.error("Error during test: " + error.message);
    } finally {
      setIsTesting(false);
    }
  };

  const copyFunctionUrl = async () => {
    // Get the actual backend function URL
    const functionUrl = `${window.location.origin}/api/functions/receiveSignedAgreement`;
    await navigator.clipboard.writeText(functionUrl);
    toast.success("Function URL copied to clipboard");
  };

  const copyExamplePayload = async () => {
    const examplePayload = {
      applicationUid: "YOUR_APPLICATION_UID",
      signatureFieldName: "Email4",
      signerEmail: "signer@example.com",
      zohoSigningFormId: "YOUR_SIGNING_FORM_ID",
      // Add any other fields from your signing form
      fieldName1: "Sample value",
      fieldName2: "Another value"
    };
    await navigator.clipboard.writeText(JSON.stringify(examplePayload, null, 2));
    toast.success("Example payload copied to clipboard");
  };

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Test Signed Agreement Webhook</h1>
        <p className="text-gray-500 mt-1">Test the webhook that receives signed agreement data from Zoho Forms</p>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          <strong>How to use:</strong>
          <ol className="list-decimal list-inside mt-2 space-y-1 text-sm">
            <li>Select a submission to get the Application UID</li>
            <li>Select which signature field you're testing</li>
            <li>Review and modify the auto-generated test payload</li>
            <li>Click "Send Test Webhook" to simulate Zoho Forms calling our webhook</li>
          </ol>
        </AlertDescription>
      </Alert>

      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-base">Webhook Endpoint for Zoho Forms</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm font-semibold">Backend Function URL</Label>
            <div className="flex items-center gap-2 mt-1">
              <code className="flex-1 bg-white px-3 py-2 rounded border text-sm break-all">
                {window.location.origin}/api/functions/receiveSignedAgreement
              </code>
              <Button
                variant="outline"
                size="sm"
                onClick={copyFunctionUrl}
                className="gap-2 shrink-0"
              >
                <Copy className="w-3 h-3" />
                Copy
              </Button>
            </div>
            <p className="text-xs text-gray-600 mt-1">
              Use this URL as the webhook endpoint in your Zoho Forms configuration
            </p>
          </div>
          
          <div>
            <Label className="text-sm font-semibold">Method</Label>
            <Badge className="mt-1">POST</Badge>
          </div>

          <div className="border-t border-blue-300 pt-4">
            <Label className="text-sm font-semibold block mb-3">How to Test from Zoho Forms:</Label>
            <ol className="space-y-3 text-sm text-gray-700">
              <li className="flex gap-2">
                <span className="font-bold text-blue-600 shrink-0">1.</span>
                <div>
                  <strong>Add Hidden Fields to Your Signing Form:</strong>
                  <div className="mt-1 bg-white p-2 rounded border text-xs font-mono space-y-1">
                    <div>• <code>applicationUid</code> - Set from URL parameter or pre-filled</div>
                    <div>• <code>signatureFieldName</code> - Name of the signature field (e.g., "Email4")</div>
                    <div>• <code>signerEmail</code> - Email of the person signing</div>
                    <div>• <code>zohoSigningFormId</code> - The Zoho Form ID of the signing form</div>
                  </div>
                </div>
              </li>
              
              <li className="flex gap-2">
                <span className="font-bold text-blue-600 shrink-0">2.</span>
                <div>
                  <strong>Configure Zoho Forms Webhook:</strong>
                  <ul className="mt-1 ml-4 space-y-1">
                    <li>• Go to your Zoho Form settings</li>
                    <li>• Navigate to Integrations → Webhooks</li>
                    <li>• Click "Add Webhook"</li>
                    <li>• Paste the URL from above</li>
                    <li>• Set method to POST</li>
                    <li>• Select "On Form Submission"</li>
                  </ul>
                </div>
              </li>

              <li className="flex gap-2">
                <span className="font-bold text-blue-600 shrink-0">3.</span>
                <div>
                  <strong>Test the Form:</strong>
                  <p className="mt-1">Submit a test response through your Zoho Form. Check the function logs in your Base44 dashboard to see the webhook being received.</p>
                </div>
              </li>
            </ol>
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-sm">
              <strong>Important:</strong> The webhook will send all form fields in the payload. Make sure your hidden fields 
              (<code className="bg-blue-100 px-1 rounded">applicationUid</code>, <code className="bg-blue-100 px-1 rounded">signatureFieldName</code>, 
              <code className="bg-blue-100 px-1 rounded">signerEmail</code>, <code className="bg-blue-100 px-1 rounded">zohoSigningFormId</code>) 
              are correctly populated before submission.
            </AlertDescription>
          </Alert>

          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={copyExamplePayload}
              className="gap-2"
            >
              <Copy className="w-3 h-3" />
              Copy Example Payload
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Test Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="submission-select">Select Submission</Label>
              <Select value={selectedSubmissionId} onValueChange={setSelectedSubmissionId}>
                <SelectTrigger id="submission-select" className="mt-1">
                  <SelectValue placeholder="Choose a submission..." />
                </SelectTrigger>
                <SelectContent>
                  {submissions.map((sub) => (
                    <SelectItem key={sub.id} value={sub.id}>
                      {sub.applicant_name || sub.applicant_email || 'Unnamed'} - {sub.application_uid}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedSubmission && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 space-y-1 text-sm">
                <div><strong>Applicant:</strong> {selectedSubmission.applicant_name}</div>
                <div><strong>Email:</strong> {selectedSubmission.applicant_email}</div>
                <div className="font-mono text-xs">
                  <strong>App UID:</strong> {selectedSubmission.application_uid}
                </div>
                <div><strong>Form:</strong> {formConfig?.form_name}</div>
              </div>
            )}

            {selectedSubmission && signatureFields.length > 0 && (
              <div>
                <Label htmlFor="field-select">Select Signature Field</Label>
                <Select value={selectedSignatureField} onValueChange={setSelectedSignatureField}>
                  <SelectTrigger id="field-select" className="mt-1">
                    <SelectValue placeholder="Choose a signature field..." />
                  </SelectTrigger>
                  <SelectContent>
                    {signatureFields.map((field) => (
                      <SelectItem key={field.name} value={field.name}>
                        {field.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {selectedFieldInfo && signingFormConfig && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 space-y-1 text-sm">
                <div><strong>Signing Form:</strong> {signingFormConfig.form_name}</div>
                <div className="font-mono text-xs">
                  <strong>Zoho Form ID:</strong> {signingFormConfig.zoho_form_id}
                </div>
                <div><strong>Field:</strong> {selectedFieldInfo.label}</div>
                {selectedFieldInfo.parentSubform && (
                  <div><strong>Parent Subform:</strong> {selectedFieldInfo.parentSubform}</div>
                )}
              </div>
            )}

            {selectedSubmission && signatureFields.length === 0 && (
              <Alert className="bg-orange-50 border-orange-200">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <AlertDescription className="text-orange-800">
                  No signature email fields configured for this form
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Test Payload</CardTitle>
            <p className="text-sm text-gray-600">
              This is what Zoho Forms would send to our webhook
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="payload">JSON Payload</Label>
              <Textarea
                id="payload"
                value={testPayload}
                onChange={(e) => setTestPayload(e.target.value)}
                className="mt-1 font-mono text-xs h-64"
                placeholder='{\n  "applicationUid": "...",\n  "signatureFieldName": "...",\n  "signerEmail": "...",\n  ...\n}'
              />
              <p className="text-xs text-gray-500 mt-1">
                Modify this JSON to test different scenarios
              </p>
            </div>

            <Button
              onClick={handleTest}
              disabled={isTesting || !testPayload.trim()}
              className="w-full gap-2"
            >
              {isTesting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Sending Test...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Send Test Webhook
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {testResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {testResult.success ? (
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600" />
              )}
              Test Result
              <Badge className={testResult.success ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                {testResult.success ? "Success" : "Failed"}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {testResult.data && (
                <div>
                  <Label className="text-sm font-semibold">Response Data</Label>
                  <pre className="mt-1 bg-gray-50 border rounded-lg p-4 text-xs overflow-auto max-h-64">
                    {JSON.stringify(testResult.data, null, 2)}
                  </pre>
                </div>
              )}
              
              {testResult.error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Error:</strong> {testResult.error}
                  </AlertDescription>
                </Alert>
              )}

              {testResult.stack && (
                <details className="text-xs">
                  <summary className="cursor-pointer text-gray-600 hover:text-gray-900">
                    Show stack trace
                  </summary>
                  <pre className="mt-2 bg-gray-50 border rounded-lg p-2 overflow-auto">
                    {testResult.stack}
                  </pre>
                </details>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-base">Alternative: Test via Zoho Flow</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-gray-700">
            You can also test the webhook by configuring a Zoho Flow that calls this endpoint when your signing form is submitted.
          </p>
          
          <div className="bg-white p-3 rounded-lg border space-y-2 text-sm">
            <div><strong>Flow Setup:</strong></div>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Trigger: Zoho Forms - New Submission</li>
              <li>Action: Webhooks - Custom Request</li>
              <li>Method: POST</li>
              <li>URL: <code className="bg-gray-100 px-1 rounded">{window.location.origin}/api/functions/receiveSignedAgreement</code></li>
              <li>Body: Map your form fields to the required parameters</li>
            </ol>
          </div>

          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-sm">
              Using Zoho Flow gives you more control over the data transformation and allows you to add custom logic before calling the webhook.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}


import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Search, CheckCircle, AlertCircle, FileText, Download, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function TestCrmAttachments() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [orgName, setOrgName] = useState("");
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (!authed) {
        base44.auth.redirectToLogin(window.location.href);
      } else {
        setIsAuthenticated(true);
      }
    });
  }, []);

  if (isAuthenticated === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const handleTest = async () => {
    if (!orgName.trim()) {
      setResult({
        success: false,
        message: "Please enter an organization name"
      });
      return;
    }

    setTesting(true);
    setResult(null);

    try {
      const response = await base44.functions.invoke('testCrmLookup', {
        organizationName: orgName.trim()
      });

      setResult(response.data);
    } catch (error) {
      setResult({
        success: false,
        message: error.message,
        error: error.toString()
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Test CRM Attachments</h1>
        <p className="text-gray-500 mt-1">Test the Zoho CRM attachment retrieval by organization name</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Organization Lookup Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="org-name">Organization Name</Label>
            <div className="flex gap-2">
              <Input
                id="org-name"
                placeholder="Enter exact organization name as it appears in Zoho CRM"
                value={orgName}
                onChange={(e) => setOrgName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleTest();
                  }
                }}
              />
              <Button
                onClick={handleTest}
                disabled={testing || !orgName.trim()}
                className="gap-2"
              >
                {testing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Testing...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    Test Lookup
                  </>
                )}
              </Button>
            </div>
            <p className="text-xs text-gray-500">
              Enter the exact organization name as it appears in the "Name" field in Zoho CRM's isaasi_Organisations module
            </p>
          </div>

          {result && (
            <div className="space-y-4 mt-6">
              <Alert variant={result.success ? "default" : "destructive"} className={result.success ? "border-green-200 bg-green-50" : ""}>
                {result.success ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <AlertCircle className="h-4 w-4" />
                )}
                <AlertDescription className={result.success ? "text-green-800" : ""}>
                  {result.message}
                </AlertDescription>
              </Alert>

              {result.hint && (
                <Alert className="bg-blue-50 border-blue-200">
                  <AlertCircle className="h-4 w-4 text-blue-600" />
                  <AlertDescription className="text-blue-800">
                    <strong>Hint:</strong> {result.hint}
                  </AlertDescription>
                </Alert>
              )}

              {result.organizationName && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-900 mb-2">Organization Found</h3>
                  <div className="space-y-1 text-sm">
                    <div>
                      <span className="text-blue-700 font-medium">Name:</span>{" "}
                      <span className="text-blue-900">{result.organizationName}</span>
                    </div>
                    <div>
                      <span className="text-blue-700 font-medium">Record ID:</span>{" "}
                      <code className="bg-blue-100 px-2 py-0.5 rounded text-blue-900">{result.recordId}</code>
                    </div>
                  </div>
                </div>
              )}

              {result.attachments && result.attachments.length > 0 && (
                <Card>
                  <CardHeader className="bg-purple-50 border-b">
                    <CardTitle className="text-base flex items-center gap-2">
                      <FileText className="w-5 h-5 text-purple-600" />
                      Attachments Found ({result.attachments.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      {result.attachments.map((att) => (
                        <div
                          key={att.id}
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-purple-50 transition-colors"
                        >
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{att.fileName}</p>
                            <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                              <span>{att.size ? `${(att.size / 1024).toFixed(1)} KB` : 'Unknown size'}</span>
                              {att.createdTime && (
                                <>
                                  <span>•</span>
                                  <span>Created: {new Date(att.createdTime).toLocaleDateString()}</span>
                                </>
                              )}
                            </div>
                            {att.error && (
                              <p className="text-xs text-red-600 mt-1">Error: {att.error}</p>
                            )}
                          </div>
                          <div className="flex gap-1">
                            {att.signedUrl && (
                              <>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => window.open(att.signedUrl, '_blank')}
                                  className="gap-1"
                                  title="Open in new tab"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    const link = document.createElement('a');
                                    link.href = att.signedUrl;
                                    link.download = att.fileName;
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                  }}
                                  className="gap-1"
                                  title="Download"
                                >
                                  <Download className="w-3 h-3" />
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {result.attachments && result.attachments.length === 0 && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    No attachments found for this organization
                  </AlertDescription>
                </Alert>
              )}

              {result.error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <div className="font-semibold mb-1">Error Details:</div>
                    <pre className="text-xs bg-red-50 p-2 rounded overflow-auto max-h-40">
                      {result.error}
                    </pre>
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-base text-blue-900">Testing Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-blue-800">
          <div className="flex gap-2">
            <Badge className="bg-blue-600">1</Badge>
            <p>The organization name must match <strong>exactly</strong> as it appears in Zoho CRM's isaasi_Organisations module "Name" field</p>
          </div>
          <div className="flex gap-2">
            <Badge className="bg-blue-600">2</Badge>
            <p>The test uses the same Zoho API credentials configured in your environment secrets</p>
          </div>
          <div className="flex gap-2">
            <Badge className="bg-blue-600">3</Badge>
            <p>If successful, you'll see the organization record ID and all attachments with download links</p>
          </div>
          <div className="flex gap-2">
            <Badge className="bg-blue-600">4</Badge>
            <p>Common issues: incorrect organization name spelling, missing Zoho credentials, or API permissions</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  FileText, 
  RefreshCw, 
  Save, 
  Mail, 
  CheckCircle, 
  Webhook, 
  Upload, 
  Phone, 
  RotateCcw, 
  Calculator,
  FileCheck,
  FileX,
  PhoneOff,
  Activity,
  Clock
} from "lucide-react";
import { format } from "date-fns";

const eventConfig = {
  submission_received: {
    icon: FileText,
    label: "Submission Received",
    color: "bg-blue-100 text-blue-800 border-blue-300"
  },
  status_changed: {
    icon: RefreshCw,
    label: "Status Changed",
    color: "bg-purple-100 text-purple-800 border-purple-300"
  },
  submission_updated: {
    icon: Save,
    label: "Submission Updated",
    color: "bg-green-100 text-green-800 border-green-300"
  },
  signature_requested: {
    icon: Mail,
    label: "Signature Requested",
    color: "bg-amber-100 text-amber-800 border-amber-300"
  },
  signature_completed: {
    icon: CheckCircle,
    label: "Signature Completed",
    color: "bg-emerald-100 text-emerald-800 border-emerald-300"
  },
  webhook_triggered: {
    icon: Webhook,
    label: "Webhook Triggered",
    color: "bg-cyan-100 text-cyan-800 border-cyan-300"
  },
  logo_uploaded: {
    icon: Upload,
    label: "Logo Uploaded to CRM",
    color: "bg-indigo-100 text-indigo-800 border-indigo-300"
  },
  dd_call_booked: {
    icon: Phone,
    label: "DD Call Booked",
    color: "bg-teal-100 text-teal-800 border-teal-300"
  },
  dd_call_cleared: {
    icon: PhoneOff,
    label: "DD Call Cleared",
    color: "bg-gray-100 text-gray-800 border-gray-300"
  },
  submission_reset: {
    icon: RotateCcw,
    label: "Submission Reset",
    color: "bg-red-100 text-red-800 border-red-300"
  },
  score_calculated: {
    icon: Calculator,
    label: "Score Calculated",
    color: "bg-pink-100 text-pink-800 border-pink-300"
  },
  attachment_approved: {
    icon: FileCheck,
    label: "Attachment Approved",
    color: "bg-green-100 text-green-800 border-green-300"
  },
  attachment_rejected: {
    icon: FileX,
    label: "Attachment Rejected",
    color: "bg-orange-100 text-orange-800 border-orange-300"
  }
};

export default function SubmissionHistoryLog({ historyLog = [], sentWebhookMessages = [] }) {
  // Sort by timestamp descending (most recent first)
  const sortedLog = [...historyLog].sort((a, b) => 
    new Date(b.timestamp) - new Date(a.timestamp)
  );

  const renderEventDetails = (event) => {
    switch (event.event_type) {
      case 'submission_received':
        return (
          <div className="text-sm">
            <p className="text-gray-700">New submission received from {event.details?.applicant_name || 'Unknown'}</p>
            {event.details?.form_name && (
              <p className="text-gray-500 text-xs mt-1">Form: {event.details.form_name}</p>
            )}
          </div>
        );
      
      case 'status_changed':
        return (
          <div className="text-sm">
            <p className="text-gray-700">
              Status changed from <span className="font-semibold">{event.details?.old_status_label || event.details?.old_status || 'Unknown'}</span> to{' '}
              <span className="font-semibold">{event.details?.new_status_label || event.details?.new_status || 'Unknown'}</span>
            </p>
            {event.details?.workflows_triggered !== undefined && (
              <p className="text-gray-500 text-xs mt-1">
                Workflows: {event.details.workflows_triggered ? 'Triggered' : 'Not triggered'}
              </p>
            )}
          </div>
        );
      
      case 'submission_updated':
        return (
          <div className="text-sm">
            <p className="text-gray-700">Submission data updated</p>
            {event.details?.fields_updated && (
              <p className="text-gray-500 text-xs mt-1">
                {event.details.fields_updated} field(s) modified
              </p>
            )}
          </div>
        );
      
      case 'signature_requested':
        return (
          <div className="text-sm">
            <p className="text-gray-700">
              Signature request sent for <span className="font-semibold">{event.details?.field_label || event.details?.field_name || 'Unknown field'}</span>
            </p>
            {event.details?.signing_form_name && (
              <p className="text-gray-500 text-xs mt-1">Signing form: <span className="font-mono text-xs">{event.details.signing_form_name}</span></p>
            )}
            {event.details?.recipient_email && (
              <p className="text-gray-500 text-xs mt-1">To: {event.details.recipient_email}</p>
            )}
            {event.details?.resend_count > 0 && (
              <p className="text-amber-600 text-xs mt-1">Reminder #{event.details.resend_count}</p>
            )}
          </div>
        );
      
      case 'signature_completed':
        return (
          <div className="text-sm">
            <p className="text-gray-700">
              <span className="font-semibold">{event.details?.field_label || event.details?.field_name || 'Unknown field'}</span> signed
            </p>
            {event.details?.signing_form_name && (
              <p className="text-gray-500 text-xs mt-1">Signing form: <span className="font-mono text-xs">{event.details.signing_form_name}</span></p>
            )}
            {event.details?.signed_by && (
              <p className="text-gray-500 text-xs mt-1">Signed by: {event.details.signed_by}</p>
            )}
          </div>
        );
      
      case 'webhook_triggered':
        const webhookMessage = sentWebhookMessages.find(
          m => m.webhook_id === event.details?.webhook_id && 
               Math.abs(new Date(m.timestamp) - new Date(event.timestamp)) < 5000
        );

        return (
          <div className="text-sm">
            <p className="text-gray-700">
              Webhook <span className="font-semibold">{event.details?.webhook_name || 'Unknown'}</span> triggered
            </p>
            {event.details?.webhook_url && (
              <p className="text-gray-500 text-xs mt-1 font-mono break-all">{event.details.webhook_url}</p>
            )}
            {event.details?.is_reminder && (
              <p className="text-amber-600 text-xs mt-1">Reminder #{event.details.reminder_count}</p>
            )}
            {webhookMessage && (
              <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded">
                <p className="text-xs font-semibold text-blue-900 mb-1">Custom Message Sent:</p>
                <p className="text-xs text-blue-800 whitespace-pre-wrap">{webhookMessage.message}</p>
              </div>
            )}
          </div>
        );
      
      case 'logo_uploaded':
        return (
          <div className="text-sm">
            <p className="text-gray-700">Organization logo uploaded to CRM</p>
            {event.details?.crm_module && (
              <p className="text-gray-500 text-xs mt-1">Module: {event.details.crm_module}</p>
            )}
          </div>
        );
      
      case 'dd_call_booked':
        return (
          <div className="text-sm">
            <p className="text-gray-700">Due diligence call scheduled</p>
            {event.details?.call_date && (
              <p className="text-gray-500 text-xs mt-1">
                {format(new Date(event.details.call_date), 'MMM d, yyyy h:mm a')}
              </p>
            )}
          </div>
        );
      
      case 'dd_call_cleared':
        return (
          <div className="text-sm">
            <p className="text-gray-700">Due diligence call date cleared</p>
            {event.details?.previous_call_date && (
              <p className="text-gray-500 text-xs mt-1">
                Was: {format(new Date(event.details.previous_call_date), 'MMM d, yyyy h:mm a')}
              </p>
            )}
          </div>
        );
      
      case 'submission_reset':
        return (
          <div className="text-sm">
            <p className="text-gray-700 font-semibold">Submission reset to original state</p>
            <p className="text-red-600 text-xs mt-1">All review data cleared</p>
          </div>
        );
      
      case 'score_calculated':
        return (
          <div className="text-sm">
            <p className="text-gray-700">
              Due diligence score calculated: <span className="font-semibold">{event.details?.score}%</span>
            </p>
            {event.details?.risk_level && (
              <Badge className="mt-1 text-xs">
                {event.details.risk_level} risk
              </Badge>
            )}
          </div>
        );
      
      case 'attachment_approved':
      case 'attachment_rejected':
        return (
          <div className="text-sm">
            <p className="text-gray-700">
              Attachment <span className="font-semibold">{event.event_type === 'attachment_approved' ? 'approved' : 'rejected'}</span>
            </p>
            {event.details?.file_name && (
              <p className="text-gray-500 text-xs mt-1">{event.details.file_name}</p>
            )}
          </div>
        );
      
      default:
        return (
          <div className="text-sm">
            <p className="text-gray-700">{event.event_type}</p>
          </div>
        );
    }
  };

  if (sortedLog.length === 0) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center py-8 text-gray-500">
          <Activity className="w-12 h-12 mx-auto mb-3 text-gray-300" />
          <p>No history available yet</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-4 pb-3 border-b">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-slate-600" />
          <h3 className="text-lg font-semibold text-gray-900">Activity Timeline</h3>
        </div>
        <Badge variant="secondary">
          {sortedLog.length} events
        </Badge>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="pr-4 space-y-3">
          {sortedLog.map((event, index) => {
            const config = eventConfig[event.event_type] || {
              icon: Activity,
              label: event.event_type,
              color: "bg-gray-100 text-gray-800 border-gray-300"
            };
            const Icon = config.icon;

            return (
              <div
                key={index}
                className="flex gap-3 p-3 rounded-lg border bg-white hover:shadow-md transition-shadow"
              >
                <div className="flex-shrink-0">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${config.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <span className="font-semibold text-gray-900 text-sm">
                      {config.label}
                    </span>
                    <Badge variant="outline" className="flex items-center gap-1 text-xs whitespace-nowrap flex-shrink-0">
                      <Clock className="w-3 h-3" />
                      {format(new Date(event.timestamp), 'MMM d, h:mm a')}
                    </Badge>
                  </div>
                  {renderEventDetails(event)}
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline" className="text-xs">
                      {event.user_email === 'System' ? (
                        <span className="flex items-center gap-1">
                          <Activity className="w-3 h-3" />
                          System
                        </span>
                      ) : (
                        event.user_email
                      )}
                    </Badge>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}

import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Edit, Maximize2 } from "lucide-react";
import { cn } from "@/lib/utils";

function StaticQuestionReview({ item, response, onChange, questionNumber, note, onNoteChange }) {
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // If it's a header, just display it
  if (item.type === 'header') {
    return (
      <div 
        className="p-2 font-bold text-base -mx-4"
        style={{ 
          backgroundColor: item.backgroundColor || '#3b82f6', 
          color: item.textColor || '#ffffff' 
        }}
      >
        {item.title}
      </div>
    );
  }

  // Otherwise render the question as before
  const question = item;

  const options = [
    { 
      value: 'green', 
      gradient: 'bg-gradient-to-br from-green-400 to-green-600',
      points: question.green_points,
      label: 'Green'
    },
    { 
      value: 'amber', 
      gradient: 'bg-gradient-to-br from-amber-400 to-amber-600',
      points: question.amber_points,
      label: 'Amber'
    },
    { 
      value: 'red', 
      gradient: 'bg-gradient-to-br from-red-400 to-red-600',
      points: question.red_points,
      label: 'Red'
    },
    { 
      value: 'not_applicable', 
      gradient: 'bg-gradient-to-br from-blue-300 to-blue-500',
      points: 'N/A',
      label: 'N/A'
    },
  ];

  const renderTrafficLights = (expanded = false) => (
    <div className={cn("flex justify-center gap-3", expanded && "gap-6")}>
      {options.map((option) => (
        <button
          key={`${question.id}-${option.value}${expanded ? '-modal' : ''}`}
          type="button"
          onClick={() => onChange(question.id, option.value)}
          className={cn(
            "relative flex flex-col items-center gap-2 transition-all duration-200",
            response === option.value 
              ? "opacity-100 scale-110" 
              : "opacity-60 hover:opacity-80 hover:scale-105"
          )}
        >
          <div className={cn(
            "flex items-center justify-center rounded-full transition-all duration-200 shadow-md",
            option.gradient,
            expanded ? "w-16 h-16" : "w-8 h-8",
            response === option.value && "ring-2 ring-white ring-offset-2"
          )}>
            <span className={cn(
              "font-bold leading-none text-white drop-shadow-md flex items-center justify-center",
              expanded ? "text-lg" : "text-[10px]"
            )}>
              {option.points}
            </span>
          </div>
          {expanded && (
            <span className={cn(
              "text-sm font-semibold",
              response === option.value ? "text-gray-900" : "text-gray-600"
            )}>
              {option.label}
            </span>
          )}
        </button>
      ))}
    </div>
  );

  return (
    <>
      <Card className="bg-white/90 backdrop-blur-sm shadow-sm border border-gray-200">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-start gap-2">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-purple-600 text-white text-xs font-bold flex-shrink-0 mt-0.5">
              {questionNumber}
            </span>
            <Label className="text-sm font-semibold text-gray-900 leading-snug flex-1">
              {question.question}
            </Label>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 hover:bg-blue-100 flex-shrink-0"
              onClick={() => setIsModalOpen(true)}
            >
              <Maximize2 className="h-4 w-4 text-blue-600" />
            </Button>
          </div>

          <div className="pt-2">
            {renderTrafficLights(false)}
          </div>

          <div className="pt-2 border-t border-gray-300/50">
            <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
              <CollapsibleTrigger asChild>
                <button
                  className={cn(
                    "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                    note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  <Edit className="h-4 w-4" />
                  {note ? 'View/Edit Comment' : 'Add Comment'}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3">
                <Textarea
                  value={note || ''}
                  onChange={(e) => onNoteChange(question.id, e.target.value)}
                  placeholder="Add internal notes or comments about this question..."
                  rows={3}
                  className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
                />
              </CollapsibleContent>
            </Collapsible>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-xl">
              <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-purple-600 text-white text-sm font-bold">
                {questionNumber}
              </span>
              Due Diligence Question {questionNumber}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 mt-6">
            <div className="bg-gray-50 p-6 rounded-lg border-2 border-gray-200">
              <Label className="text-lg font-semibold text-gray-900 block mb-4">
                {question.question}
              </Label>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-bold text-gray-700">Select Response</Label>
              {renderTrafficLights(true)}
            </div>

            <div className="pt-4 border-t border-gray-200">
              <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
                <CollapsibleTrigger asChild>
                  <button
                    className={cn(
                      "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                      note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                    )}
                  >
                    <Edit className="h-4 w-4" />
                    {note ? 'View/Edit Comment' : 'Add Comment'}
                  </button>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-3">
                  <Textarea
                    value={note || ''}
                    onChange={(e) => onNoteChange(question.id, e.target.value)}
                    placeholder="Add internal notes or comments about this question..."
                    rows={4}
                    className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
                  />
                </CollapsibleContent>
              </Collapsible>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default React.memo(StaticQuestionReview);

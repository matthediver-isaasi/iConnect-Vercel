import React, { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { Check as CheckIcon, Maximize2, Edit, Circle, CheckCircle2, X, Plus, FileSignature, Clock, Mail, Eye } from "lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import MonthYearPicker from "../forms/MonthYearPicker";

// Helper function to convert Zoho's "Jan-2025" format to "2025-01" format
const convertZohoMonthToStandard = (zohoMonth) => {
  if (!zohoMonth || typeof zohoMonth !== 'string') return '';
  
  // Check if it's already in YYYY-MM format
  if (/^\d{4}-\d{2}$/.test(zohoMonth)) return zohoMonth;
  
  // Parse "Jan-2025" or "January-2025" format
  const match = zohoMonth.match(/^([A-Za-z]+)-(\d{4})$/);
  if (!match) return zohoMonth; // Return as-is if format doesn't match
  
  const [, monthStr, year] = match;
  const monthMap = {
    'jan': '01', 'january': '01',
    'feb': '02', 'february': '02',
    'mar': '03', 'march': '03',
    'apr': '04', 'april': '04',
    'may': '05',
    'jun': '06', 'june': '06',
    'jul': '07', 'july': '07',
    'aug': '08', 'august': '08',
    'sep': '09', 'september': '09',
    'oct': '10', 'october': '10',
    'nov': '11', 'november': '11',
    'dec': '12', 'december': '12'
  };
  
  const monthNum = monthMap[monthStr.toLowerCase()];
  if (!monthNum) return zohoMonth; // Return as-is if month not recognized
  
  return `${year}-${monthNum}`;
};

// Helper function to convert "2025-01" format back to "Jan-2025" format
const convertStandardToZohoMonth = (standardMonth) => {
  if (!standardMonth || typeof standardMonth !== 'string') return '';
  
  // Check if it's already in Zoho format
  if (/^[A-Za-z]+-\d{4}$/.test(standardMonth)) return standardMonth;
  
  // Parse "YYYY-MM" format
  const match = standardMonth.match(/^(\d{4})-(\d{2})$/);
  if (!match) return standardMonth; // Return as-is if format doesn't match
  
  const [, year, monthNum] = match;
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthIndex = parseInt(monthNum, 10) - 1;
  
  if (monthIndex < 0 || monthIndex > 11) return standardMonth;
  
  return `${monthNames[monthIndex]}-${year}`;
};

const ReadOnlyField = ({ field, formData }) => {
  if (field.type === 'name') {
    const firstName = formData[`${field.name}_First`];
    const lastName = formData[`${field.name}_Last`];
    return (
      <div className="space-y-1">
        <p className="text-sm text-gray-500">First Name: <span className="font-medium text-gray-800">{firstName || '-'}</span></p>
        <p className="text-sm text-gray-500">Last Name: <span className="font-medium text-gray-800">{lastName || '-'}</span></p>
      </div>
    );
  }

  if (field.type === 'address') {
    const address1 = formData[`${field.name}_address1`];
    const address2 = formData[`${field.name}_address2`];
    const city = formData[`${field.name}_city`];
    const zipCode = formData[`${field.name}_zipCode`];
    const country = formData[`${field.name}_country`];
    return (
      <div className="space-y-1">
        <p className="text-sm text-gray-500">Address Line 1: <span className="font-medium text-gray-800">{address1 || '-'}</span></p>
        {address2 && <p className="text-sm text-gray-500">Address Line 2: <span className="font-medium text-gray-800">{address2}</span></p>}
        <p className="text-sm text-gray-500">City: <span className="font-medium text-gray-800">{city || '-'}</span></p>
        <p className="text-sm text-gray-500">Postal/Zip Code: <span className="font-medium text-gray-800">{zipCode || '-'}</span></p>
        <p className="text-sm text-gray-500">Country: <span className="font-medium text-gray-800">{country || '-'}</span></p>
      </div>
    );
  }

  const value = formData[field.name];

  // Handle month fields directly to display the converted value
  if (field.type === 'month') {
    if (!value) return <span className="text-gray-500">- Not provided -</span>;
    const displayValue = convertZohoMonthToStandard(value);
    return <span className="font-medium text-gray-800">{String(displayValue)}</span>;
  }
  
  // Handle fields with options (dropdown, radio, checkbox groups)
  // Only show the selected options, not all available options
  if (field.options && field.options.length > 0) {
    // Determine if this is a multi-select checkbox group or a single-select field
    const isCheckboxGroup = field.type === 'checkbox' && field.options.length > 0;
    
    // Parse values: only split on comma for checkbox groups, treat as single value otherwise
    const selectedValues = value 
      ? (isCheckboxGroup 
          ? (typeof value === 'string' ? value.split(',').map(v => v.trim()) : (Array.isArray(value) ? value : [value]))
          : [value] // For dropdowns/radio, treat the entire value as one item
        )
      : [];
    
    // Filter to only show selected options
    const selectedOptions = field.options.filter(option => {
      const optionValue = option.value || option;
      return selectedValues.includes(optionValue);
    });
    
    if (selectedOptions.length === 0) {
      return <span className="text-gray-500">- Not provided -</span>;
    }
    
    return (
      <div className="space-y-2">
        {selectedOptions.map((option, idx) => {
          const optionLabel = option.label || option;
          
          return (
            <div key={idx} className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <span className="text-sm font-semibold text-gray-900">
                {optionLabel}
              </span>
            </div>
          );
        })}
      </div>
    );
  }
  
  // Handle single checkbox (no options)
  if (field.type === 'checkbox') {
    return (
      <span className="font-medium text-gray-800">
        {value === true || value === 'true' ? 'Checked' : 'Unchecked'}
      </span>
    );
  }

  if (value === null || value === undefined || value === '') return <span className="text-gray-500">- Not provided -</span>;
  return <span className="font-medium text-gray-800">{String(value)}</span>;
};

// New component to render signed form data in a user-friendly way
const SignedFormDataDisplay = ({ formData, formStructure }) => {
  if (!formStructure || !formStructure.fields) {
    return (
      <div className="bg-gray-50 border rounded-lg p-4">
        <p className="text-sm text-gray-500">Form structure not available</p>
      </div>
    );
  }

  const renderFieldValue = (field, data) => {
    if (field.type === 'name') {
      const firstName = data[`${field.name}_First`];
      const lastName = data[`${field.name}_Last`];
      return (
        <div className="space-y-1">
          <p className="text-sm"><span className="font-medium">First Name:</span> {firstName || '-'}</p>
          <p className="text-sm"><span className="font-medium">Last Name:</span> {lastName || '-'}</p>
        </div>
      );
    }

    if (field.type === 'address') {
      const address1 = data[`${field.name}_address1`];
      const address2 = data[`${field.name}_address2`];
      const city = data[`${field.name}_city`];
      const zipCode = data[`${field.name}_zipCode`];
      const country = data[`${field.name}_country`];
      return (
        <div className="space-y-1">
          <p className="text-sm"><span className="font-medium">Address Line 1:</span> {address1 || '-'}</p>
          {address2 && <p className="text-sm"><span className="font-medium">Address Line 2:</span> {address2}</p>}
          <p className="text-sm"><span className="font-medium">City:</span> {city || '-'}</p>
          <p className="text-sm"><span className="font-medium">Postal/Zip Code:</span> {zipCode || '-'}</p>
          <p className="text-sm"><span className="font-medium">Country:</span> {country || '-'}</p>
        </div>
      );
    }

    if (field.type === 'subform') {
      const subformData = data[field.name];
      if (!subformData || !Array.isArray(subformData) || subformData.length === 0) {
        return <span className="text-sm text-gray-500">- No entries -</span>;
      }
      
      const visibleSubfields = field.subfields?.filter(sf => sf.visible !== false) || [];
      
      return (
        <div className="space-y-2">
          {subformData.map((row, index) => (
            <div key={index} className="bg-gray-50 border border-gray-200 rounded-md p-3 space-y-1">
              <div className="font-semibold text-xs text-gray-700 mb-1">Entry #{index + 1}</div>
              {visibleSubfields.map((subfield) => (
                <p key={subfield.name} className="text-sm">
                  <span className="font-medium">{subfield.label}:</span> {row[subfield.name] || '-'}
                </p>
              ))}
            </div>
          ))}
        </div>
      );
    }

    const value = data[field.name];
    
    if (field.type === 'checkbox') {
      if (field.options && field.options.length > 0) {
        // Multiple checkboxes
        const selectedValues = value 
          ? (typeof value === 'string' ? value.split(',').map(v => v.trim()) : (Array.isArray(value) ? value : [value]))
          : [];
        
        if (selectedValues.length === 0) {
          return <span className="text-sm text-gray-500">- None selected -</span>;
        }
        
        return (
          <div className="space-y-1">
            {selectedValues.map((val, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium">{val}</span>
              </div>
            ))}
          </div>
        );
      } else {
        // Single checkbox
        return (
          <span className="text-sm font-medium">
            {value === true || value === 'true' ? 'Checked' : 'Unchecked'}
          </span>
        );
      }
    }

    if (value === null || value === undefined || value === '') {
      return <span className="text-sm text-gray-500">- Not provided -</span>;
    }

    if (field.type === 'month') {
      const displayValue = convertZohoMonthToStandard(value);
      return <span className="text-sm font-medium text-gray-800">{String(displayValue)}</span>;
    }
    
    return <span className="text-sm font-medium text-gray-800">{String(value)}</span>;
  };

  return (
    <div className="space-y-4">
      {formStructure.fields
        .filter(field => field.visible !== false)
        .map((field, index) => (
          <div key={field.name} className="bg-white border border-gray-200 rounded-lg p-4">
            <div className="flex items-start gap-3 mb-2">
              <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-green-600 text-white text-xs font-bold flex-shrink-0 mt-0.5">
                {index + 1}
              </span>
              <div className="flex-1">
                <Label className="text-sm font-semibold text-gray-900">
                  {field.label || field.name}
                </Label>
                {field.description && (
                  <p className="text-xs text-gray-500 italic mt-0.5">{field.description}</p>
                )}
              </div>
            </div>
            <div className="pl-9">
              {renderFieldValue(field, formData)}
            </div>
          </div>
        ))}
    </div>
  );
};

const ReadOnlySubform = ({ subformData, subfields }) => {
  if (!subformData || !Array.isArray(subformData) || subformData.length === 0) {
    return <span className="text-gray-500">- No entries provided -</span>;
  }

  // Filter to only visible subfields
  const visibleSubfields = subfields?.filter(sf => sf.visible !== false) || [];

  return (
    <div className="space-y-3">
      {subformData.map((row, index) => (
        <div key={index} className="bg-gray-50 border border-gray-200 rounded-lg p-3 space-y-2">
          <div className="font-semibold text-sm text-gray-700 mb-2">Entry #{index + 1}</div>
          <div className="space-y-1">
            {visibleSubfields.map((subfield) => {
              const val = row[subfield.name];

              return (
                <div key={subfield.name} className="text-sm">
                  <span className="text-gray-600">{subfield.label}:</span>{' '}
                  <span className="font-medium text-gray-900">
                    {val === null || val === undefined || val === '' ? '-' : String(val)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};

export default function ReviewFieldEditor({ 
  field, 
  originalFormData, 
  reviewedFormData, 
  reviewStatus, 
  onChange, 
  sequenceNumber, 
  note, 
  onNoteChange,
  signatureStatus,
  subformSignatureStatuses = {},
  onResendSignature,
  submissionId
}) {
  // For name and address fields, we need to track their sub-parts
  const getInitialValue = () => {
    if (field.type === 'name') {
      return {
        First: reviewedFormData[`${field.name}_First`] || '',
        Last: reviewedFormData[`${field.name}_Last`] || ''
      };
    }
    if (field.type === 'address') {
      return {
        address1: reviewedFormData[`${field.name}_address1`] || '',
        address2: reviewedFormData[`${field.name}_address2`] || '',
        city: reviewedFormData[`${field.name}_city`] || '',
        zipCode: reviewedFormData[`${field.name}_zipCode`] || '',
        country: reviewedFormData[`${field.name}_country`] || ''
      };
    }
    
    // For checkbox groups, parse comma-separated values into array
    if (field.type === 'checkbox' && field.options && field.options.length > 0) {
      const value = reviewedFormData[field.name];
      if (!value) return [];
      return typeof value === 'string' ? value.split(',').map(v => v.trim()) : (Array.isArray(value) ? value : [value]);
    }
    
    if (field.type === 'subform') {
      return reviewedFormData[field.name] || [];
    }

    // For month fields, convert Zoho format to standard format for display
    if (field.type === 'month') {
      const value = reviewedFormData[field.name];
      return convertZohoMonthToStandard(value);
    }

    return reviewedFormData[field.name];
  };

  const [currentEditedValue, setCurrentEditedValue] = useState(getInitialValue());
  const [isApproved, setIsApproved] = useState(field.is_internal ? false : reviewStatus === 'approved');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isNotesOpen, setIsNotesOpen] = useState(false);
  const [showSignedDataModal, setShowSignedDataModal] = useState(false);
  const [selectedSubformSignature, setSelectedSubformSignature] = useState(null);

  // Fetch signing form configuration when modal is opened
  const activeSignatureStatus = selectedSubformSignature || signatureStatus;
  const signingFormConfigId = activeSignatureStatus?.signing_form_config_id;
  
  const { data: signingFormConfig } = useQuery({
    queryKey: ['formConfig', signingFormConfigId],
    queryFn: async () => {
      if (!signingFormConfigId) return null;
      const configs = await base44.entities.FormConfiguration.filter({ id: signingFormConfigId });
      return configs[0] || null;
    },
    enabled: !!signingFormConfigId && showSignedDataModal,
  });

  useEffect(() => {
    setCurrentEditedValue(getInitialValue());
    // Internal fields should always remain in amend (editable) mode
    setIsApproved(field.is_internal ? false : reviewStatus === 'approved');
    
    // DEBUG: Log to understand what's happening with name fields
    console.log(`[ReviewFieldEditor] Field: ${field.name}, Type: ${field.type}, isInternal: ${field.is_internal}, reviewStatus prop: ${reviewStatus}, calculated isApproved: ${field.is_internal ? false : reviewStatus === 'approved'}`);
  }, [reviewedFormData, reviewStatus, field.name, field.is_internal]);

  const handleToggleApproval = (checked) => {
    setIsApproved(checked);
    if (checked) {
      if (field.type === 'name') {
        onChange(`${field.name}_First`, originalFormData[`${field.name}_First`], 'approved');
        onChange(`${field.name}_Last`, originalFormData[`${field.name}_Last`], 'approved');
        setCurrentEditedValue({
          First: originalFormData[`${field.name}_First`] || '',
          Last: originalFormData[`${field.name}_Last`] || ''
        });
      } else if (field.type === 'address') {
        onChange(`${field.name}_address1`, originalFormData[`${field.name}_address1`], 'approved');
        onChange(`${field.name}_address2`, originalFormData[`${field.name}_address2`], 'approved');
        onChange(`${field.name}_city`, originalFormData[`${field.name}_city`], 'approved');
        onChange(`${field.name}_zipCode`, originalFormData[`${field.name}_zipCode`], 'approved');
        onChange(`${field.name}_country`, originalFormData[`${field.name}_country`], 'approved');
        setCurrentEditedValue({
          address1: originalFormData[`${field.name}_address1`] || '',
          address2: originalFormData[`${field.name}_address2`] || '',
          city: originalFormData[`${field.name}_city`] || '',
          zipCode: originalFormData[`${field.name}_zipCode`] || '',
          country: originalFormData[`${field.name}_country`] || ''
        });
      } else if (field.type === 'subform') {
        onChange(field.name, originalFormData[field.name], 'approved');
        setCurrentEditedValue(originalFormData[field.name] || []);
      } else if (field.type === 'month') {
        // When approving, the original data is in Zoho format.
        // Set currentEditedValue (for display) to standard format.
        const convertedValue = convertZohoMonthToStandard(originalFormData[field.name]);
        setCurrentEditedValue(convertedValue);
        // Call onChange with the original Zoho format value to save.
        onChange(field.name, originalFormData[field.name], 'approved');
      } else {
        onChange(field.name, originalFormData[field.name], 'approved');
        setCurrentEditedValue(originalFormData[field.name]);
      }
    } else {
      if (field.type === 'name') {
        onChange(`${field.name}_First`, currentEditedValue.First, 'amended');
        onChange(`${field.name}_Last`, currentEditedValue.Last, 'amended');
      } else if (field.type === 'address') {
        onChange(`${field.name}_address1`, currentEditedValue.address1, 'amended');
        onChange(`${field.name}_address2`, currentEditedValue.address2, 'amended');
        onChange(`${field.name}_city`, currentEditedValue.city, 'amended');
        onChange(`${field.name}_zipCode`, currentEditedValue.zipCode, 'amended');
        onChange(`${field.name}_country`, currentEditedValue.country, 'amended');
      } else if (field.type === 'subform') {
        onChange(field.name, currentEditedValue, 'amended');
      } else if (field.type === 'month') {
        // Convert standard format back to Zoho format when saving
        const zohoValue = convertStandardToZohoMonth(currentEditedValue);
        onChange(field.name, zohoValue, 'amended');
      } else {
        // For checkbox groups, convert array back to comma-separated string
        const valueToSave = Array.isArray(currentEditedValue) ? currentEditedValue.join(',') : currentEditedValue;
        onChange(field.name, valueToSave, 'amended');
      }
    }
  };

  const handleEditedValueChange = (e) => {
    const newValue = e.target.value;
    setCurrentEditedValue(newValue);
    setIsApproved(false);
    onChange(field.name, newValue, 'amended');
  };

  const handleSelectChange = (newValue) => {
    setCurrentEditedValue(newValue);
    setIsApproved(false);
    onChange(field.name, newValue, 'amended');
  };

  const handleCheckboxChange = (checked) => {
    setCurrentEditedValue(checked);
    onChange(field.name, checked, 'amended');
    setIsApproved(false);
  };

  const handleCheckboxGroupChange = (optionValue, checked) => {
    const currentValues = Array.isArray(currentEditedValue) ? currentEditedValue : [];
    let newValues;
    
    if (checked) {
      newValues = [...currentValues, optionValue];
    } else {
      newValues = currentValues.filter(v => v !== optionValue);
    }
    
    setCurrentEditedValue(newValues);
    setIsApproved(false);
    // Save as comma-separated string
    onChange(field.name, newValues.join(','), 'amended');
  };

  const renderEditableInput = (expanded = false) => {
    if (field.type === 'name') {
      return (
        <div className="space-y-2">
          <div>
            <Label className="text-xs text-gray-500">First Name</Label>
            <Input
              type="text"
              value={currentEditedValue.First || ''}
              onChange={(e) => {
                const newName = { ...currentEditedValue, First: e.target.value };
                setCurrentEditedValue(newName);
                onChange(`${field.name}_First`, e.target.value, 'amended');
                setIsApproved(false);
              }}
              disabled={isApproved}
              placeholder="First Name"
              className={expanded ? "text-lg" : ""}
            />
          </div>
          <div>
            <Label className="text-xs text-gray-500">Last Name</Label>
            <Input
              type="text"
              value={currentEditedValue.Last || ''}
              onChange={(e) => {
                const newName = { ...currentEditedValue, Last: e.target.value };
                setCurrentEditedValue(newName);
                onChange(`${field.name}_Last`, e.target.value, 'amended');
                setIsApproved(false);
              }}
              disabled={isApproved}
              placeholder="Last Name"
              className={expanded ? "text-lg" : ""}
            />
          </div>
        </div>
      );
    }

    if (field.type === 'address') {
      return (
        <div className="space-y-2">
          <div>
            <Label className="text-xs text-gray-500">Address Line 1</Label>
            <Input
              type="text"
              value={currentEditedValue.address1 || ''}
              onChange={(e) => {
                const newAddress = { ...currentEditedValue, address1: e.target.value };
                setCurrentEditedValue(newAddress);
                onChange(`${field.name}_address1`, e.target.value, 'amended');
                setIsApproved(false);
              }}
              disabled={isApproved}
              placeholder="Address Line 1"
              className={expanded ? "text-lg" : ""}
            />
          </div>
          <div>
            <Label className="text-xs text-gray-500">Address Line 2</Label>
            <Input
              type="text"
              value={currentEditedValue.address2 || ''}
              onChange={(e) => {
                const newAddress = { ...currentEditedValue, address2: e.target.value };
                setCurrentEditedValue(newAddress);
                onChange(`${field.name}_address2`, e.target.value, 'amended');
                setIsApproved(false);
              }}
              disabled={isApproved}
              placeholder="Address Line 2"
              className={expanded ? "text-lg" : ""}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label className="text-xs text-gray-500">City</Label>
              <Input
                type="text"
                value={currentEditedValue.city || ''}
                onChange={(e) => {
                  const newAddress = { ...currentEditedValue, city: e.target.value };
                  setCurrentEditedValue(newAddress);
                  onChange(`${field.name}_city`, e.target.value, 'amended');
                  setIsApproved(false);
                }}
                disabled={isApproved}
                placeholder="City"
                className={expanded ? "text-lg" : ""}
              />
            </div>
            <div>
              <Label className="text-xs text-gray-500">Postal/Zip Code</Label>
              <Input
                type="text"
                value={currentEditedValue.zipCode || ''}
                onChange={(e) => {
                  const newAddress = { ...currentEditedValue, zipCode: e.target.value };
                  setCurrentEditedValue(newAddress);
                  onChange(`${field.name}_zipCode`, e.target.value, 'amended');
                  setIsApproved(false);
                }}
                disabled={isApproved}
                placeholder="Postal/Zip Code"
                className={expanded ? "text-lg" : ""}
            />
          </div>
          </div>
          <div>
            <Label className="text-xs text-gray-500">Country</Label>
            <Input
              type="text"
              value={currentEditedValue.country || ''}
              onChange={(e) => {
                const newAddress = { ...currentEditedValue, country: e.target.value };
                setCurrentEditedValue(newAddress);
                onChange(`${field.name}_country`, e.target.value, 'amended');
                setIsApproved(false);
              }}
              disabled={isApproved}
              placeholder="Country"
              className={expanded ? "text-lg" : ""}
            />
          </div>
        </div>
      );
    }
    
    if (field.type === 'subform') {
      const subformData = Array.isArray(currentEditedValue) ? currentEditedValue : [];
      
      // Filter to only visible subfields
      const visibleSubfields = field.subfields?.filter(sf => sf.visible !== false) || [];

      const addRow = () => {
        const newRow = {};
        visibleSubfields.forEach(subfield => {
          newRow[subfield.name] = '';
        });
        const updated = [...subformData, newRow];
        setCurrentEditedValue(updated);
        onChange(field.name, updated, 'amended');
        setIsApproved(false);
      };

      const removeRow = (rowIndex) => {
        const updated = subformData.filter((_, i) => i !== rowIndex);
        setCurrentEditedValue(updated);
        onChange(field.name, updated, 'amended');
        setIsApproved(false);
      };

      const updateSubfield = (rowIndex, subfieldName, value) => {
        const updated = [...subformData];
        updated[rowIndex] = {
          ...updated[rowIndex],
          [subfieldName]: value
        };
        setCurrentEditedValue(updated);
        onChange(field.name, updated, 'amended');
        setIsApproved(false);
      };

      return (
        <div className="space-y-3">
          {subformData.map((row, rowIndex) => (
            <div key={rowIndex} className={cn(
              "bg-white border-2 rounded-lg p-3 space-y-2 relative",
              isApproved ? "border-gray-200" : "border-purple-300"
            )}>
              <div className="absolute top-2 right-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeRow(rowIndex)}
                  disabled={isApproved}
                  className="h-7 w-7 text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              <div className="font-semibold text-sm text-purple-700 mb-2">
                Entry #{rowIndex + 1}
              </div>
              {visibleSubfields.map((subfield) => {
                const isSignatureField = subfield.type === 'email' && subfield.is_signature_email;
                // Create unique key for this subform entry's signature status
                const signatureStatusKey = `${subfield.name}_${rowIndex}`;
                const signatureStatus = isSignatureField ? subformSignatureStatuses[signatureStatusKey] : null;

                return (
                  <div key={subfield.name}>
                    <div className="flex items-center gap-2 mb-1">
                      <Label className={cn("text-xs text-gray-600", expanded && "text-sm")}>
                        {subfield.label}
                        {subfield.required && <span className="text-red-500 ml-1">*</span>}
                      </Label>
                      {signatureStatus && (
                        <Badge className={cn(
                          "text-xs",
                          signatureStatus.is_signed 
                            ? "bg-green-100 text-green-700" 
                            : "bg-amber-100 text-amber-700"
                        )}>
                          <FileSignature className="w-3 h-3 mr-1" />
                          {signatureStatus.is_signed ? 'Signed' : 'Awaiting Signature'}
                        </Badge>
                      )}
                    </div>
                    <Input
                      type={subfield.type === 'email' ? 'email' : 'text'}
                      value={row[subfield.name] || ''}
                      onChange={(e) => updateSubfield(rowIndex, subfield.name, e.target.value)}
                      placeholder={subfield.label}
                      disabled={isApproved}
                      className={expanded ? "text-base" : "text-sm"}
                    />
                    {signatureStatus && (
                      <div className={cn(
                        "mt-2 p-2 rounded-md text-xs",
                        signatureStatus.is_signed 
                          ? "bg-green-50 border border-green-200" 
                          : "bg-amber-50 border border-amber-200"
                      )}>
                        {signatureStatus.is_signed ? (
                          <div className="space-y-1">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3 text-green-600" />
                                <span className="font-semibold text-green-900">Signed</span>
                              </div>
                              {signatureStatus.signed_form_data && (
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => {
                                    setSelectedSubformSignature(signatureStatus);
                                    setShowSignedDataModal(true);
                                  }}
                                  className="h-5 px-2 gap-1 hover:bg-green-100"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span className="text-xs">View</span>
                                </Button>
                              )}
                            </div>
                            <div className="flex items-center gap-1 pl-4">
                              <Mail className="w-3 h-3 text-green-600" />
                              <span className="text-green-800">{signatureStatus.signed_by_email}</span>
                            </div>
                            <div className="flex items-center gap-1 pl-4">
                              <Clock className="w-3 h-3 text-green-600" />
                              <span className="text-green-800">
                                {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                                  day: '2-digit',
                                  month: 'short',
                                  year: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-amber-600" />
                              <span className="font-semibold text-amber-900">Pending signature</span>
                            </div>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => onResendSignature(subfield.name, field.name, rowIndex)}
                              className="h-5 px-2 gap-1 text-xs bg-white hover:bg-amber-50 text-amber-700 border-amber-300"
                            >
                              <Mail className="w-3 h-3" />
                              Resend
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
          
          <Button
            type="button"
            variant="outline"
            onClick={addRow}
            disabled={isApproved}
            className={cn(
              "w-full gap-2 border-2 border-dashed hover:bg-purple-50 text-purple-700",
              isApproved ? "border-gray-300 text-gray-400" : "border-purple-300 hover:border-purple-400"
            )}
          >
            <Plus className="w-4 h-4" />
            Add {field.label || 'Entry'}
          </Button>
        </div>
      );
    }
    
    switch (field.type) {
      case 'text':
      case 'email':
      case 'number':
      case 'decimal':
      case 'percent':
      case 'phone':
        const htmlInputType = field.htmlInputType || field.type;
        const isNumberType = htmlInputType === 'number' || field.type === 'number' || field.type === 'decimal' || field.type === 'percent';
        const isDecimal = field.type === 'decimal';
        const isPercent = field.type === 'percent';
        
        return (
          <Input
            type={isNumberType ? 'number' : (htmlInputType === 'email' ? 'email' : htmlInputType === 'tel' ? 'tel' : 'text')}
            step={isDecimal ? '0.01' : (isPercent ? '1' : undefined)}
            value={currentEditedValue || ''}
            onChange={handleEditedValueChange}
            disabled={isApproved}
            placeholder={field.placeholder || ''}
            className={expanded ? "text-lg" : ""}
          />
        );
      case 'textarea':
      case 'paragraph':
        return (
          <Textarea
            value={currentEditedValue || ''}
            onChange={handleEditedValueChange}
            disabled={isApproved}
            placeholder={field.placeholder || ''}
            rows={expanded ? 12 : 2}
            className={expanded ? "text-lg" : ""}
          />
        );
      case 'checkbox':
        // Check if this is a checkbox group (has options) or single checkbox
        if (field.options && field.options.length > 0) {
          const selectedValues = Array.isArray(currentEditedValue) ? currentEditedValue : [];
          const shouldScroll = field.options.length > 6;
          
          return (
            <div className={cn(
              "space-y-2",
              shouldScroll && "max-h-48 overflow-y-auto pr-2 border rounded-md p-2"
            )}>
              {field.options.map((option, idx) => {
                const optionValue = option.value || option;
                const optionLabel = option.label || option;
                const isChecked = selectedValues.includes(optionValue);
                
                return (
                  <div key={idx} className="flex items-center space-x-2">
                    <Checkbox
                      checked={isChecked}
                      onCheckedChange={(checked) => handleCheckboxGroupChange(optionValue, checked)}
                      disabled={isApproved}
                      id={`${field.name}-${idx}${expanded ? '-modal' : ''}`}
                    />
                    <Label 
                      htmlFor={`${field.name}-${idx}${expanded ? '-modal' : ''}`}
                      className={cn("font-normal cursor-pointer", expanded && "text-lg")}
                    >
                      {optionLabel}
                    </Label>
                  </div>
                );
              })}
            </div>
          );
        } else {
          // Single checkbox
          return (
            <div className="flex items-center space-x-2">
              <Checkbox
                checked={currentEditedValue === true || currentEditedValue === 'true'}
                onCheckedChange={handleCheckboxChange}
                disabled={isApproved}
              />
              <Label className={cn("font-normal cursor-pointer", expanded && "text-lg")}>{field.label}</Label>
            </div>
          );
        }
      case 'dropdown':
      case 'select':
        return (
          <Select 
            value={currentEditedValue || ''} 
            onValueChange={handleSelectChange}
            disabled={isApproved}
          >
            <SelectTrigger className={expanded ? "text-lg" : ""}>
              <SelectValue placeholder={field.placeholder || 'Select an option'} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, idx) => (
                <SelectItem key={idx} value={option.value || option}>
                  {option.label || option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'radio':
        return (
          <div className="space-y-2">
            {field.options?.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="radio"
                  id={`${field.name}-review-${idx}${expanded ? '-modal' : ''}`}
                  name={`${field.name}-review${expanded ? '-modal' : ''}`}
                  value={option.value || option}
                  checked={currentEditedValue === (option.value || option)}
                  onChange={handleEditedValueChange}
                  className="w-4 h-4"
                  disabled={isApproved}
                />
                <Label htmlFor={`${field.name}-review-${idx}${expanded ? '-modal' : ''}`} className={cn("font-normal cursor-pointer", expanded && "text-lg")}>
                  {option.label || option}
                </Label>
              </div>
            ))}
          </div>
        );
      case 'date':
        const dateInputType = field.htmlInputType || 'date';
        
        // Use native date/datetime inputs for other date types
        return (
          <Input
            type={dateInputType === 'datetime-local' ? 'datetime-local' : 'date'}
            value={currentEditedValue || ''}
            onChange={handleEditedValueChange}
            disabled={isApproved}
            className={expanded ? "text-lg" : ""}
          />
        );
      case 'month':
        // Handle MonthYear picker - value is already in standard format from getInitialValue
        return (
          <MonthYearPicker
            value={currentEditedValue || ''}
            onChange={(newValue) => {
              setCurrentEditedValue(newValue);
              // Convert standard format back to Zoho format when saving
              const zohoValue = convertStandardToZohoMonth(newValue);
              onChange(field.name, zohoValue, 'amended');
              setIsApproved(false);
            }}
            disabled={isApproved}
            className={expanded ? "text-lg" : ""}
          />
        );
      default:
        return (
          <Input
            value={currentEditedValue || ''}
            onChange={handleEditedValueChange}
            disabled={isApproved}
            placeholder={field.placeholder || ''}
            className={expanded ? "text-lg" : ""}
          />
        );
    }
  };

  // If field is marked as internal, render simplified editable view
  if (field.is_internal) {
    return (
      <>
        <div className="col-span-2 bg-gradient-to-r from-blue-50 to-slate-50 border-2 border-l-4 border-blue-400 rounded-xl p-4 space-y-3">
          <div className="flex items-start gap-2">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex-shrink-0 mt-0.5">
              {sequenceNumber}
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Label className="text-sm font-bold text-gray-800">{field.label || field.name}</Label>
                <Badge className="bg-blue-100 text-blue-700 text-xs">Internal Field</Badge>
                {signatureStatus && (
                  <Badge className={cn(
                    "text-xs",
                    signatureStatus.is_signed 
                      ? "bg-green-100 text-green-700" 
                      : "bg-amber-100 text-amber-700"
                  )}>
                    <FileSignature className="w-3 h-3 mr-1" />
                    {signatureStatus.is_signed ? 'Signed' : 'Awaiting Signature'}
                  </Badge>
                )}
              </div>
              {field.description && (
                <p className="text-xs text-gray-500 italic">{field.description}</p>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 hover:bg-blue-100 flex-shrink-0"
              onClick={() => setIsModalOpen(true)}
            >
              <Maximize2 className="h-4 w-4 text-blue-600" />
            </Button>
          </div>
          
          <div className="bg-white p-3 rounded-lg border-2 border-blue-400 shadow-sm">
            {renderEditableInput(false)}
          </div>

          {signatureStatus && (
            <div className={cn(
              "p-3 rounded-lg border-2",
              signatureStatus.is_signed 
                ? "bg-green-50 border-green-300" 
                : "bg-amber-50 border-amber-300"
            )}>
              {signatureStatus.is_signed ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      <p className="text-sm font-bold text-green-900">Agreement Signed</p>
                    </div>
                    {signatureStatus.signed_form_data && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedSubformSignature(null); // Clear subform signature
                          setShowSignedDataModal(true);
                        }}
                        className="gap-2 h-7 text-xs bg-white hover:bg-green-50"
                      >
                        <Eye className="w-3 h-3" />
                        View Form Data
                      </Button>
                    )}
                  </div>
                  <div className="flex items-center gap-2 pl-6">
                    <Mail className="w-3 h-3 text-green-600" />
                    <p className="text-xs text-green-800">
                      Signed by: <span className="font-semibold">{signatureStatus.signed_by_email}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pl-6">
                    <Clock className="w-3 h-3 text-green-600" />
                    <p className="text-xs text-green-800">
                      {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <p className="text-sm font-bold text-amber-900">Digital signature pending for this agreement</p>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => onResendSignature(field.name)}
                    className="h-7 px-3 gap-1 text-xs bg-white hover:bg-amber-50 text-amber-700 border-amber-300"
                  >
                    <Mail className="w-3 h-3" />
                    Resend
                  </Button>
                </div>
              )}
            </div>
          )}

          <div className="pt-2 border-t border-gray-300/50">
            <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
              <CollapsibleTrigger asChild>
                <button
                  className={cn(
                    "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                    note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  <Edit className="h-4 w-4" />
                  {note ? 'View/Edit Comment' : 'Add Comment'}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3">
                <Textarea
                  value={note}
                  onChange={(e) => onNoteChange(field.name, e.target.value)}
                  placeholder="Add internal notes or comments about this field..."
                  rows={3}
                  className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
                />
              </CollapsibleContent>
            </Collapsible>
          </div>
        </div>

        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3 text-xl">
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white text-sm font-bold">
                  {sequenceNumber}
                </span>
                {field.label || field.name}
                <Badge className="bg-blue-100 text-blue-700">Internal Field</Badge>
              </DialogTitle>
              {field.description && (
                <p className="text-sm text-gray-500 italic mt-2">{field.description}</p>
              )}
            </DialogHeader>
            
            <div className="space-y-6 mt-6">
              <div className="space-y-3">
                <Label className="text-base font-bold text-gray-700">Internal Field Data</Label>
                <div className="bg-white p-4 rounded-lg border-2 border-blue-400 shadow-sm">
                  {renderEditableInput(true)}
                </div>
              </div>

              {signatureStatus && (
                <div className={cn(
                  "p-4 rounded-lg border-2",
                  signatureStatus.is_signed 
                    ? "bg-green-50 border-green-300" 
                    : "bg-amber-50 border-amber-300"
                )}>
                  {signatureStatus.is_signed ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                          <p className="text-base font-bold text-green-900">Agreement Signed</p>
                        </div>
                        {signatureStatus.signed_form_data && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedSubformSignature(null); // Clear subform signature
                              setShowSignedDataModal(true);
                            }}
                            className="gap-2 h-8 text-xs bg-white hover:bg-green-50"
                          >
                            <Eye className="w-3 h-3" />
                            View Form Data
                          </Button>
                        )}
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Mail className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          Signed by: <span className="font-semibold">{signatureStatus.signed_by_email}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Clock className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-amber-600" />
                      <p className="text-base font-bold text-amber-900">Digital signature pending for this agreement</p>
                    </div>
                  )}
                </div>
              )}

              <div className="pt-4 border-t border-gray-200">
                <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
                  <CollapsibleTrigger asChild>
                    <button
                      className={cn(
                        "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                        note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                      )}
                    >
                      <Edit className="h-4 w-4" />
                      {note ? 'View/Edit Comment' : 'Add Comment'}
                    </button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="pt-3">
                    <Textarea
                      value={note}
                      onChange={(e) => onNoteChange(field.name, e.target.value)}
                      placeholder="Add internal notes or comments about this field..."
                      rows={4}
                      className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
                    />
                  </CollapsibleContent>
                </Collapsible>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={showSignedDataModal} onOpenChange={setShowSignedDataModal}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileSignature className="w-5 h-5 text-green-600" />
                Signed Agreement Form Response
              </DialogTitle>
            </DialogHeader>
            <div className="flex-1 overflow-y-auto mt-4">
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="font-semibold text-green-900">Signed by:</span>{' '}
                      <span className="text-green-800">{activeSignatureStatus?.signed_by_email}</span>
                    </div>
                    <div>
                      <span className="font-semibold text-green-900">Signed on:</span>{' '}
                      <span className="text-green-800">
                        {activeSignatureStatus?.signed_date && new Date(activeSignatureStatus.signed_date).toLocaleString('en-GB', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-semibold text-gray-700 mb-3 block">
                    Form Response
                  </Label>
                  {signingFormConfig && signingFormConfig.form_structure ? (
                    <SignedFormDataDisplay 
                      formData={activeSignatureStatus?.signed_form_data || {} }
                      formStructure={signingFormConfig.form_structure}
                    />
                  ) : signingFormConfigId && !signingFormConfig ? (
                    <div className="bg-gray-50 border rounded-lg p-8 text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-3"></div>
                      <p className="text-sm text-gray-600">Loading form structure...</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                        <p className="text-sm text-amber-800">
                          <strong>Note:</strong> Form structure not available. Showing raw data below.
                        </p>
                      </div>
                      <pre className="bg-gray-50 border rounded-lg p-4 text-xs overflow-auto max-h-[400px] font-mono">
                        {JSON.stringify(activeSignatureStatus?.signed_form_data, null, 2)}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <>
      <div className={cn(
        "col-span-2 py-4 px-3 rounded-xl transition-all duration-300 space-y-4",
        isApproved ? "bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 shadow-md" : "bg-gradient-to-r from-gray-50 to-slate-50 border-2 border-gray-200",
        reviewStatus === 'amended' && !isApproved ? "border-l-4 border-l-orange-400 shadow-lg" : ""
      )}>
        {/* Field Header - spans both columns */}
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-2 flex-1">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex-shrink-0 mt-0.5">
              {sequenceNumber}
            </span>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <Label className="text-sm font-bold text-gray-800">{field.label || field.name}</Label>
                {signatureStatus && (
                  <Badge className={cn(
                    "text-xs",
                    signatureStatus.is_signed 
                      ? "bg-green-100 text-green-700" 
                      : "bg-amber-100 text-amber-700"
                  )}>
                    <FileSignature className="w-3 h-3 mr-1" />
                    {signatureStatus.is_signed ? 'Signed' : 'Awaiting Signature'}
                  </Badge>
                )}
              </div>
              {field.description && (
                <p className="text-xs text-gray-500 italic mt-1">{field.description}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center space-x-2">
              <span className={cn(
                "text-xs font-semibold transition-colors",
                !isApproved ? "text-orange-600" : "text-gray-400"
              )}>
                Amend
              </span>
              <Switch
                id={`approve-${field.name}`}
                checked={isApproved}
                onCheckedChange={handleToggleApproval}
                className="data-[state=checked]:bg-green-600"
              />
              <span className={cn(
                "text-xs font-semibold transition-colors",
                isApproved ? "text-green-600" : "text-gray-400"
              )}>
                Approve
              </span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 hover:bg-blue-100"
              onClick={() => setIsModalOpen(true)}
            >
              <Maximize2 className="h-4 w-4 text-blue-600" />
            </Button>
          </div>
        </div>

        {/* Signature Status - spans both columns */}
        {signatureStatus && (
          <div className={cn(
            "p-3 rounded-lg border-2",
            signatureStatus.is_signed 
              ? "bg-green-50 border-green-300" 
              : "bg-amber-50 border-amber-300"
          )}>
            {signatureStatus.is_signed ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <p className="text-sm font-bold text-green-900">Agreement Signed</p>
                  </div>
                  {signatureStatus.signed_form_data && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedSubformSignature(null); // Clear subform signature
                        setShowSignedDataModal(true);
                      }}
                      className="gap-2 h-7 text-xs bg-white hover:bg-green-50"
                    >
                      <Eye className="w-3 h-3" />
                      View Form Data
                    </Button>
                  )}
                </div>
                <div className="flex items-center gap-2 pl-6">
                  <Mail className="w-3 h-3 text-green-600" />
                  <p className="text-xs text-green-800">
                    Signed by: <span className="font-semibold">{signatureStatus.signed_by_email}</span>
                  </p>
                </div>
                <div className="flex items-center gap-2 pl-6">
                  <Clock className="w-3 h-3 text-green-600" />
                  <p className="text-xs text-green-800">
                    {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                  </p>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <p className="text-sm font-bold text-amber-900">Digital signature pending for this agreement</p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => onResendSignature(field.name)}
                  className="h-7 px-3 gap-1 text-xs bg-white hover:bg-amber-50 text-amber-700 border-amber-300"
                >
                  <Mail className="w-3 h-3" />
                  Resend
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Two-column data layout */}
        <div className="grid grid-cols-2 gap-6">
          <div className="flex flex-col space-y-2">
            <div className="bg-white p-3 rounded-lg border-2 border-gray-200 text-sm shadow-sm">
              {field.type === 'subform' ? (
                <ReadOnlySubform 
                  subformData={originalFormData[field.name]} 
                  subfields={field.subfields}
                />
              ) : (
                <ReadOnlyField field={field} formData={originalFormData} />
              )}
            </div>
          </div>

          <div className="flex flex-col space-y-2">
            <div className={cn(
              "bg-white p-3 rounded-lg border-2 transition-all duration-200 shadow-sm",
              !isApproved ? "border-blue-400 shadow-md" : "border-gray-200"
            )}>
              {renderEditableInput(false)}
            </div>
          </div>
        </div>

        {/* Notes section - spans both columns */}
        <div className="pt-2 border-t border-gray-300/50">
          <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
            <CollapsibleTrigger asChild>
              <button
                className={cn(
                  "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                  note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                )}
              >
                <Edit className="h-4 w-4" />
                {note ? 'View/Edit Comment' : 'Add Comment'}
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="pt-3">
              <Textarea
                value={note}
                onChange={(e) => onNoteChange(field.name, e.target.value)}
                placeholder="Add internal notes or comments about this field..."
                rows={3}
                disabled={isApproved}
                className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
              />
            </CollapsibleContent>
          </Collapsible>
        </div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-xl">
              <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-600 text-white text-sm font-bold">
                {sequenceNumber}
              </span>
              {field.label || field.name}
            </DialogTitle>
            {field.description && (
              <p className="text-sm text-gray-500 italic mt-2">{field.description}</p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-2 gap-6 mt-6">
            <div className="space-y-3">
              <Label className="text-base font-bold text-gray-700">Original Submission</Label>
              <div className="bg-gray-50 p-4 rounded-lg border-2 border-gray-200 min-h-[100px]">
                {field.type === 'subform' ? (
                  <ReadOnlySubform 
                    subformData={originalFormData[field.name]} 
                    subfields={field.subfields}
                  />
                ) : (
                  <ReadOnlyField field={field} formData={originalFormData} />
                )}
              </div>
              {signatureStatus && (
                <div className={cn(
                  "p-4 rounded-lg border-2",
                  signatureStatus.is_signed 
                    ? "bg-green-50 border-green-300" 
                    : "bg-amber-50 border-amber-300"
                )}>
                  {signatureStatus.is_signed ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                          <p className="text-base font-bold text-green-900">Agreement Signed</p>
                        </div>
                        {signatureStatus.signed_form_data && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedSubformSignature(null); // Clear subform signature
                              setShowSignedDataModal(true);
                            }}
                            className="gap-2 h-8 text-xs bg-white hover:bg-green-50"
                          >
                            <Eye className="w-3 h-3" />
                            View Form Data
                          </Button>
                        )}
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Mail className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          Signed by: <span className="font-semibold">{signatureStatus.signed_by_email}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Clock className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-amber-600" />
                      <p className="text-base font-bold text-amber-900">Digital signature pending for this agreement</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-base font-bold text-gray-700">Reviewer's Amendment</Label>
                <div className="flex items-center space-x-2">
                  <span className={cn(
                    "text-sm font-semibold transition-colors",
                    !isApproved ? "text-orange-600" : "text-gray-400"
                  )}>
                    Amend
                  </span>
                  <Switch
                    id={`approve-${field.name}-modal`}
                    checked={isApproved}
                    onCheckedChange={handleToggleApproval}
                    className="data-[state=checked]:bg-green-600"
                  />
                  <span className={cn(
                    "text-sm font-semibold transition-colors",
                    isApproved ? "text-green-600" : "text-gray-400"
                  )}>
                    Approve
                  </span>
                </div>
              </div>
              <div className={cn(
                "bg-white p-4 rounded-lg border-2 transition-all duration-200",
                !isApproved ? "border-blue-400 shadow-md" : "border-gray-200"
              )}>
                {renderEditableInput(true)}
              </div>
              {signatureStatus && (
                <div className={cn(
                  "p-4 rounded-lg border-2",
                  signatureStatus.is_signed 
                    ? "bg-green-50 border-green-300" 
                    : "bg-amber-50 border-amber-300"
                )}>
                  {signatureStatus.is_signed ? (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-5 h-5 text-green-600" />
                          <p className="text-base font-bold text-green-900">Agreement Signed</p>
                        </div>
                        {signatureStatus.signed_form_data && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedSubformSignature(null); // Clear subform signature
                              setShowSignedDataModal(true);
                            }}
                            className="gap-2 h-8 text-xs bg-white hover:bg-green-50"
                          >
                            <Eye className="w-3 h-3" />
                            View Form Data
                          </Button>
                        )}
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Mail className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          Signed by: <span className="font-semibold">{signatureStatus.signed_by_email}</span>
                        </p>
                      </div>
                      <div className="flex items-center gap-2 pl-7">
                        <Clock className="w-4 h-4 text-green-600" />
                        <p className="text-sm text-green-800">
                          {new Date(signatureStatus.signed_date).toLocaleString('en-GB', {
                            day: '2-digit',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Clock className="w-5 h-5 text-amber-600" />
                        <p className="text-base font-bold text-amber-900">Digital signature pending for this agreement</p>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => onResendSignature(field.name)}
                        className="h-8 px-3 gap-1 text-sm bg-white hover:bg-amber-50 text-amber-700 border-amber-300"
                      >
                        <Mail className="w-4 h-4" />
                        Resend
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-gray-200">
            <Collapsible open={isNotesOpen} onOpenChange={setIsNotesOpen}>
              <CollapsibleTrigger asChild>
                <button
                  className={cn(
                    "flex items-center gap-2 text-sm font-semibold transition-all hover:underline",
                    note ? "text-blue-700" : "text-gray-600 hover:text-gray-900"
                  )}
                >
                  <Edit className="h-4 w-4" />
                  {note ? 'View/Edit Comment' : 'Add Comment'}
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-3">
                <Textarea
                  value={note}
                  onChange={(e) => onNoteChange(field.name, e.target.value)}
                  placeholder="Add internal notes or comments about this field..."
                  rows={4}
                  disabled={isApproved}
                  className="text-sm bg-yellow-50 border-yellow-300 focus:border-yellow-500 focus:ring-yellow-500"
                />
              </CollapsibleContent>
            </Collapsible>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showSignedDataModal} onOpenChange={setShowSignedDataModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSignature className="w-5 h-5 text-green-600" />
              Signed Agreement Form Response
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto mt-4">
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="font-semibold text-green-900">Signed by:</span>{' '}
                    <span className="text-green-800">{activeSignatureStatus?.signed_by_email}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-green-900">Signed on:</span>{' '}
                    <span className="text-green-800">
                      {activeSignatureStatus?.signed_date && new Date(activeSignatureStatus.signed_date).toLocaleString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>
              </div>
              
              <div>
                <Label className="text-sm font-semibold text-gray-700 mb-3 block">
                  Form Response
                </Label>
                {signingFormConfig && signingFormConfig.form_structure ? (
                  <SignedFormDataDisplay 
                    formData={activeSignatureStatus?.signed_form_data || {} }
                    formStructure={signingFormConfig.form_structure}
                  />
                ) : signingFormConfigId && !signingFormConfig ? (
                  <div className="bg-gray-50 border rounded-lg p-8 text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-3"></div>
                    <p className="text-sm text-gray-600">Loading form structure...</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                      <p className="text-sm text-amber-800">
                        <strong>Note:</strong> Form structure not available. Showing raw data below.
                      </p>
                    </div>
                    <pre className="bg-gray-50 border rounded-lg p-4 text-xs overflow-auto max-h-[400px] font-mono">
                      {JSON.stringify(activeSignatureStatus?.signed_form_data, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
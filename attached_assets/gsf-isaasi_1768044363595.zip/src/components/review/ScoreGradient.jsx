
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

function ScoreGradient({ score, riskLevel, customRiskLevels }) {
  const defaultRiskLevels = [
    { name: "Low Risk", threshold: 0, color: "#22c55e" },
    { name: "Medium Risk", threshold: 20, color: "#f59e0b" },
    { name: "High Risk", threshold: 50, color: "#f97316" },
    { name: "Critical Risk", threshold: 80, color: "#ef4444" }
  ];

  const riskLevels = customRiskLevels && customRiskLevels.length > 0 
    ? customRiskLevels 
    : defaultRiskLevels;

  // Sort by threshold ascending (0% to 100%)
  const sortedLevels = [...riskLevels].sort((a, b) => a.threshold - b.threshold);

  const getCurrentRiskLevel = () => {
    // Work backwards from highest threshold to find the current level
    for (let i = sortedLevels.length - 1; i >= 0; i--) {
      if (score >= sortedLevels[i].threshold) {
        return sortedLevels[i];
      }
    }
    // Fallback to lowest threshold level
    return sortedLevels[0];
  };

  const currentLevel = getCurrentRiskLevel();

  return (
    <div className="space-y-4">
      <div className="text-center">
        <div className="text-5xl font-bold text-white mb-2">
          {score !== null && score !== undefined ? `${score}%` : '--'}
        </div>
        {currentLevel && (
          <Badge 
            className="text-sm px-4 py-1.5"
            style={{ 
              backgroundColor: currentLevel.color,
              color: 'white',
              border: 'none'
            }}
          >
            {currentLevel.name.toUpperCase()}
          </Badge>
        )}
      </div>

      <div className="relative h-12 rounded-lg overflow-hidden shadow-inner border-2 border-white/20">
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(to right, ${sortedLevels.map(l => l.color).join(', ')})`
          }}
        />
        
        {score !== null && score !== undefined && (
          <div
            className="absolute top-0 bottom-0 flex items-center justify-center transition-all duration-500 ease-out"
            style={{ left: `${score}%` }}
          >
            <div className="relative">
              <div className="w-1 h-12 bg-white shadow-lg"></div>
              <div 
                className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white text-gray-900 px-3 py-1.5 rounded-lg shadow-xl font-bold text-sm whitespace-nowrap"
              >
                {score}%
              </div>
              <div 
                className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-white"
              ></div>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between text-xs text-blue-100 font-semibold">
        <span>0% (Best)</span>
        <span>Risk Score</span>
        <span>100% (Worst)</span>
      </div>
    </div>
  );
}

export default React.memo(ScoreGradient);

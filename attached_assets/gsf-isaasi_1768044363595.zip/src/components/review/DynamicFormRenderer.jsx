import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function DynamicFormRenderer({ formStructure, formData, onChange }) {
  if (!formStructure || !formStructure.fields) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No form structure available</p>
        <p className="text-sm mt-2">This form needs to be synced from Zoho Forms</p>
      </div>
    );
  }

  const renderField = (field) => {
    const value = formData[field.name] || '';

    switch (field.type) {
      case 'text':
      case 'email':
      case 'number':
      case 'phone':
        return (
          <Input
            type={field.type === 'number' ? 'number' : 'text'}
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
            placeholder={field.placeholder}
          />
        );

      case 'textarea':
      case 'paragraph':
        return (
          <Textarea
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
            placeholder={field.placeholder}
            rows={4}
          />
        );

      case 'checkbox':
        return (
          <div className="flex items-center space-x-2">
            <Checkbox
              checked={value === true || value === 'true'}
              onCheckedChange={(checked) => onChange(field.name, checked)}
            />
            <Label>{field.label}</Label>
          </div>
        );

      case 'dropdown':
      case 'select':
        return (
          <Select value={value} onValueChange={(val) => onChange(field.name, val)}>
            <SelectTrigger>
              <SelectValue placeholder={field.placeholder || 'Select an option'} />
            </SelectTrigger>
            <SelectContent>
              {field.options?.map((option, idx) => (
                <SelectItem key={idx} value={option.value || option}>
                  {option.label || option}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        );

      case 'radio':
        return (
          <div className="space-y-2">
            {field.options?.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="radio"
                  id={`${field.name}-${idx}`}
                  name={field.name}
                  value={option.value || option}
                  checked={value === (option.value || option)}
                  onChange={(e) => onChange(field.name, e.target.value)}
                  className="w-4 h-4"
                />
                <Label htmlFor={`${field.name}-${idx}`}>{option.label || option}</Label>
              </div>
            ))}
          </div>
        );

      case 'date':
        return (
          <Input
            type="date"
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
          />
        );

      default:
        return (
          <Input
            value={value}
            onChange={(e) => onChange(field.name, e.target.value)}
            placeholder={field.placeholder}
          />
        );
    }
  };

  return (
    <div className="space-y-6">
      {formStructure.fields.map((field, index) => (
        <div key={index} className="space-y-2">
          <Label className="text-sm font-medium">
            {field.label || field.name}
            {field.required && <span className="text-red-500 ml-1">*</span>}
          </Label>
          {field.description && (
            <p className="text-sm text-gray-500">{field.description}</p>
          )}
          {renderField(field)}
        </div>
      ))}
    </div>
  );
}
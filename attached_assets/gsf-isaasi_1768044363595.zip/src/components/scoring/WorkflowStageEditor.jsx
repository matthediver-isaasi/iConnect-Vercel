import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { X, Plus, GripVertical, Star, Clock, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown } from "lucide-react";

function WorkflowStageEditor({ stages, onChange }) {
  const handleAddStage = () => {
    const newStage = {
      id: `stage_${Date.now()}`,
      label: "New Stage",
      color: "#6b7280",
      is_initial: false,
      include_in_housekeeping: true,
      order: stages.length,
      selection_conditions: {
        require_all_signatures: false,
        require_all_attachments_approved: false,
        require_logo_designated: false,
        min_score_threshold: null,
        max_score_threshold: null
      },
      _internalId: `internal_${Date.now()}_${Math.random()}` // Stable internal ID for React keys
    };
    const updated = [...stages, newStage];
    onChange(updated);
  };

  const handleRemoveStage = (index) => {
    const updated = stages.filter((_, i) => i !== index);
    // Recalculate order
    const reordered = updated.map((stage, i) => ({ ...stage, order: i }));
    onChange(reordered);
  };

  const handleStageChange = (index, field, value) => {
    const updated = [...stages];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const handleConditionChange = (index, conditionField, value) => {
    const updated = [...stages];
    const currentConditions = updated[index].selection_conditions || {};
    updated[index] = {
      ...updated[index],
      selection_conditions: {
        ...currentConditions,
        [conditionField]: value
      }
    };
    onChange(updated);
  };

  const handleSetInitial = (index) => {
    const updated = stages.map((stage, i) => ({
      ...stage,
      is_initial: i === index
    }));
    onChange(updated);
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(stages);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    // Update order property
    const reordered = items.map((item, index) => ({
      ...item,
      order: index
    }));

    onChange(reordered);
  };

  return (
    <div className="space-y-4">
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="stages">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="space-y-3"
            >
              {stages.map((stage, index) => {
                // Use internal ID for stable key, or generate one if missing
                const stableKey = stage._internalId || `stage_${index}_${stage.id}`;
                const conditions = stage.selection_conditions || {};
                const hasConditions = conditions.require_all_signatures || 
                                     conditions.require_all_attachments_approved || 
                                     conditions.require_logo_designated ||
                                     conditions.min_score_threshold !== null ||
                                     conditions.max_score_threshold !== null;
                
                return (
                  <Draggable key={stableKey} draggableId={stableKey} index={index}>
                    {(provided, snapshot) => (
                      <Card
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={cn(
                          "border-2 transition-shadow",
                          snapshot.isDragging && "shadow-lg",
                          stage.is_initial && "border-blue-400 bg-blue-50"
                        )}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start gap-3">
                            <div
                              {...provided.dragHandleProps}
                              className="mt-2 cursor-grab active:cursor-grabbing"
                            >
                              <GripVertical className="w-5 h-5 text-gray-400" />
                            </div>

                            <div className="flex-1 space-y-4">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                <div>
                                  <Label className="text-xs font-semibold mb-1">Stage ID</Label>
                                  <Input
                                    value={stage.id}
                                    onChange={(e) => handleStageChange(index, 'id', e.target.value)}
                                    placeholder="stage_id"
                                    className="text-sm"
                                  />
                                </div>

                                <div>
                                  <Label className="text-xs font-semibold mb-1">Display Label</Label>
                                  <Input
                                    value={stage.label}
                                    onChange={(e) => handleStageChange(index, 'label', e.target.value)}
                                    placeholder="Stage Name"
                                    className="text-sm"
                                  />
                                </div>

                                <div>
                                  <Label className="text-xs font-semibold mb-1">Color</Label>
                                  <div className="flex gap-2">
                                    <Input
                                      type="color"
                                      value={stage.color}
                                      onChange={(e) => handleStageChange(index, 'color', e.target.value)}
                                      className="w-16 h-9 p-1 cursor-pointer"
                                    />
                                    <Input
                                      type="text"
                                      value={stage.color}
                                      onChange={(e) => handleStageChange(index, 'color', e.target.value)}
                                      placeholder="#000000"
                                      className="flex-1 text-sm font-mono"
                                    />
                                  </div>
                                </div>
                              </div>

                              <div className="space-y-3 pt-3 border-t">
                                <div className="flex items-center gap-2">
                                  <span className="text-xs text-gray-500">Preview:</span>
                                  <Badge
                                    style={{
                                      backgroundColor: stage.color,
                                      color: '#ffffff',
                                      border: 'none'
                                    }}
                                  >
                                    {stage.label}
                                  </Badge>
                                  {stage.is_initial && (
                                    <Badge variant="outline" className="text-xs border-blue-300 text-blue-700">
                                      Default for new submissions
                                    </Badge>
                                  )}
                                  {hasConditions && (
                                    <Badge variant="outline" className="text-xs border-purple-300 text-purple-700">
                                      <ShieldCheck className="w-3 h-3 mr-1" />
                                      Has Conditions
                                    </Badge>
                                  )}
                                </div>

                                <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2.5 border border-gray-200">
                                  <div className="flex items-center gap-2">
                                    <Clock className="w-4 h-4 text-purple-600" />
                                    <div>
                                      <Label className="text-xs font-semibold text-gray-900">
                                        Include in Housekeeping
                                      </Label>
                                      <p className="text-xs text-gray-500">
                                        Process reminders for this stage
                                      </p>
                                    </div>
                                  </div>
                                  <Switch
                                    checked={stage.include_in_housekeeping !== false}
                                    onCheckedChange={(checked) => handleStageChange(index, 'include_in_housekeeping', checked)}
                                    className="data-[state=checked]:bg-purple-600"
                                  />
                                </div>
                              </div>

                              {/* Selection Conditions */}
                              <Collapsible>
                                <div className="bg-purple-50 border border-purple-200 rounded-lg">
                                  <CollapsibleTrigger asChild>
                                    <button className="w-full flex items-center justify-between p-3 hover:bg-purple-100 transition-colors rounded-lg">
                                      <div className="flex items-center gap-2">
                                        <ShieldCheck className="w-4 h-4 text-purple-600" />
                                        <Label className="text-sm font-semibold text-purple-900 cursor-pointer">
                                          Selection Conditions
                                        </Label>
                                        <span className="text-xs text-purple-600">
                                          ({hasConditions ? 'Configured' : 'None'})
                                        </span>
                                      </div>
                                      <ChevronDown className="w-4 h-4 text-purple-600 transition-transform group-data-[state=open]:rotate-180" />
                                    </button>
                                  </CollapsibleTrigger>
                                  <CollapsibleContent>
                                    <div className="p-3 pt-0 space-y-3">
                                      <p className="text-xs text-purple-800">
                                        Define requirements that must be met before reviewers can select this stage
                                      </p>

                                      <div className="space-y-2">
                                        <div className="flex items-center justify-between bg-white rounded-lg p-2.5 border border-purple-200">
                                          <div>
                                            <Label className="text-xs font-semibold text-gray-900">
                                              Require All Signatures
                                            </Label>
                                            <p className="text-xs text-gray-500">
                                              All signature agreements must be signed
                                            </p>
                                          </div>
                                          <Switch
                                            checked={conditions.require_all_signatures || false}
                                            onCheckedChange={(checked) => handleConditionChange(index, 'require_all_signatures', checked)}
                                            className="data-[state=checked]:bg-purple-600"
                                          />
                                        </div>

                                        <div className="flex items-center justify-between bg-white rounded-lg p-2.5 border border-purple-200">
                                          <div>
                                            <Label className="text-xs font-semibold text-gray-900">
                                              Require All Documents Approved
                                            </Label>
                                            <p className="text-xs text-gray-500">
                                              All CRM attachments must be approved
                                            </p>
                                          </div>
                                          <Switch
                                            checked={conditions.require_all_attachments_approved || false}
                                            onCheckedChange={(checked) => handleConditionChange(index, 'require_all_attachments_approved', checked)}
                                            className="data-[state=checked]:bg-purple-600"
                                          />
                                        </div>

                                        <div className="flex items-center justify-between bg-white rounded-lg p-2.5 border border-purple-200">
                                          <div>
                                            <Label className="text-xs font-semibold text-gray-900">
                                              Require Logo Designated
                                            </Label>
                                            <p className="text-xs text-gray-500">
                                              An organization logo must be selected
                                            </p>
                                          </div>
                                          <Switch
                                            checked={conditions.require_logo_designated || false}
                                            onCheckedChange={(checked) => handleConditionChange(index, 'require_logo_designated', checked)}
                                            className="data-[state=checked]:bg-purple-600"
                                          />
                                        </div>

                                        <div className="bg-white rounded-lg p-2.5 border border-purple-200 space-y-2">
                                          <Label className="text-xs font-semibold text-gray-900">
                                            Score Thresholds
                                          </Label>
                                          <div className="grid grid-cols-2 gap-2">
                                            <div>
                                              <Label className="text-xs text-gray-600">Min Score (%)</Label>
                                              <Input
                                                type="number"
                                                min="0"
                                                max="100"
                                                value={conditions.min_score_threshold ?? ''}
                                                onChange={(e) => handleConditionChange(
                                                  index, 
                                                  'min_score_threshold', 
                                                  e.target.value === '' ? null : parseInt(e.target.value)
                                                )}
                                                placeholder="No min"
                                                className="text-xs h-8"
                                              />
                                            </div>
                                            <div>
                                              <Label className="text-xs text-gray-600">Max Score (%)</Label>
                                              <Input
                                                type="number"
                                                min="0"
                                                max="100"
                                                value={conditions.max_score_threshold ?? ''}
                                                onChange={(e) => handleConditionChange(
                                                  index, 
                                                  'max_score_threshold', 
                                                  e.target.value === '' ? null : parseInt(e.target.value)
                                                )}
                                                placeholder="No max"
                                                className="text-xs h-8"
                                              />
                                            </div>
                                          </div>
                                          <p className="text-xs text-gray-500">
                                            Leave blank for no score requirement
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  </CollapsibleContent>
                                </div>
                              </Collapsible>
                            </div>

                            <div className="flex flex-col gap-2 items-end">
                              <Button
                                type="button"
                                variant={stage.is_initial ? "default" : "outline"}
                                size="sm"
                                onClick={() => handleSetInitial(index)}
                                className={cn(
                                  "gap-1 h-8",
                                  stage.is_initial && "bg-blue-600 hover:bg-blue-700"
                                )}
                                title="Set as initial stage for new submissions"
                              >
                                <Star className={cn("w-3 h-3", stage.is_initial && "fill-white")} />
                                {stage.is_initial ? "Initial" : "Set Initial"}
                              </Button>

                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveStage(index)}
                                className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                disabled={stages.length === 1}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <Button
        type="button"
        variant="outline"
        onClick={handleAddStage}
        className="w-full border-2 border-dashed hover:bg-blue-50 text-blue-700"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Workflow Stage
      </Button>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
        <p className="font-semibold mb-1">💡 Tips:</p>
        <ul className="list-disc list-inside space-y-1 text-xs">
          <li>Drag stages to reorder them</li>
          <li>Stage ID must be unique and will be used in the database</li>
          <li>One stage must be marked as "Initial" for new submissions</li>
          <li>Toggle "Include in Housekeeping" to control which stages are processed for automated reminders</li>
          <li><strong>Selection Conditions:</strong> Define requirements that must be met before this stage can be selected during review</li>
          <li>Colors are shown as hex codes (e.g., #3b82f6)</li>
        </ul>
      </div>
    </div>
  );
}

export default React.memo(WorkflowStageEditor);

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { toast } from "sonner";

const defaultColors = [
  { name: "Red", value: "#ef4444" },
  { name: "Orange", value: "#f97316" },
  { name: "Amber", value: "#f59e0b" },
  { name: "Yellow", value: "#eab308" },
  { name: "Lime", value: "#84cc16" },
  { name: "Green", value: "#22c55e" },
  { name: "Emerald", value: "#10b981" },
  { name: "Teal", value: "#14b8a6" },
  { name: "Cyan", value: "#06b6d4" },
  { name: "Sky", value: "#0ea5e9" },
  { name: "Blue", value: "#3b82f6" },
  { name: "Indigo", value: "#6366f1" },
  { name: "Violet", value: "#8b5cf6" },
  { name: "Purple", value: "#a855f7" },
  { name: "Fuchsia", value: "#d946ef" },
  { name: "Pink", value: "#ec4899" },
  { name: "Rose", value: "#f43f5e" },
  { name: "Slate", value: "#64748b" },
  { name: "Gray", value: "#6b7280" },
];

function RiskLevelEditor({ riskLevels, onChange }) {
  const [showColorPicker, setShowColorPicker] = useState(null);

  const addRiskLevel = () => {
    const newLevel = {
      name: "New Level",
      threshold: 50,
      color: "#3b82f6"
    };
    onChange([...riskLevels, newLevel]);
  };

  const removeRiskLevel = (index) => {
    if (riskLevels.length <= 2) {
      toast.error("You must have at least 2 risk levels");
      return;
    }
    onChange(riskLevels.filter((_, i) => i !== index));
  };

  const updateRiskLevel = (index, field, value) => {
    const updated = [...riskLevels];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  // Sort levels by threshold ascending for display (0% to 100%)
  const sortedLevels = [...riskLevels].sort((a, b) => a.threshold - b.threshold);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-lg">Risk Levels</h3>
          <p className="text-sm text-gray-600">Define custom risk thresholds with names and colors</p>
        </div>
        <Button onClick={addRiskLevel} size="sm" className="gap-2">
          <Plus className="w-4 h-4" />
          Add Level
        </Button>
      </div>

      <div className="space-y-3">
        {sortedLevels.map((level, displayIndex) => {
          // Find the original index to update the correct item in the parent state
          const actualIndex = riskLevels.findIndex(l => 
            l.name === level.name && l.threshold === level.threshold && l.color === level.color
          );
          
          return (
            <Card key={actualIndex} className="bg-gray-50">
              <CardContent className="pt-4">
                <div className="flex gap-4 items-start">
                  <div className="flex-1 grid grid-cols-3 gap-4">
                    <div>
                      <Label className="text-sm">Risk Level Name</Label>
                      <Input
                        value={level.name}
                        onChange={(e) => updateRiskLevel(actualIndex, 'name', e.target.value)}
                        placeholder="e.g., Critical Risk"
                      />
                    </div>
                    <div>
                      <Label className="text-sm">Threshold (% or above)</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={level.threshold}
                        onChange={(e) => updateRiskLevel(actualIndex, 'threshold', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="relative">
                      <Label className="text-sm">Color</Label>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setShowColorPicker(showColorPicker === actualIndex ? null : actualIndex)}
                          className="w-full h-10 rounded-md border-2 border-gray-300 hover:border-gray-400 transition-colors"
                          style={{ backgroundColor: level.color }}
                        />
                        <Input
                          type="text"
                          value={level.color}
                          onChange={(e) => updateRiskLevel(actualIndex, 'color', e.target.value)}
                          className="w-24"
                          placeholder="#000000"
                        />
                      </div>
                      {showColorPicker === actualIndex && (
                        <div className="absolute z-10 mt-2 p-3 bg-white border-2 border-gray-200 rounded-lg shadow-xl">
                          <div className="grid grid-cols-6 gap-2 mb-2">
                            {defaultColors.map((color) => (
                              <button
                                key={color.value}
                                onClick={() => {
                                  updateRiskLevel(actualIndex, 'color', color.value);
                                  setShowColorPicker(null);
                                }}
                                className="w-8 h-8 rounded-md border-2 border-gray-300 hover:scale-110 transition-transform"
                                style={{ backgroundColor: color.value }}
                                title={color.name}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeRiskLevel(actualIndex)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50 mt-6"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Visual Gradient Scale */}
      <Card className="bg-white">
        <CardContent className="pt-6">
          <Label className="text-sm font-semibold mb-3 block">Risk Scale Preview</Label>
          <div className="relative h-16 rounded-lg overflow-hidden shadow-inner border-2 border-gray-200">
            <div
              className="absolute inset-0"
              style={{
                background: `linear-gradient(to right, ${sortedLevels.map(l => l.color).join(', ')})`
              }}
            />
            {sortedLevels.map((level, index) => (
              <div
                key={index}
                className="absolute top-0 bottom-0 flex flex-col justify-center"
                style={{ left: `${level.threshold}%` }}
              >
                <div className="w-0.5 h-full bg-white/80 relative">
                  <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded shadow-md text-xs font-semibold whitespace-nowrap">
                    {level.name}
                  </div>
                  <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-white px-1.5 py-0.5 rounded shadow text-xs font-bold">
                    {level.threshold}%
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-8 text-xs text-gray-500 font-semibold">
            <span>0% (Best)</span>
            <span>Risk Score</span>
            <span>100% (Worst)</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default React.memo(RiskLevelEditor);

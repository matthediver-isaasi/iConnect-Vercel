import React, { createContext, useContext, useState, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertTriangle } from 'lucide-react';

const NavigationGuardContext = createContext();

export function NavigationGuardProvider({ children }) {
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(null);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const attemptNavigation = useCallback((path) => {
    if (hasUnsavedChanges && location.pathname !== path) {
      // Store the pending navigation and show dialog
      setPendingNavigation(path);
      setShowConfirmDialog(true);
      return false;
    } else {
      navigate(path);
      return true;
    }
  }, [hasUnsavedChanges, navigate, location.pathname]);

  const confirmNavigation = useCallback(() => {
    setHasUnsavedChanges(false);
    setShowConfirmDialog(false);
    if (pendingNavigation) {
      navigate(pendingNavigation);
      setPendingNavigation(null);
    }
  }, [navigate, pendingNavigation]);

  const cancelNavigation = useCallback(() => {
    setShowConfirmDialog(false);
    setPendingNavigation(null);
  }, []);

  const value = React.useMemo(() => ({
    hasUnsavedChanges,
    setHasUnsavedChanges,
    attemptNavigation
  }), [hasUnsavedChanges, attemptNavigation]);

  return (
    <NavigationGuardContext.Provider value={value}>
      {children}
      
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent className="max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-orange-700">
              <AlertTriangle className="w-5 h-5" />
              Unsaved Changes
            </AlertDialogTitle>
            <AlertDialogDescription className="text-base pt-2">
              You have unsaved changes that will be lost if you leave this page. Are you sure you want to continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelNavigation}>
              Stay on Page
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmNavigation}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Leave Page
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </NavigationGuardContext.Provider>
  );
}

export function useNavigationGuard() {
  const context = useContext(NavigationGuardContext);
  if (!context) {
    throw new Error('useNavigationGuard must be used within NavigationGuardProvider');
  }
  return context;
}
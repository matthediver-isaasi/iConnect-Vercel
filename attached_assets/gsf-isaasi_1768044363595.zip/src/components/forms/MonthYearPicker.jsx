import React, { useState, useEffect } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const MONTHS = [
  { value: "01", label: "January" },
  { value: "02", label: "February" },
  { value: "03", label: "March" },
  { value: "04", label: "April" },
  { value: "05", label: "May" },
  { value: "06", label: "June" },
  { value: "07", label: "July" },
  { value: "08", label: "August" },
  { value: "09", label: "September" },
  { value: "10", label: "October" },
  { value: "11", label: "November" },
  { value: "12", label: "December" },
];

export default function MonthYearPicker({ 
  value, 
  onChange, 
  disabled = false, 
  required = false,
  placeholder = "Select Month/Year",
  className 
}) {
  // Parse YYYY-MM format
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");

  // Generate years (current year - 100 to current year + 10)
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 111 }, (_, i) => currentYear - 100 + i).reverse();

  // Parse value on mount or when value changes
  useEffect(() => {
    if (value && typeof value === 'string' && value.includes('-')) {
      const [y, m] = value.split('-');
      setYear(y);
      setMonth(m);
    } else {
      setMonth("");
      setYear("");
    }
  }, [value]);

  const handleMonthChange = (newMonth) => {
    setMonth(newMonth);
    if (year && newMonth) {
      onChange(`${year}-${newMonth}`);
    }
  };

  const handleYearChange = (newYear) => {
    setYear(newYear);
    if (month && newYear) {
      onChange(`${newYear}-${month}`);
    }
  };

  return (
    <div className={cn("flex gap-2", className)}>
      <div className="flex-1">
        <Select 
          value={month} 
          onValueChange={handleMonthChange}
          disabled={disabled}
          required={required}
        >
          <SelectTrigger className={cn(className)}>
            <SelectValue placeholder="Month" />
          </SelectTrigger>
          <SelectContent>
            {MONTHS.map((m) => (
              <SelectItem key={m.value} value={m.value}>
                {m.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1">
        <Select 
          value={year} 
          onValueChange={handleYearChange}
          disabled={disabled}
          required={required}
        >
          <SelectTrigger className={cn(className)}>
            <SelectValue placeholder="Year" />
          </SelectTrigger>
          <SelectContent className="max-h-[300px]">
            {years.map((y) => (
              <SelectItem key={y} value={y.toString()}>
                {y}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
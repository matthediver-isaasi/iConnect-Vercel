
import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, Plus, Trash2 } from "lucide-react";
import MonthYearPicker from "./MonthYearPicker";

export default function DynamicFormInput({ formStructure, formData, onChange, validationErrors = {} }) {
  if (!formStructure || !formStructure.fields) {
    return (
      <div className="text-center py-8 text-gray-500">
        <p>No form structure available</p>
        <p className="text-sm mt-2">This form needs to be synced from Zoho Forms</p>
      </div>
    );
  }

  const renderSubform = (field, index) => {
    const subformData = formData[field.name] || [];
    const hasError = validationErrors[field.name];

    const addRow = () => {
      const newRow = {};
      field.subfields.forEach(subfield => {
        newRow[subfield.name] = '';
      });
      onChange(field.name, [...subformData, newRow]);
    };

    const removeRow = (rowIndex) => {
      const updated = subformData.filter((_, i) => i !== rowIndex);
      onChange(field.name, updated);
    };

    const updateSubfield = (rowIndex, subfieldName, value) => {
      const updated = [...subformData];
      updated[rowIndex] = {
        ...updated[rowIndex],
        [subfieldName]: value
      };
      onChange(field.name, updated);
    };

    return (
      <Card 
        key={field.name} 
        className={`transition-all duration-200 bg-gradient-to-br from-white to-purple-50/30 ${
          hasError ? 'border-red-300 bg-red-50/50' : 'hover:shadow-md border-gray-200'
        }`}
      >
        <CardContent className="p-6">
          <div className="space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1">
                <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-purple-600 text-white text-sm font-bold flex-shrink-0 mt-0.5">
                  {index + 1}
                </span>
                <div className="flex-1">
                  <Label className="text-base font-semibold text-gray-900 flex items-center gap-1">
                    {field.label || field.name}
                    {field.required && <span className="text-red-500">*</span>}
                  </Label>
                  {field.description && (
                    <p className="text-sm text-gray-500 mt-1">{field.description}</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="pl-10 space-y-4">
              {subformData.map((row, rowIndex) => (
                <div key={rowIndex} className="bg-white border-2 border-purple-200 rounded-lg p-4 space-y-3 relative">
                  <div className="absolute top-2 right-2">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeRow(rowIndex)}
                      className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="font-semibold text-sm text-purple-700 mb-2">
                    Entry #{rowIndex + 1}
                  </div>
                  {field.subfields.map((subfield) => {
                    const inputType = subfield.htmlInputType || subfield.type;
                    const isNumberType = inputType === 'number' || subfield.type === 'number' || subfield.type === 'decimal';
                    const isDecimal = subfield.type === 'decimal';
                    
                    return (
                      <div key={subfield.name}>
                        <Label className="text-sm text-gray-700 mb-1 block">
                          {subfield.label}
                          {subfield.required && <span className="text-red-500 ml-1">*</span>}
                        </Label>
                        <Input
                          type={isNumberType ? 'number' : (inputType === 'email' ? 'email' : inputType === 'tel' ? 'tel' : 'text')}
                          step={isDecimal ? '0.01' : undefined}
                          value={row[subfield.name] || ''}
                          onChange={(e) => updateSubfield(rowIndex, subfield.name, e.target.value)}
                          placeholder={subfield.label}
                          required={subfield.required}
                        />
                      </div>
                    );
                  })}
                </div>
              ))}
              
              <Button
                type="button"
                variant="outline"
                onClick={addRow}
                className="w-full gap-2 border-2 border-dashed border-purple-300 hover:bg-purple-50 hover:border-purple-400 text-purple-700"
              >
                <Plus className="w-4 h-4" />
                Add {field.label || 'Entry'}
              </Button>
              
              {hasError && (
                <p className="text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {hasError}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  const renderField = (field) => {
    const value = formData[field.name] || '';
    const isRequired = field.required;
    const hasError = validationErrors[field.name];
    
    // Determine the HTML input type to use
    const htmlInputType = field.htmlInputType || field.type;
    const isNumberType = htmlInputType === 'number' || field.type === 'number' || field.type === 'decimal' || field.type === 'percent';
    const isDecimal = field.type === 'decimal' || field.type === 'currency';

    switch (field.type) {
      case 'text':
      case 'email':
      case 'number':
      case 'decimal':
      case 'percent':
      case 'phone':
        return (
          <div id={`field-${field.name}`}>
            <Input
              type={isNumberType ? 'number' : (htmlInputType === 'email' ? 'email' : htmlInputType === 'tel' ? 'tel' : 'text')}
              step={isDecimal ? '0.01' : (field.type === 'percent' ? '1' : undefined)}
              value={value}
              onChange={(e) => onChange(field.name, e.target.value)}
              placeholder={field.placeholder || ''}
              required={isRequired}
              className={hasError ? 'border-red-500 focus:border-red-500' : ''}
            />
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'name':
        return (
          <div id={`field-${field.name}`} className="space-y-3">
            <div>
              <Label className="text-sm text-gray-600 mb-1 block">First Name {isRequired && <span className="text-red-500">*</span>}</Label>
              <Input
                type="text"
                value={formData[`${field.name}_First`] || ''}
                onChange={(e) => onChange(`${field.name}_First`, e.target.value)}
                placeholder="First Name"
                required={isRequired}
                className={hasError ? 'border-red-500 focus:border-red-500' : ''}
              />
            </div>
            <div>
              <Label className="text-sm text-gray-600 mb-1 block">Last Name {isRequired && <span className="text-red-500">*</span>}</Label>
              <Input
                type="text"
                value={formData[`${field.name}_Last`] || ''}
                onChange={(e) => onChange(`${field.name}_Last`, e.target.value)}
                placeholder="Last Name"
                required={isRequired}
                className={hasError ? 'border-red-500 focus:border-red-500' : ''}
              />
            </div>
            {hasError && (
              <p className="text-sm text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'address':
        return (
          <div id={`field-${field.name}`} className="space-y-3">
            <div>
              <Label className="text-sm text-gray-600 mb-1 block">Address Line 1 {isRequired && <span className="text-red-500">*</span>}</Label>
              <Input
                type="text"
                value={formData[`${field.name}_address1`] || ''}
                onChange={(e) => onChange(`${field.name}_address1`, e.target.value)}
                placeholder="Address Line 1"
                required={isRequired}
                className={hasError ? 'border-red-500 focus:border-red-500' : ''}
              />
            </div>
            <div>
              <Label className="text-sm text-gray-600 mb-1 block">Address Line 2</Label>
              <Input
                type="text"
                value={formData[`${field.name}_address2`] || ''}
                onChange={(e) => onChange(`${field.name}_address2`, e.target.value)}
                placeholder="Address Line 2"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-sm text-gray-600 mb-1 block">City {isRequired && <span className="text-red-500">*</span>}</Label>
                <Input
                  type="text"
                  value={formData[`${field.name}_city`] || ''}
                  onChange={(e) => onChange(`${field.name}_city`, e.target.value)}
                  placeholder="City"
                  required={isRequired}
                />
              </div>
              <div>
                <Label className="text-sm text-gray-600 mb-1 block">Postal/Zip Code</Label>
                <Input
                  type="text"
                  value={formData[`${field.name}_zipCode`] || ''}
                  onChange={(e) => onChange(`${field.name}_zipCode`, e.target.value)}
                  placeholder="Postal/Zip Code"
                />
              </div>
            </div>
            <div>
              <Label className="text-sm text-gray-600 mb-1 block">Country {isRequired && <span className="text-red-500">*</span>}</Label>
              <Input
                type="text"
                value={formData[`${field.name}_country`] || ''}
                onChange={(e) => onChange(`${field.name}_country`, e.target.value)}
                placeholder="Country"
                required={isRequired}
              />
            </div>
            {hasError && (
              <p className="text-sm text-red-600 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'textarea':
      case 'paragraph':
        return (
          <div id={`field-${field.name}`}>
            <Textarea
              value={value}
              onChange={(e) => onChange(field.name, e.target.value)}
              placeholder={field.placeholder || ''}
              rows={4}
              required={isRequired}
              className={hasError ? 'border-red-500 focus:border-red-500' : ''}
            />
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'checkbox':
        return (
          <div id={`field-${field.name}`}>
            <div className="flex items-center space-x-2">
              <Checkbox
                checked={value === true || value === 'true'}
                onCheckedChange={(checked) => onChange(field.name, checked)}
                required={isRequired}
              />
              <Label className="font-normal cursor-pointer">{field.label}</Label>
            </div>
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'dropdown':
      case 'select':
        return (
          <div id={`field-${field.name}`}>
            <Select 
              value={value} 
              onValueChange={(val) => onChange(field.name, val)}
              required={isRequired}
            >
              <SelectTrigger className={hasError ? 'border-red-500 focus:border-red-500' : ''}>
                <SelectValue placeholder={field.placeholder || 'Select an option'} />
              </SelectTrigger>
              <SelectContent>
                {field.options?.map((option, idx) => (
                  <SelectItem key={idx} value={option.value || option}>
                    {option.label || option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'radio':
        return (
          <div id={`field-${field.name}`}>
            <div className="space-y-2">
              {field.options?.map((option, idx) => (
                <div key={idx} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id={`${field.name}-${idx}`}
                    name={field.name}
                    value={option.value || option}
                    checked={value === (option.value || option)}
                    onChange={(e) => onChange(field.name, e.target.value)}
                    className="w-4 h-4"
                    required={isRequired}
                  />
                  <Label htmlFor={`${field.name}-${idx}`} className="font-normal cursor-pointer">
                    {option.label || option}
                  </Label>
                </div>
              ))}
            </div>
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      case 'date':
      case 'datetime':
      case 'month':
        // Use custom MonthYearPicker for month type
        if (field.type === 'month' || field.htmlInputType === 'month') {
          return (
            <div id={`field-${field.name}`}>
              <MonthYearPicker
                value={value}
                onChange={(newValue) => onChange(field.name, newValue)}
                required={isRequired}
                className={hasError ? 'border-red-500 focus:border-red-500' : ''}
                placeholder={field.placeholder || 'Select Month/Year'}
              />
              {hasError && (
                <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  {hasError}
                </p>
              )}
            </div>
          );
        }
        
        // Use native date/datetime inputs for other date types
        return (
          <div id={`field-${field.name}`}>
            <Input
              type={htmlInputType === 'datetime' ? 'datetime-local' : 'date'}
              value={value}
              onChange={(e) => onChange(field.name, e.target.value)}
              required={isRequired}
              className={hasError ? 'border-red-500 focus:border-red-500' : ''}
            />
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );

      default:
        return (
          <div id={`field-${field.name}`}>
            <Input
              value={value}
              onChange={(e) => onChange(field.name, e.target.value)}
              placeholder={field.placeholder || ''}
              required={isRequired}
              className={hasError ? 'border-red-500 focus:border-red-500' : ''}
            />
            {hasError && (
              <p className="text-sm text-red-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {hasError}
              </p>
            )}
          </div>
        );
    }
  };

  return (
    <>
      {formStructure.fields.map((field, index) => {
        if (field.type === 'subform') {
          return renderSubform(field, index);
        }
        
        return (
          <Card 
            key={field.name} 
            className={`transition-all duration-200 bg-gradient-to-br from-white to-blue-50/30 ${
              validationErrors[field.name] ? 'border-red-300 bg-red-50/50' : 'hover:shadow-md border-gray-200'
            }`}
          >
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-blue-600 text-white text-sm font-bold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <div className="flex-1">
                    <Label className="text-base font-semibold text-gray-900 flex items-center gap-1">
                      {field.label || field.name}
                      {field.required && <span className="text-red-500">*</span>}
                    </Label>
                    {field.description && (
                      <p className="text-sm text-gray-500 mt-1">{field.description}</p>
                    )}
                  </div>
                </div>
                <div className="pl-10">
                  {renderField(field)}
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </>
  );
}

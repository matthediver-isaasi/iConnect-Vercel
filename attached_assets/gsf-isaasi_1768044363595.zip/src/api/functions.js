import { base44 } from './base44Client';


export const syncZohoForms = base44.functions.syncZohoForms;

export const scrapeFormSchema = base44.functions.scrapeFormSchema;

export const calculateDueDiligenceScore = base44.functions.calculateDueDiligenceScore;

export const calculateStaticTrafficLightScore = base44.functions.calculateStaticTrafficLightScore;

export const saveFormConfiguration = base44.functions.saveFormConfiguration;

export const receiveZohoSubmission = base44.functions.receiveZohoSubmission;

export const getZohoCrmAttachments = base44.functions.getZohoCrmAttachments;

export const testCrmLookup = base44.functions.testCrmLookup;

export const receiveSignedAgreement = base44.functions.receiveSignedAgreement;

export const triggerSignatureWebhook = base44.functions.triggerSignatureWebhook;

export const receiveDdCallBooking = base44.functions.receiveDdCallBooking;

export const addRefereeToSubmission = base44.functions.addRefereeToSubmission;

export const triggerStatusWebhook = base44.functions.triggerStatusWebhook;

export const clearDdCallDate = base44.functions.clearDdCallDate;

export const getBatchProgress = base44.functions.getBatchProgress;

export const processScheduledReminders = base44.functions.processScheduledReminders;

export const testSetUserVerification = base44.functions.testSetUserVerification;

export const uploadLogoToCrm = base44.functions.uploadLogoToCrm;

export const receiveRefereeFromZoho = base44.functions.receiveRefereeFromZoho;

export const swapSubmissionFormType = base44.functions.swapSubmissionFormType;


import { base44 } from './base44Client';


export const Submission = base44.entities.Submission;

export const FormConfiguration = base44.entities.FormConfiguration;

export const JobProgress = base44.entities.JobProgress;



// auth sdk:
export const User = base44.auth;